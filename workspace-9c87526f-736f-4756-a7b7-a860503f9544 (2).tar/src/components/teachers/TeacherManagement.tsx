'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  Users,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Filter,
  DollarSign,
  GraduationCap,
  Award,
  Briefcase
} from 'lucide-react'

// Types pour les données des professeurs
interface Teacher {
  id: string
  teacherId: string
  firstName: string
  lastName: string
  email: string
  phone?: string
  dateOfBirth: string
  address?: string
  department: string
  hireDate: string
  status: 'active' | 'inactive' | 'on_leave'
  salary: number
  bankAccount?: string
  qualifications: string[]
  subjects: string[]
  classes: string[]
  experience: number
  contractType: 'permanent' | 'temporary' | 'part_time'
}

interface SalaryPayment {
  id: string
  teacherId: string
  month: string
  year: number
  baseSalary: number
  bonuses: number
  deductions: number
  netSalary: number
  paymentDate: string
  status: 'pending' | 'paid' | 'cancelled'
  paymentMethod: string
}

interface Subject {
  id: string
  name: string
  code: string
  department: string
}

interface Class {
  id: string
  name: string
  level: string
}

export default function TeacherManagement() {
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [salaryPayments, setSalaryPayments] = useState<SalaryPayment[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [classes, setClasses] = useState<Class[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isSalaryDialogOpen, setIsSalaryDialogOpen] = useState(false)
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null)
  const [viewingTeacher, setViewingTeacher] = useState<Teacher | null>(null)
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    department: '',
    salary: '',
    bankAccount: '',
    qualifications: '',
    experience: '',
    contractType: 'permanent' as const
  })

  // Charger les données (simulation)
  useEffect(() => {
    // Données de démonstration pour les professeurs
    const mockTeachers: Teacher[] = [
      {
        id: '1',
        teacherId: 'TCH001',
        firstName: 'Jean',
        lastName: 'Dupont',
        email: 'jean.dupont@email.com',
        phone: '0612345678',
        dateOfBirth: '1985-03-15',
        address: '123 Rue des Écoles, Paris',
        department: 'Mathématiques',
        hireDate: '2020-09-01',
        status: 'active',
        salary: 3500,
        bankAccount: 'FR7630006000011234567890189',
        qualifications: ['Master Mathématiques', 'CAPES Mathématiques'],
        subjects: ['Mathématiques', 'Physique'],
        classes: ['3ème A', '3ème B'],
        experience: 8,
        contractType: 'permanent'
      },
      {
        id: '2',
        teacherId: 'TCH002',
        firstName: 'Marie',
        lastName: 'Martin',
        email: 'marie.martin@email.com',
        phone: '0623456789',
        dateOfBirth: '1988-07-22',
        address: '456 Avenue de la Science, Paris',
        department: 'Français',
        hireDate: '2019-09-01',
        status: 'active',
        salary: 3200,
        bankAccount: 'FR7630006000011234567890190',
        qualifications: ['Master Littérature', 'CAPES Français'],
        subjects: ['Français', 'Littérature'],
        classes: ['4ème A', '4ème B'],
        experience: 6,
        contractType: 'permanent'
      },
      {
        id: '3',
        teacherId: 'TCH003',
        firstName: 'Pierre',
        lastName: 'Bernard',
        email: 'pierre.bernard@email.com',
        phone: '0634567890',
        dateOfBirth: '1990-11-10',
        address: '789 Boulevard du Savoir, Paris',
        department: 'Sciences',
        hireDate: '2021-09-01',
        status: 'active',
        salary: 3400,
        bankAccount: 'FR7630006000011234567890191',
        qualifications: ['Master Physique', 'CAPES Sciences'],
        subjects: ['Physique', 'Chimie'],
        classes: ['3ème A', '3ème C'],
        experience: 4,
        contractType: 'permanent'
      }
    ]

    // Paiements de salaire de démonstration
    const mockSalaryPayments: SalaryPayment[] = [
      {
        id: '1',
        teacherId: '1',
        month: 'Novembre',
        year: 2024,
        baseSalary: 3500,
        bonuses: 200,
        deductions: 350,
        netSalary: 3350,
        paymentDate: '2024-11-30',
        status: 'paid',
        paymentMethod: 'Virement bancaire'
      },
      {
        id: '2',
        teacherId: '1',
        month: 'Octobre',
        year: 2024,
        baseSalary: 3500,
        bonuses: 150,
        deductions: 350,
        netSalary: 3300,
        paymentDate: '2024-10-31',
        status: 'paid',
        paymentMethod: 'Virement bancaire'
      }
    ]

    // Données de démonstration pour les matières
    const mockSubjects: Subject[] = [
      { id: '1', name: 'Mathématiques', code: 'MATH', department: 'Mathématiques' },
      { id: '2', name: 'Français', code: 'FR', department: 'Français' },
      { id: '3', name: 'Physique', code: 'PHY', department: 'Sciences' },
      { id: '4', name: 'Chimie', code: 'CHM', department: 'Sciences' },
      { id: '5', name: 'Histoire', code: 'HIST', department: 'Histoire-Géographie' },
      { id: '6', name: 'Anglais', code: 'ENG', department: 'Langues' }
    ]

    // Données de démonstration pour les classes
    const mockClasses: Class[] = [
      { id: '1', name: '3ème A', level: '3ème' },
      { id: '2', name: '3ème B', level: '3ème' },
      { id: '3', name: '3ème C', level: '3ème' },
      { id: '4', name: '4ème A', level: '4ème' },
      { id: '5', name: '4ème B', level: '4ème' }
    ]

    setTeachers(mockTeachers)
    setSalaryPayments(mockSalaryPayments)
    setSubjects(mockSubjects)
    setClasses(mockClasses)
  }, [])

  // Filtrer les professeurs
  const filteredTeachers = teachers.filter(teacher => {
    const matchesSearch = `${teacher.firstName} ${teacher.lastName} ${teacher.teacherId}`.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDepartment = selectedDepartment === 'all' || teacher.department === selectedDepartment
    const matchesStatus = selectedStatus === 'all' || teacher.status === selectedStatus
    return matchesSearch && matchesDepartment && matchesStatus
  })

  // Gérer le formulaire
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  // Ajouter ou modifier un professeur
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingTeacher) {
      setTeachers(prev => prev.map(teacher => 
        teacher.id === editingTeacher.id 
          ? { 
              ...teacher, 
              firstName: formData.firstName,
              lastName: formData.lastName,
              email: formData.email,
              phone: formData.phone,
              dateOfBirth: formData.dateOfBirth,
              address: formData.address,
              department: formData.department,
              salary: parseFloat(formData.salary),
              bankAccount: formData.bankAccount,
              qualifications: formData.qualifications.split(',').map(q => q.trim()),
              experience: parseInt(formData.experience),
              contractType: formData.contractType
            }
          : teacher
      ))
    } else {
      const newTeacher: Teacher = {
        id: Date.now().toString(),
        teacherId: `TCH${String(teachers.length + 1).padStart(3, '0')}`,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        dateOfBirth: formData.dateOfBirth,
        address: formData.address,
        department: formData.department,
        hireDate: new Date().toISOString().split('T')[0],
        status: 'active',
        salary: parseFloat(formData.salary),
        bankAccount: formData.bankAccount,
        qualifications: formData.qualifications.split(',').map(q => q.trim()),
        subjects: [],
        classes: [],
        experience: parseInt(formData.experience),
        contractType: formData.contractType
      }
      setTeachers(prev => [...prev, newTeacher])
    }

    // Réinitialiser le formulaire
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      address: '',
      department: '',
      salary: '',
      bankAccount: '',
      qualifications: '',
      experience: '',
      contractType: 'permanent'
    })
    setEditingTeacher(null)
    setIsAddDialogOpen(false)
  }

  // Supprimer un professeur
  const handleDelete = (teacherId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce professeur ?')) {
      setTeachers(prev => prev.filter(teacher => teacher.id !== teacherId))
    }
  }

  // Voir les détails d'un professeur
  const handleView = (teacher: Teacher) => {
    setViewingTeacher(teacher)
    setIsViewDialogOpen(true)
  }

  // Modifier un professeur
  const handleEdit = (teacher: Teacher) => {
    setEditingTeacher(teacher)
    setFormData({
      firstName: teacher.firstName,
      lastName: teacher.lastName,
      email: teacher.email,
      phone: teacher.phone || '',
      dateOfBirth: teacher.dateOfBirth,
      address: teacher.address || '',
      department: teacher.department,
      salary: teacher.salary.toString(),
      bankAccount: teacher.bankAccount || '',
      qualifications: teacher.qualifications.join(', '),
      experience: teacher.experience.toString(),
      contractType: teacher.contractType
    })
    setIsAddDialogOpen(true)
  }

  // Gérer les paiements de salaire
  const handleSalaryManagement = (teacher: Teacher) => {
    setViewingTeacher(teacher)
    setIsSalaryDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Actif</Badge>
      case 'inactive':
        return <Badge className="bg-red-100 text-red-800">Inactif</Badge>
      case 'on_leave':
        return <Badge className="bg-yellow-100 text-yellow-800">En congé</Badge>
      default:
        return <Badge>Inconnu</Badge>
    }
  }

  const getContractTypeBadge = (type: string) => {
    switch (type) {
      case 'permanent':
        return <Badge className="bg-blue-100 text-blue-800">CDI</Badge>
      case 'temporary':
        return <Badge className="bg-orange-100 text-orange-800">CDD</Badge>
      case 'part_time':
        return <Badge className="bg-purple-100 text-purple-800">Temps partiel</Badge>
      default:
        return <Badge>Inconnu</Badge>
    }
  }

  const getTeacherSalaryPayments = (teacherId: string) => {
    return salaryPayments.filter(payment => payment.teacherId === teacherId)
  }

  const departments = Array.from(new Set(teachers.map(t => t.department)))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Professeurs</h2>
          <p className="text-gray-600">Gérez les professeurs, leurs salaires et leurs informations</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingTeacher(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Ajouter un professeur
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingTeacher ? 'Modifier un professeur' : 'Ajouter un nouveau professeur'}
              </DialogTitle>
              <DialogDescription>
                {editingTeacher ? 'Modifiez les informations du professeur' : 'Remplissez les informations pour ajouter un nouveau professeur'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <Tabs defaultValue="personal" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="personal">Informations personnelles</TabsTrigger>
                  <TabsTrigger value="professional">Informations professionnelles</TabsTrigger>
                  <TabsTrigger value="financial">Informations financières</TabsTrigger>
                </TabsList>
                
                <TabsContent value="personal" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">Prénom</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange('firstName', e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Nom</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange('lastName', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Téléphone</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="dateOfBirth">Date de naissance</Label>
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={formData.dateOfBirth}
                        onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="address">Adresse</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="professional" className="space-y-4">
                  <div>
                    <Label htmlFor="department">Département</Label>
                    <Input
                      id="department"
                      value={formData.department}
                      onChange={(e) => handleInputChange('department', e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="experience">Années d'expérience</Label>
                      <Input
                        id="experience"
                        type="number"
                        value={formData.experience}
                        onChange={(e) => handleInputChange('experience', e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="contractType">Type de contrat</Label>
                      <Select value={formData.contractType} onValueChange={(value: any) => handleInputChange('contractType', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="permanent">CDI</SelectItem>
                          <SelectItem value="temporary">CDD</SelectItem>
                          <SelectItem value="part_time">Temps partiel</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="qualifications">Qualifications (séparées par des virgules)</Label>
                    <Input
                      id="qualifications"
                      value={formData.qualifications}
                      onChange={(e) => handleInputChange('qualifications', e.target.value)}
                      placeholder="Master Mathématiques, CAPES Mathématiques"
                    />
                  </div>
                </TabsContent>

                <TabsContent value="financial" className="space-y-4">
                  <div>
                    <Label htmlFor="salary">Salaire mensuel (€)</Label>
                    <Input
                      id="salary"
                      type="number"
                      value={formData.salary}
                      onChange={(e) => handleInputChange('salary', e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="bankAccount">Compte bancaire (IBAN)</Label>
                    <Input
                      id="bankAccount"
                      value={formData.bankAccount}
                      onChange={(e) => handleInputChange('bankAccount', e.target.value)}
                      placeholder="FR7630006000011234567890189"
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingTeacher ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total professeurs</p>
                <p className="text-2xl font-bold">{teachers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Professeurs actifs</p>
                <p className="text-2xl font-bold">{teachers.filter(t => t.status === 'active').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Masse salariale/mois</p>
                <p className="text-2xl font-bold">
                  {teachers.reduce((acc, t) => acc + t.salary, 0).toLocaleString()}€
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Briefcase className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Expérience moyenne</p>
                <p className="text-2xl font-bold">
                  {teachers.length > 0 ? Math.round(teachers.reduce((acc, t) => acc + t.experience, 0) / teachers.length) : 0} ans
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filtres</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher par nom, prénom ou ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par département" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les départements</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="active">Actifs</SelectItem>
                <SelectItem value="inactive">Inactifs</SelectItem>
                <SelectItem value="on_leave">En congé</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Teachers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Liste des professeurs ({filteredTeachers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Nom</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Département</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Contrat</TableHead>
                  <TableHead>Salaire</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTeachers.map((teacher) => (
                  <TableRow key={teacher.id}>
                    <TableCell className="font-medium">{teacher.teacherId}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{teacher.firstName} {teacher.lastName}</div>
                        <div className="text-sm text-gray-500">{teacher.experience} ans d'expérience</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-1">
                          <Mail className="h-3 w-3 text-gray-400" />
                          <span className="text-sm">{teacher.email}</span>
                        </div>
                        {teacher.phone && (
                          <div className="flex items-center space-x-1">
                            <Phone className="h-3 w-3 text-gray-400" />
                            <span className="text-sm">{teacher.phone}</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{teacher.department}</TableCell>
                    <TableCell>{getStatusBadge(teacher.status)}</TableCell>
                    <TableCell>{getContractTypeBadge(teacher.contractType)}</TableCell>
                    <TableCell>
                      <span className="font-medium text-green-600">{teacher.salary.toLocaleString()}€</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleView(teacher)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleSalaryManagement(teacher)}>
                          <DollarSign className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(teacher)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(teacher.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Teacher Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Détails du professeur</DialogTitle>
            <DialogDescription>
              Informations complètes du professeur
            </DialogDescription>
          </DialogHeader>
          {viewingTeacher && (
            <div className="space-y-6">
              {/* Personal Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Informations personnelles</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Nom complet</Label>
                      <p className="font-medium">{viewingTeacher.firstName} {viewingTeacher.lastName}</p>
                    </div>
                    <div>
                      <Label>ID Professeur</Label>
                      <p className="font-medium">{viewingTeacher.teacherId}</p>
                    </div>
                    <div>
                      <Label>Date de naissance</Label>
                      <p className="font-medium">{viewingTeacher.dateOfBirth}</p>
                    </div>
                    <div>
                      <Label>Email</Label>
                      <p className="font-medium">{viewingTeacher.email}</p>
                    </div>
                    <div>
                      <Label>Téléphone</Label>
                      <p className="font-medium">{viewingTeacher.phone || 'Non renseigné'}</p>
                    </div>
                    <div>
                      <Label>Adresse</Label>
                      <p className="font-medium">{viewingTeacher.address || 'Non renseignée'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Professional Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Briefcase className="h-5 w-5" />
                    <span>Informations professionnelles</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Département</Label>
                      <p className="font-medium">{viewingTeacher.department}</p>
                    </div>
                    <div>
                      <Label>Date d'embauche</Label>
                      <p className="font-medium">{viewingTeacher.hireDate}</p>
                    </div>
                    <div>
                      <Label>Expérience</Label>
                      <p className="font-medium">{viewingTeacher.experience} ans</p>
                    </div>
                    <div>
                      <Label>Type de contrat</Label>
                      <p className="font-medium">{getContractTypeBadge(viewingTeacher.contractType)}</p>
                    </div>
                    <div>
                      <Label>Statut</Label>
                      <p className="font-medium">{getStatusBadge(viewingTeacher.status)}</p>
                    </div>
                    <div>
                      <Label>Qualifications</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {viewingTeacher.qualifications.map((qual, index) => (
                          <Badge key={index} variant="secondary">{qual}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Financial Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <DollarSign className="h-5 w-5" />
                    <span>Informations financières</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Salaire mensuel</Label>
                      <p className="font-medium text-green-600">{viewingTeacher.salary.toLocaleString()}€</p>
                    </div>
                    <div>
                      <Label>Compte bancaire</Label>
                      <p className="font-medium">{viewingTeacher.bankAccount || 'Non renseigné'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Classes and Subjects */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <GraduationCap className="h-5 w-5" />
                    <span>Classes et matières</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Matières enseignées</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {viewingTeacher.subjects.map((subject, index) => (
                          <Badge key={index} variant="outline">{subject}</Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label>Classes assignées</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {viewingTeacher.classes.map((cls, index) => (
                          <Badge key={index} variant="outline">{cls}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Salary Management Dialog */}
      <Dialog open={isSalaryDialogOpen} onOpenChange={setIsSalaryDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gestion des salaires</DialogTitle>
            <DialogDescription>
              Historique des paiements de salaire pour {viewingTeacher?.firstName} {viewingTeacher?.lastName}
            </DialogDescription>
          </DialogHeader>
          {viewingTeacher && (
            <div className="space-y-6">
              {/* Current Salary Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Informations salariales actuelles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>Salaire de base</Label>
                      <p className="font-medium text-green-600">{viewingTeacher.salary.toLocaleString()}€</p>
                    </div>
                    <div>
                      <Label>Type de contrat</Label>
                      <p className="font-medium">{getContractTypeBadge(viewingTeacher.contractType)}</p>
                    </div>
                    <div>
                      <Label>Compte bancaire</Label>
                      <p className="font-medium">{viewingTeacher.bankAccount || 'Non renseigné'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Salary Payments History */}
              <Card>
                <CardHeader>
                  <CardTitle>Historique des paiements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {getTeacherSalaryPayments(viewingTeacher.id).map((payment) => (
                      <div key={payment.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{payment.month} {payment.year}</h4>
                            <p className="text-sm text-gray-600">Date de paiement: {payment.paymentDate}</p>
                          </div>
                          <Badge className={
                            payment.status === 'paid' ? 'bg-green-100 text-green-800' :
                            payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }>
                            {payment.status === 'paid' ? 'Payé' : 
                             payment.status === 'pending' ? 'En attente' : 'Annulé'}
                          </Badge>
                        </div>
                        <div className="mt-2 grid grid-cols-4 gap-4">
                          <div>
                            <Label className="text-xs">Salaire de base</Label>
                            <p className="font-medium">{payment.baseSalary.toLocaleString()}€</p>
                          </div>
                          <div>
                            <Label className="text-xs">Primes</Label>
                            <p className="font-medium text-green-600">+{payment.bonuses.toLocaleString()}€</p>
                          </div>
                          <div>
                            <Label className="text-xs">Déductions</Label>
                            <p className="font-medium text-red-600">-{payment.deductions.toLocaleString()}€</p>
                          </div>
                          <div>
                            <Label className="text-xs">Salaire net</Label>
                            <p className="font-bold text-blue-600">{payment.netSalary.toLocaleString()}€</p>
                          </div>
                        </div>
                        <div className="mt-2">
                          <Label className="text-xs">Méthode de paiement</Label>
                          <p className="text-sm">{payment.paymentMethod}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}