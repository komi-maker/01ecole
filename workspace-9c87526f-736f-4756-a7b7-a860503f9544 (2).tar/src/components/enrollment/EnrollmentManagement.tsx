'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  School,
  Filter,
  Calendar,
  Users,
  FileText,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react'

interface Enrollment {
  id: string
  studentId: string
  studentName: string
  classId: string
  className: string
  academicYear: string
  enrollmentDate: string
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED'
  registrationFee: number
  tuitionFee: number
  totalFee: number
  paidAmount: number
  balance: number
  parentName: string
  parentEmail: string
  parentPhone: string
  previousSchool?: string
  documents: string[]
  remarks?: string
  approvedBy?: string
  createdAt: string
}

export default function EnrollmentManagement() {
  const [enrollments, setEnrollments] = useState<Enrollment[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [selectedYear, setSelectedYear] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [editingEnrollment, setEditingEnrollment] = useState<Enrollment | null>(null)
  const [viewingEnrollment, setViewingEnrollment] = useState<Enrollment | null>(null)
  const [formData, setFormData] = useState({
    studentId: '',
    classId: '',
    academicYear: '',
    enrollmentDate: '',
    registrationFee: '',
    tuitionFee: '',
    parentName: '',
    parentEmail: '',
    parentPhone: '',
    previousSchool: '',
    remarks: ''
  })

  useEffect(() => {
    const mockEnrollments: Enrollment[] = [
      {
        id: '1',
        studentId: '1',
        studentName: 'Marie Dupont',
        classId: '1',
        className: '3ème A',
        academicYear: '2024-2025',
        enrollmentDate: '2024-09-01',
        status: 'COMPLETED',
        registrationFee: 200,
        tuitionFee: 2500,
        totalFee: 2700,
        paidAmount: 2700,
        balance: 0,
        parentName: 'Jean Dupont',
        parentEmail: 'jean.dupont@email.com',
        parentPhone: '0612345678',
        previousSchool: 'Collège ABC',
        documents: ['Certificat de naissance', 'Bulletin précédent', 'Photo d\'identité'],
        remarks: 'Inscription complète',
        approvedBy: 'Admin',
        createdAt: '2024-09-01'
      },
      {
        id: '2',
        studentId: '2',
        studentName: 'Pierre Martin',
        classId: '2',
        className: '3ème B',
        academicYear: '2024-2025',
        enrollmentDate: '2024-09-02',
        status: 'APPROVED',
        registrationFee: 200,
        tuitionFee: 2500,
        totalFee: 2700,
        paidAmount: 200,
        balance: 2500,
        parentName: 'Sophie Martin',
        parentEmail: 'sophie.martin@email.com',
        parentPhone: '0623456789',
        previousSchool: 'Collège XYZ',
        documents: ['Certificat de naissance', 'Bulletin précédent'],
        remarks: 'En attente de paiement des frais de scolarité',
        approvedBy: 'Admin',
        createdAt: '2024-09-02'
      },
      {
        id: '3',
        studentId: '3',
        studentName: 'Sophie Bernard',
        classId: '1',
        className: '3ème A',
        academicYear: '2024-2025',
        enrollmentDate: '2024-09-03',
        status: 'PENDING',
        registrationFee: 200,
        tuitionFee: 2500,
        totalFee: 2700,
        paidAmount: 0,
        balance: 2700,
        parentName: 'Michel Bernard',
        parentEmail: 'michel.bernard@email.com',
        parentPhone: '0634567890',
        documents: ['Certificat de naissance'],
        remarks: 'Documents manquants',
        createdAt: '2024-09-03'
      }
    ]
    setEnrollments(mockEnrollments)
  }, [])

  const filteredEnrollments = enrollments.filter(enrollment => {
    const matchesSearch = enrollment.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         enrollment.parentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         enrollment.className.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === 'all' || enrollment.status === selectedStatus
    const matchesYear = selectedYear === 'all' || enrollment.academicYear === selectedYear
    return matchesSearch && matchesStatus && matchesYear
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingEnrollment) {
      setEnrollments(prev => prev.map(enrollment => 
        enrollment.id === editingEnrollment.id 
          ? { 
              ...enrollment, 
              ...formData, 
              registrationFee: parseFloat(formData.registrationFee),
              tuitionFee: parseFloat(formData.tuitionFee),
              totalFee: parseFloat(formData.registrationFee) + parseFloat(formData.tuitionFee)
            }
          : enrollment
      ))
    } else {
      const registrationFee = parseFloat(formData.registrationFee)
      const tuitionFee = parseFloat(formData.tuitionFee)
      const newEnrollment: Enrollment = {
        id: Date.now().toString(),
        studentId: formData.studentId,
        studentName: 'Étudiant', // À remplacer par le vrai nom
        classId: formData.classId,
        className: 'Classe', // À remplacer par le vrai nom
        academicYear: formData.academicYear,
        enrollmentDate: formData.enrollmentDate,
        status: 'PENDING',
        registrationFee,
        tuitionFee,
        totalFee: registrationFee + tuitionFee,
        paidAmount: 0,
        balance: registrationFee + tuitionFee,
        parentName: formData.parentName,
        parentEmail: formData.parentEmail,
        parentPhone: formData.parentPhone,
        previousSchool: formData.previousSchool,
        documents: [],
        remarks: formData.remarks,
        createdAt: new Date().toISOString().split('T')[0]
      }
      setEnrollments(prev => [...prev, newEnrollment])
    }

    setFormData({ 
      studentId: '', 
      classId: '', 
      academicYear: '', 
      enrollmentDate: '', 
      registrationFee: '', 
      tuitionFee: '', 
      parentName: '', 
      parentEmail: '', 
      parentPhone: '', 
      previousSchool: '', 
      remarks: '' 
    })
    setEditingEnrollment(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (enrollment: Enrollment) => {
    setEditingEnrollment(enrollment)
    setFormData({
      studentId: enrollment.studentId,
      classId: enrollment.classId,
      academicYear: enrollment.academicYear,
      enrollmentDate: enrollment.enrollmentDate,
      registrationFee: enrollment.registrationFee.toString(),
      tuitionFee: enrollment.tuitionFee.toString(),
      parentName: enrollment.parentName,
      parentEmail: enrollment.parentEmail,
      parentPhone: enrollment.parentPhone,
      previousSchool: enrollment.previousSchool || '',
      remarks: enrollment.remarks || ''
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (enrollmentId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette inscription ?')) {
      setEnrollments(prev => prev.filter(enrollment => enrollment.id !== enrollmentId))
    }
  }

  const handleView = (enrollment: Enrollment) => {
    setViewingEnrollment(enrollment)
    setIsViewDialogOpen(true)
  }

  const handleApprove = (enrollmentId: string) => {
    setEnrollments(prev => prev.map(enrollment => 
      enrollment.id === enrollmentId 
        ? { ...enrollment, status: 'APPROVED' as const, approvedBy: 'Admin' }
        : enrollment
    ))
  }

  const handleReject = (enrollmentId: string) => {
    setEnrollments(prev => prev.map(enrollment => 
      enrollment.id === enrollmentId 
        ? { ...enrollment, status: 'REJECTED' as const }
        : enrollment
    ))
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <Badge className="bg-green-100 text-green-800">Complète</Badge>
      case 'APPROVED':
        return <Badge className="bg-blue-100 text-blue-800">Approuvée</Badge>
      case 'PENDING':
        return <Badge className="bg-yellow-100 text-yellow-800">En attente</Badge>
      case 'REJECTED':
        return <Badge className="bg-red-100 text-red-800">Rejetée</Badge>
      default:
        return <Badge>Inconnue</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'APPROVED':
        return <CheckCircle className="h-4 w-4 text-blue-600" />
      case 'PENDING':
        return <Clock className="h-4 w-4 text-yellow-600" />
      case 'REJECTED':
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-gray-600" />
    }
  }

  const totalEnrollments = enrollments.length
  const completedEnrollments = enrollments.filter(e => e.status === 'COMPLETED').length
  const pendingEnrollments = enrollments.filter(e => e.status === 'PENDING').length
  const totalRevenue = enrollments.filter(e => e.status === 'COMPLETED').reduce((acc, e) => acc + e.totalFee, 0)

  const academicYears = Array.from(new Set(enrollments.map(e => e.academicYear)))

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Inscriptions</h2>
          <p className="text-gray-600">Gérez les nouvelles inscriptions et les dossiers des étudiants</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingEnrollment(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle inscription
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingEnrollment ? 'Modifier une inscription' : 'Nouvelle inscription'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="studentId">ID Étudiant</Label>
                  <Input
                    id="studentId"
                    value={formData.studentId}
                    onChange={(e) => handleInputChange('studentId', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="classId">ID Classe</Label>
                  <Input
                    id="classId"
                    value={formData.classId}
                    onChange={(e) => handleInputChange('classId', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="academicYear">Année académique</Label>
                  <Input
                    id="academicYear"
                    value={formData.academicYear}
                    onChange={(e) => handleInputChange('academicYear', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="enrollmentDate">Date d'inscription</Label>
                  <Input
                    id="enrollmentDate"
                    type="date"
                    value={formData.enrollmentDate}
                    onChange={(e) => handleInputChange('enrollmentDate', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="registrationFee">Frais d'inscription (€)</Label>
                  <Input
                    id="registrationFee"
                    type="number"
                    value={formData.registrationFee}
                    onChange={(e) => handleInputChange('registrationFee', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="tuitionFee">Frais de scolarité (€)</Label>
                  <Input
                    id="tuitionFee"
                    type="number"
                    value={formData.tuitionFee}
                    onChange={(e) => handleInputChange('tuitionFee', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="parentName">Nom du parent</Label>
                  <Input
                    id="parentName"
                    value={formData.parentName}
                    onChange={(e) => handleInputChange('parentName', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="parentEmail">Email du parent</Label>
                  <Input
                    id="parentEmail"
                    type="email"
                    value={formData.parentEmail}
                    onChange={(e) => handleInputChange('parentEmail', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="parentPhone">Téléphone du parent</Label>
                  <Input
                    id="parentPhone"
                    value={formData.parentPhone}
                    onChange={(e) => handleInputChange('parentPhone', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="previousSchool">École précédente</Label>
                <Input
                  id="previousSchool"
                  value={formData.previousSchool}
                  onChange={(e) => handleInputChange('previousSchool', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="remarks">Remarques</Label>
                <Input
                  id="remarks"
                  value={formData.remarks}
                  onChange={(e) => handleInputChange('remarks', e.target.value)}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingEnrollment ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <School className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total inscriptions</p>
                <p className="text-2xl font-bold">{totalEnrollments}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Inscriptions complètes</p>
                <p className="text-2xl font-bold">{completedEnrollments}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-8 w-8 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">En attente</p>
                <p className="text-2xl font-bold">{pendingEnrollments}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Revenus générés</p>
                <p className="text-2xl font-bold">{totalRevenue.toLocaleString()}€</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filtres</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher par étudiant, parent ou classe..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="COMPLETED">Complètes</SelectItem>
                <SelectItem value="APPROVED">Approuvées</SelectItem>
                <SelectItem value="PENDING">En attente</SelectItem>
                <SelectItem value="REJECTED">Rejetées</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par année" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les années</SelectItem>
                {academicYears.map(year => (
                  <SelectItem key={year} value={year}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Liste des inscriptions ({filteredEnrollments.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Étudiant</TableHead>
                <TableHead>Classe</TableHead>
                <TableHead>Année académique</TableHead>
                <TableHead>Parent</TableHead>
                <TableHead>Frais totaux</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEnrollments.map((enrollment) => (
                <TableRow key={enrollment.id}>
                  <TableCell className="font-medium">{enrollment.studentName}</TableCell>
                  <TableCell>{enrollment.className}</TableCell>
                  <TableCell>{enrollment.academicYear}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{enrollment.parentName}</div>
                      <div className="text-gray-500">{enrollment.parentEmail}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="font-medium">{enrollment.totalFee.toLocaleString()}€</div>
                      <div className="text-gray-500">Payé: {enrollment.paidAmount.toLocaleString()}€</div>
                      <div className={enrollment.balance > 0 ? 'text-red-600' : 'text-green-600'}>
                        Solde: {enrollment.balance > 0 ? `${enrollment.balance.toLocaleString()}€ dû` : 'À jour'}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(enrollment.status)}
                      {getStatusBadge(enrollment.status)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => handleView(enrollment)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      {enrollment.status === 'PENDING' && (
                        <>
                          <Button variant="ghost" size="sm" onClick={() => handleApprove(enrollment.id)}>
                            <CheckCircle className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleReject(enrollment.id)}>
                            <XCircle className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(enrollment)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(enrollment.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* View Enrollment Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Détails de l'inscription</DialogTitle>
          </DialogHeader>
          {viewingEnrollment && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Informations étudiant</h3>
                  <div className="space-y-2">
                    <p><strong>Nom:</strong> {viewingEnrollment.studentName}</p>
                    <p><strong>ID Étudiant:</strong> {viewingEnrollment.studentId}</p>
                    <p><strong>Classe:</strong> {viewingEnrollment.className}</p>
                    <p><strong>Année académique:</strong> {viewingEnrollment.academicYear}</p>
                    <p><strong>Date d'inscription:</strong> {viewingEnrollment.enrollmentDate}</p>
                    {viewingEnrollment.previousSchool && (
                      <p><strong>École précédente:</strong> {viewingEnrollment.previousSchool}</p>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold mb-3">Informations parentales</h3>
                  <div className="space-y-2">
                    <p><strong>Nom du parent:</strong> {viewingEnrollment.parentName}</p>
                    <p><strong>Email:</strong> {viewingEnrollment.parentEmail}</p>
                    <p><strong>Téléphone:</strong> {viewingEnrollment.parentPhone}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Informations financières</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p><strong>Frais d'inscription:</strong> {viewingEnrollment.registrationFee.toLocaleString()}€</p>
                    <p><strong>Frais de scolarité:</strong> {viewingEnrollment.tuitionFee.toLocaleString()}€</p>
                    <p><strong>Total:</strong> {viewingEnrollment.totalFee.toLocaleString()}€</p>
                  </div>
                  <div>
                    <p><strong>Montant payé:</strong> {viewingEnrollment.paidAmount.toLocaleString()}€</p>
                    <p><strong>Solde:</strong> 
                      <span className={viewingEnrollment.balance > 0 ? 'text-red-600 ml-2' : 'text-green-600 ml-2'}>
                        {viewingEnrollment.balance > 0 ? `${viewingEnrollment.balance.toLocaleString()}€ dû` : 'À jour'}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              {viewingEnrollment.documents.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-3">Documents fournis</h3>
                  <div className="space-y-2">
                    {viewingEnrollment.documents.map((doc, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <FileText className="h-4 w-4 text-gray-400" />
                        <span>{doc}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {viewingEnrollment.remarks && (
                <div>
                  <h3 className="font-semibold mb-3">Remarques</h3>
                  <p>{viewingEnrollment.remarks}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}