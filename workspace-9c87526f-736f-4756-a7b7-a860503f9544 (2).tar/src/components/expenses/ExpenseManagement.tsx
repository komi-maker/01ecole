'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Calculator,
  Filter,
  DollarSign,
  TrendingUp,
  Receipt
} from 'lucide-react'

interface Expense {
  id: string
  description: string
  amount: number
  category: 'SALARIES' | 'RENT' | 'UTILITIES' | 'SUPPLIES' | 'MAINTENANCE' | 'EQUIPMENT' | 'OTHER'
  date: string
  status: 'PENDING' | 'APPROVED' | 'PAID' | 'CANCELLED'
  paymentMethod?: string
  supplier?: string
  invoiceNumber?: string
  remarks?: string
  approvedBy?: string
  createdAt: string
}

export default function ExpenseManagement() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null)
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    category: 'OTHER' as 'SALARIES' | 'RENT' | 'UTILITIES' | 'SUPPLIES' | 'MAINTENANCE' | 'EQUIPMENT' | 'OTHER',
    date: '',
    paymentMethod: '',
    supplier: '',
    invoiceNumber: '',
    remarks: ''
  })

  useEffect(() => {
    const mockExpenses: Expense[] = [
      {
        id: '1',
        description: 'Fournitures de bureau',
        amount: 450,
        category: 'SUPPLIES',
        date: '2024-11-25',
        status: 'PAID',
        paymentMethod: 'Virement bancaire',
        supplier: 'BureauPlus',
        invoiceNumber: 'INV-2024-001',
        remarks: 'Stylos, cahiers, papier',
        approvedBy: 'Admin',
        createdAt: '2024-11-25'
      },
      {
        id: '2',
        description: 'Électricité - Novembre',
        amount: 280,
        category: 'UTILITIES',
        date: '2024-11-20',
        status: 'PAID',
        paymentMethod: 'Virement bancaire',
        supplier: 'EDF',
        invoiceNumber: 'INV-2024-002',
        approvedBy: 'Admin',
        createdAt: '2024-11-20'
      },
      {
        id: '3',
        description: 'Maintenance chauffage',
        amount: 350,
        category: 'MAINTENANCE',
        date: '2024-11-15',
        status: 'PENDING',
        supplier: 'ClimPro',
        invoiceNumber: 'INV-2024-003',
        remarks: 'Entretien chaudière',
        createdAt: '2024-11-15'
      }
    ]
    setExpenses(mockExpenses)
  }, [])

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.supplier?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || expense.category === selectedCategory
    const matchesStatus = selectedStatus === 'all' || expense.status === selectedStatus
    return matchesSearch && matchesCategory && matchesStatus
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingExpense) {
      setExpenses(prev => prev.map(expense => 
        expense.id === editingExpense.id 
          ? { ...expense, ...formData, amount: parseFloat(formData.amount) }
          : expense
      ))
    } else {
      const newExpense: Expense = {
        id: Date.now().toString(),
        description: formData.description,
        amount: parseFloat(formData.amount),
        category: formData.category,
        date: formData.date,
        status: 'PENDING',
        paymentMethod: formData.paymentMethod,
        supplier: formData.supplier,
        invoiceNumber: formData.invoiceNumber,
        remarks: formData.remarks,
        createdAt: new Date().toISOString().split('T')[0]
      }
      setExpenses(prev => [...prev, newExpense])
    }

    setFormData({ 
      description: '', 
      amount: '', 
      category: 'OTHER', 
      date: '', 
      paymentMethod: '', 
      supplier: '', 
      invoiceNumber: '', 
      remarks: '' 
    })
    setEditingExpense(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense)
    setFormData({
      description: expense.description,
      amount: expense.amount.toString(),
      category: expense.category,
      date: expense.date,
      paymentMethod: expense.paymentMethod || '',
      supplier: expense.supplier || '',
      invoiceNumber: expense.invoiceNumber || '',
      remarks: expense.remarks || ''
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (expenseId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette dépense ?')) {
      setExpenses(prev => prev.filter(expense => expense.id !== expenseId))
    }
  }

  const handleApprove = (expenseId: string) => {
    setExpenses(prev => prev.map(expense => 
      expense.id === expenseId 
        ? { ...expense, status: 'APPROVED' as const, approvedBy: 'Admin' }
        : expense
    ))
  }

  const handleMarkAsPaid = (expenseId: string) => {
    setExpenses(prev => prev.map(expense => 
      expense.id === expenseId 
        ? { ...expense, status: 'PAID' as const, paymentMethod: 'Virement bancaire' }
        : expense
    ))
  }

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case 'SALARIES':
        return <Badge variant="outline">Salaires</Badge>
      case 'RENT':
        return <Badge variant="outline">Loyer</Badge>
      case 'UTILITIES':
        return <Badge variant="outline">Services publics</Badge>
      case 'SUPPLIES':
        return <Badge variant="outline">Fournitures</Badge>
      case 'MAINTENANCE':
        return <Badge variant="outline">Maintenance</Badge>
      case 'EQUIPMENT':
        return <Badge variant="outline">Équipement</Badge>
      case 'OTHER':
        return <Badge variant="outline">Autre</Badge>
      default:
        return <Badge variant="outline">Inconnu</Badge>
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PAID':
        return <Badge className="bg-green-100 text-green-800">Payée</Badge>
      case 'APPROVED':
        return <Badge className="bg-blue-100 text-blue-800">Approuvée</Badge>
      case 'PENDING':
        return <Badge className="bg-yellow-100 text-yellow-800">En attente</Badge>
      case 'CANCELLED':
        return <Badge className="bg-red-100 text-red-800">Annulée</Badge>
      default:
        return <Badge>Inconnue</Badge>
    }
  }

  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0)
  const paidExpenses = expenses.filter(e => e.status === 'PAID').reduce((acc, e) => acc + e.amount, 0)
  const pendingExpenses = expenses.filter(e => e.status === 'PENDING').reduce((acc, e) => acc + e.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Dépenses</h2>
          <p className="text-gray-600">Suivez et gérez toutes les dépenses de l'école</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingExpense(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Ajouter une dépense
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingExpense ? 'Modifier une dépense' : 'Ajouter une dépense'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="amount">Montant (€)</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={formData.amount}
                    onChange={(e) => handleInputChange('amount', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="category">Catégorie</Label>
                  <Select value={formData.category} onValueChange={(value: any) => handleInputChange('category', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SALARIES">Salaires</SelectItem>
                      <SelectItem value="RENT">Loyer</SelectItem>
                      <SelectItem value="UTILITIES">Services publics</SelectItem>
                      <SelectItem value="SUPPLIES">Fournitures</SelectItem>
                      <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
                      <SelectItem value="EQUIPMENT">Équipement</SelectItem>
                      <SelectItem value="OTHER">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="supplier">Fournisseur</Label>
                  <Input
                    id="supplier"
                    value={formData.supplier}
                    onChange={(e) => handleInputChange('supplier', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="invoiceNumber">Numéro de facture</Label>
                  <Input
                    id="invoiceNumber"
                    value={formData.invoiceNumber}
                    onChange={(e) => handleInputChange('invoiceNumber', e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="paymentMethod">Méthode de paiement</Label>
                <Input
                  id="paymentMethod"
                  value={formData.paymentMethod}
                  onChange={(e) => handleInputChange('paymentMethod', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="remarks">Remarques</Label>
                <Input
                  id="remarks"
                  value={formData.remarks}
                  onChange={(e) => handleInputChange('remarks', e.target.value)}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingExpense ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calculator className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total dépenses</p>
                <p className="text-2xl font-bold">{totalExpenses.toLocaleString()}€</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Dépenses payées</p>
                <p className="text-2xl font-bold">{paidExpenses.toLocaleString()}€</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">En attente</p>
                <p className="text-2xl font-bold">{pendingExpenses.toLocaleString()}€</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Receipt className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Total dépenses</p>
                <p className="text-2xl font-bold">{expenses.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filtres</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher par description, fournisseur ou facture..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par catégorie" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les catégories</SelectItem>
                <SelectItem value="SALARIES">Salaires</SelectItem>
                <SelectItem value="RENT">Loyer</SelectItem>
                <SelectItem value="UTILITIES">Services publics</SelectItem>
                <SelectItem value="SUPPLIES">Fournitures</SelectItem>
                <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
                <SelectItem value="EQUIPMENT">Équipement</SelectItem>
                <SelectItem value="OTHER">Autre</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="PAID">Payées</SelectItem>
                <SelectItem value="APPROVED">Approuvées</SelectItem>
                <SelectItem value="PENDING">En attente</SelectItem>
                <SelectItem value="CANCELLED">Annulées</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Liste des dépenses ({filteredExpenses.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Description</TableHead>
                <TableHead>Catégorie</TableHead>
                <TableHead>Montant</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Fournisseur</TableHead>
                <TableHead>Facture</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredExpenses.map((expense) => (
                <TableRow key={expense.id}>
                  <TableCell className="font-medium">{expense.description}</TableCell>
                  <TableCell>{getCategoryBadge(expense.category)}</TableCell>
                  <TableCell className="font-medium">{expense.amount.toLocaleString()}€</TableCell>
                  <TableCell>{expense.date}</TableCell>
                  <TableCell>{expense.supplier || '-'}</TableCell>
                  <TableCell>{expense.invoiceNumber || '-'}</TableCell>
                  <TableCell>{getStatusBadge(expense.status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(expense)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      {expense.status === 'PENDING' && (
                        <Button variant="ghost" size="sm" onClick={() => handleApprove(expense.id)}>
                          <DollarSign className="h-4 w-4" />
                        </Button>
                      )}
                      {expense.status === 'APPROVED' && (
                        <Button variant="ghost" size="sm" onClick={() => handleMarkAsPaid(expense.id)}>
                          <DollarSign className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(expense.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}