'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye, 
  Users,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Filter,
  History,
  GraduationCap,
  FileText,
  Award
} from 'lucide-react'

// Types pour les données des étudiants
interface Student {
  id: string
  studentId: string
  firstName: string
  lastName: string
  email: string
  phone?: string
  dateOfBirth: string
  address?: string
  className?: string
  enrollmentDate: string
  status: 'active' | 'inactive' | 'graduated'
  parentName?: string
  parentPhone?: string
  parentEmail?: string
  attendanceRate: number
  averageGrade: number
  photo?: string
  emergencyContact?: string
  medicalInfo?: string
}

interface AcademicHistory {
  id: string
  studentId: string
  academicYear: string
  className: string
  level: string
  averageGrade: number
  rank: number
  totalStudents: number
  status: 'passed' | 'failed' | 'ongoing'
  remarks?: string
}

interface Class {
  id: string
  name: string
  level: string
  capacity: number
  currentStudents: number
}

export default function StudentManagement() {
  const [students, setStudents] = useState<Student[]>([])
  const [academicHistory, setAcademicHistory] = useState<AcademicHistory[]>([])
  const [classes, setClasses] = useState<Class[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedClass, setSelectedClass] = useState<string>('all')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [editingStudent, setEditingStudent] = useState<Student | null>(null)
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null)
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    classId: '',
    parentName: '',
    parentPhone: '',
    parentEmail: '',
    emergencyContact: '',
    medicalInfo: ''
  })

  // Charger les données (simulation)
  useEffect(() => {
    // Données de démonstration pour les étudiants
    const mockStudents: Student[] = [
      {
        id: '1',
        studentId: 'STU001',
        firstName: 'Marie',
        lastName: 'Dupont',
        email: 'marie.dupont@email.com',
        phone: '0612345678',
        dateOfBirth: '2008-05-15',
        address: '123 Rue de la Paix, Paris',
        className: '3ème A',
        enrollmentDate: '2021-09-01',
        status: 'active',
        parentName: 'Jean Dupont',
        parentPhone: '0612345679',
        parentEmail: 'jean.dupont@email.com',
        attendanceRate: 95,
        averageGrade: 15.5,
        emergencyContact: 'Mère Dupont - 0612345679',
        medicalInfo: 'Allergie aux arachides'
      },
      {
        id: '2',
        studentId: 'STU002',
        firstName: 'Pierre',
        lastName: 'Martin',
        email: 'pierre.martin@email.com',
        phone: '0623456789',
        dateOfBirth: '2008-03-22',
        address: '456 Avenue des Champs, Paris',
        className: '3ème B',
        enrollmentDate: '2021-09-01',
        status: 'active',
        parentName: 'Sophie Martin',
        parentPhone: '0623456780',
        parentEmail: 'sophie.martin@email.com',
        attendanceRate: 88,
        averageGrade: 13.2
      },
      {
        id: '3',
        studentId: 'STU003',
        firstName: 'Sophie',
        lastName: 'Bernard',
        email: 'sophie.bernard@email.com',
        phone: '0634567890',
        dateOfBirth: '2008-07-10',
        address: '789 Boulevard Voltaire, Paris',
        className: '3ème A',
        enrollmentDate: '2021-09-01',
        status: 'active',
        parentName: 'Michel Bernard',
        parentPhone: '0634567891',
        parentEmail: 'michel.bernard@email.com',
        attendanceRate: 92,
        averageGrade: 16.8
      }
    ]

    // Historique académique de démonstration
    const mockAcademicHistory: AcademicHistory[] = [
      {
        id: '1',
        studentId: '1',
        academicYear: '2023-2024',
        className: '3ème A',
        level: '3ème',
        averageGrade: 15.5,
        rank: 5,
        totalStudents: 28,
        status: 'ongoing',
        remarks: 'Excellent élève, très motivé'
      },
      {
        id: '2',
        studentId: '1',
        academicYear: '2022-2023',
        className: '4ème A',
        level: '4ème',
        averageGrade: 14.8,
        rank: 8,
        totalStudents: 30,
        status: 'passed',
        remarks: 'Bonne progression'
      },
      {
        id: '3',
        studentId: '1',
        academicYear: '2021-2022',
        className: '5ème B',
        level: '5ème',
        averageGrade: 14.2,
        rank: 12,
        totalStudents: 32,
        status: 'passed',
        remarks: 'Adaptation réussie'
      }
    ]

    // Données de démonstration pour les classes
    const mockClasses: Class[] = [
      { id: '1', name: '3ème A', level: '3ème', capacity: 30, currentStudents: 28 },
      { id: '2', name: '3ème B', level: '3ème', capacity: 30, currentStudents: 25 },
      { id: '3', name: '4ème A', level: '4ème', capacity: 30, currentStudents: 27 },
      { id: '4', name: '5ème B', level: '5ème', capacity: 30, currentStudents: 26 }
    ]

    setStudents(mockStudents)
    setAcademicHistory(mockAcademicHistory)
    setClasses(mockClasses)
  }, [])

  // Filtrer les étudiants
  const filteredStudents = students.filter(student => {
    const matchesSearch = `${student.firstName} ${student.lastName} ${student.studentId}`.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesClass = selectedClass === 'all' || student.className === classes.find(c => c.id === selectedClass)?.name
    const matchesStatus = selectedStatus === 'all' || student.status === selectedStatus
    return matchesSearch && matchesClass && matchesStatus
  })

  // Gérer le formulaire
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  // Ajouter ou modifier un étudiant
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingStudent) {
      setStudents(prev => prev.map(student => 
        student.id === editingStudent.id 
          ? { 
              ...student, 
              firstName: formData.firstName,
              lastName: formData.lastName,
              email: formData.email,
              phone: formData.phone,
              dateOfBirth: formData.dateOfBirth,
              address: formData.address,
              className: classes.find(c => c.id === formData.classId)?.name,
              parentName: formData.parentName,
              parentPhone: formData.parentPhone,
              parentEmail: formData.parentEmail,
              emergencyContact: formData.emergencyContact,
              medicalInfo: formData.medicalInfo
            }
          : student
      ))
    } else {
      const newStudent: Student = {
        id: Date.now().toString(),
        studentId: `STU${String(students.length + 1).padStart(3, '0')}`,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        dateOfBirth: formData.dateOfBirth,
        address: formData.address,
        className: classes.find(c => c.id === formData.classId)?.name,
        enrollmentDate: new Date().toISOString().split('T')[0],
        status: 'active',
        parentName: formData.parentName,
        parentPhone: formData.parentPhone,
        parentEmail: formData.parentEmail,
        emergencyContact: formData.emergencyContact,
        medicalInfo: formData.medicalInfo,
        attendanceRate: 0,
        averageGrade: 0
      }
      setStudents(prev => [...prev, newStudent])
    }

    // Réinitialiser le formulaire
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      address: '',
      classId: '',
      parentName: '',
      parentPhone: '',
      parentEmail: '',
      emergencyContact: '',
      medicalInfo: ''
    })
    setEditingStudent(null)
    setIsAddDialogOpen(false)
  }

  // Supprimer un étudiant
  const handleDelete = (studentId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet étudiant ?')) {
      setStudents(prev => prev.filter(student => student.id !== studentId))
    }
  }

  // Voir les détails d'un étudiant
  const handleView = (student: Student) => {
    setViewingStudent(student)
    setIsViewDialogOpen(true)
  }

  // Modifier un étudiant
  const handleEdit = (student: Student) => {
    setEditingStudent(student)
    setFormData({
      firstName: student.firstName,
      lastName: student.lastName,
      email: student.email,
      phone: student.phone || '',
      dateOfBirth: student.dateOfBirth,
      address: student.address || '',
      classId: classes.find(c => c.name === student.className)?.id || '',
      parentName: student.parentName || '',
      parentPhone: student.parentPhone || '',
      parentEmail: student.parentEmail || '',
      emergencyContact: student.emergencyContact || '',
      medicalInfo: student.medicalInfo || ''
    })
    setIsAddDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Actif</Badge>
      case 'inactive':
        return <Badge className="bg-red-100 text-red-800">Inactif</Badge>
      case 'graduated':
        return <Badge className="bg-blue-100 text-blue-800">Diplômé</Badge>
      default:
        return <Badge>Inconnu</Badge>
    }
  }

  const getStudentHistory = (studentId: string) => {
    return academicHistory.filter(history => history.studentId === studentId)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Étudiants</h2>
          <p className="text-gray-600">Gérez les inscriptions, informations et historique scolaire des étudiants</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingStudent(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Ajouter un étudiant
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingStudent ? 'Modifier un étudiant' : 'Ajouter un nouvel étudiant'}
              </DialogTitle>
              <DialogDescription>
                {editingStudent ? 'Modifiez les informations de l\'étudiant' : 'Remplissez les informations pour inscrire un nouvel étudiant'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <Tabs defaultValue="personal" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="personal">Informations personnelles</TabsTrigger>
                  <TabsTrigger value="academic">Informations académiques</TabsTrigger>
                  <TabsTrigger value="parent">Informations parentales</TabsTrigger>
                </TabsList>
                
                <TabsContent value="personal" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">Prénom</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange('firstName', e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Nom</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange('lastName', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Téléphone</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="dateOfBirth">Date de naissance</Label>
                      <Input
                        id="dateOfBirth"
                        type="date"
                        value={formData.dateOfBirth}
                        onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="address">Adresse</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="emergencyContact">Contact d'urgence</Label>
                      <Input
                        id="emergencyContact"
                        value={formData.emergencyContact}
                        onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="medicalInfo">Informations médicales</Label>
                      <Input
                        id="medicalInfo"
                        value={formData.medicalInfo}
                        onChange={(e) => handleInputChange('medicalInfo', e.target.value)}
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="academic" className="space-y-4">
                  <div>
                    <Label htmlFor="classId">Classe</Label>
                    <Select value={formData.classId} onValueChange={(value) => handleInputChange('classId', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner une classe" />
                      </SelectTrigger>
                      <SelectContent>
                        {classes.map(cls => (
                          <SelectItem key={cls.id} value={cls.id}>
                            {cls.name} ({cls.currentStudents}/{cls.capacity} étudiants)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </TabsContent>

                <TabsContent value="parent" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="parentName">Nom du parent</Label>
                      <Input
                        id="parentName"
                        value={formData.parentName}
                        onChange={(e) => handleInputChange('parentName', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="parentPhone">Téléphone du parent</Label>
                      <Input
                        id="parentPhone"
                        value={formData.parentPhone}
                        onChange={(e) => handleInputChange('parentPhone', e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="parentEmail">Email du parent</Label>
                    <Input
                      id="parentEmail"
                      type="email"
                      value={formData.parentEmail}
                      onChange={(e) => handleInputChange('parentEmail', e.target.value)}
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingStudent ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total étudiants</p>
                <p className="text-2xl font-bold">{students.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Étudiants actifs</p>
                <p className="text-2xl font-bold">{students.filter(s => s.status === 'active').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Présence moyenne</p>
                <p className="text-2xl font-bold">
                  {students.length > 0 ? Math.round(students.reduce((acc, s) => acc + s.attendanceRate, 0) / students.length) : 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Moyenne générale</p>
                <p className="text-2xl font-bold">
                  {students.length > 0 ? (students.reduce((acc, s) => acc + s.averageGrade, 0) / students.length).toFixed(1) : 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filtres</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher par nom, prénom ou ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par classe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les classes</SelectItem>
                {classes.map(cls => (
                  <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="active">Actifs</SelectItem>
                <SelectItem value="inactive">Inactifs</SelectItem>
                <SelectItem value="graduated">Diplômés</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students Table */}
      <Card>
        <CardHeader>
          <CardTitle>Liste des étudiants ({filteredStudents.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Nom</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Classe</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Présence</TableHead>
                  <TableHead>Moyenne</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">{student.studentId}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{student.firstName} {student.lastName}</div>
                        <div className="text-sm text-gray-500">{student.dateOfBirth}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-1">
                          <Mail className="h-3 w-3 text-gray-400" />
                          <span className="text-sm">{student.email}</span>
                        </div>
                        {student.phone && (
                          <div className="flex items-center space-x-1">
                            <Phone className="h-3 w-3 text-gray-400" />
                            <span className="text-sm">{student.phone}</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{student.className}</TableCell>
                    <TableCell>{getStatusBadge(student.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">{student.attendanceRate}%</span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              student.attendanceRate >= 90 ? 'bg-green-500' : 
                              student.attendanceRate >= 75 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}
                            style={{ width: `${student.attendanceRate}%` }}
                          />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className={`font-medium ${
                        student.averageGrade >= 15 ? 'text-green-600' : 
                        student.averageGrade >= 10 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {student.averageGrade.toFixed(1)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleView(student)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(student)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(student.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Student Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Détails de l'étudiant</DialogTitle>
            <DialogDescription>
              Informations complètes et historique scolaire
            </DialogDescription>
          </DialogHeader>
          {viewingStudent && (
            <div className="space-y-6">
              {/* Personal Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Informations personnelles</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Nom complet</Label>
                      <p className="font-medium">{viewingStudent.firstName} {viewingStudent.lastName}</p>
                    </div>
                    <div>
                      <Label>ID Étudiant</Label>
                      <p className="font-medium">{viewingStudent.studentId}</p>
                    </div>
                    <div>
                      <Label>Date de naissance</Label>
                      <p className="font-medium">{viewingStudent.dateOfBirth}</p>
                    </div>
                    <div>
                      <Label>Email</Label>
                      <p className="font-medium">{viewingStudent.email}</p>
                    </div>
                    <div>
                      <Label>Téléphone</Label>
                      <p className="font-medium">{viewingStudent.phone || 'Non renseigné'}</p>
                    </div>
                    <div>
                      <Label>Adresse</Label>
                      <p className="font-medium">{viewingStudent.address || 'Non renseignée'}</p>
                    </div>
                    <div>
                      <Label>Contact d'urgence</Label>
                      <p className="font-medium">{viewingStudent.emergencyContact || 'Non renseigné'}</p>
                    </div>
                    <div>
                      <Label>Informations médicales</Label>
                      <p className="font-medium">{viewingStudent.medicalInfo || 'Aucune'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Academic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <GraduationCap className="h-5 w-5" />
                    <span>Informations académiques</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Classe actuelle</Label>
                      <p className="font-medium">{viewingStudent.className}</p>
                    </div>
                    <div>
                      <Label>Date d'inscription</Label>
                      <p className="font-medium">{viewingStudent.enrollmentDate}</p>
                    </div>
                    <div>
                      <Label>Taux de présence</Label>
                      <p className="font-medium">{viewingStudent.attendanceRate}%</p>
                    </div>
                    <div>
                      <Label>Moyenne générale</Label>
                      <p className="font-medium">{viewingStudent.averageGrade.toFixed(1)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Parent Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Informations parentales</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Nom du parent</Label>
                      <p className="font-medium">{viewingStudent.parentName || 'Non renseigné'}</p>
                    </div>
                    <div>
                      <Label>Téléphone du parent</Label>
                      <p className="font-medium">{viewingStudent.parentPhone || 'Non renseigné'}</p>
                    </div>
                    <div>
                      <Label>Email du parent</Label>
                      <p className="font-medium">{viewingStudent.parentEmail || 'Non renseigné'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Academic History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <History className="h-5 w-5" />
                    <span>Historique scolaire</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {getStudentHistory(viewingStudent.id).map((history) => (
                      <div key={history.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">{history.academicYear}</h4>
                            <p className="text-sm text-gray-600">{history.className} - {history.level}</p>
                          </div>
                          <Badge className={
                            history.status === 'passed' ? 'bg-green-100 text-green-800' :
                            history.status === 'failed' ? 'bg-red-100 text-red-800' :
                            'bg-blue-100 text-blue-800'
                          }>
                            {history.status === 'passed' ? 'Admis' : 
                             history.status === 'failed' ? 'Échec' : 'En cours'}
                          </Badge>
                        </div>
                        <div className="mt-2 grid grid-cols-3 gap-4">
                          <div>
                            <Label className="text-xs">Moyenne</Label>
                            <p className="font-medium">{history.averageGrade.toFixed(1)}</p>
                          </div>
                          <div>
                            <Label className="text-xs">Rang</Label>
                            <p className="font-medium">{history.rank}/{history.totalStudents}</p>
                          </div>
                          <div>
                            <Label className="text-xs">Remarques</Label>
                            <p className="text-sm">{history.remarks || 'Aucune'}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}