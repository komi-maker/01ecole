'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  BookOpen,
  Filter
} from 'lucide-react'

interface Subject {
  id: string
  name: string
  code: string
  description?: string
  credits: number
  teacherId?: string
  teacherName?: string
  classIds: string[]
  classNames: string[]
  status: 'active' | 'inactive'
  createdAt: string
}

export default function SubjectManagement() {
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    description: '',
    credits: '',
    teacherId: ''
  })

  useEffect(() => {
    const mockSubjects: Subject[] = [
      {
        id: '1',
        name: 'Mathématiques',
        code: 'MATH',
        description: 'Cours de mathématiques générales',
        credits: 4,
        teacherId: '1',
        teacherName: 'Jean Durand',
        classIds: ['1', '2'],
        classNames: ['3ème A', '3ème B'],
        status: 'active',
        createdAt: '2023-09-01'
      },
      {
        id: '2',
        name: 'Français',
        code: 'FR',
        description: 'Cours de langue et littérature française',
        credits: 4,
        teacherId: '2',
        teacherName: 'Marie Lefebvre',
        classIds: ['1', '3'],
        classNames: ['3ème A', '3ème C'],
        status: 'active',
        createdAt: '2023-09-01'
      }
    ]
    setSubjects(mockSubjects)
  }, [])

  const filteredSubjects = subjects.filter(subject => {
    const matchesSearch = subject.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         subject.code.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === 'all' || subject.status === selectedStatus
    return matchesSearch && matchesStatus
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingSubject) {
      setSubjects(prev => prev.map(subject => 
        subject.id === editingSubject.id 
          ? { ...subject, ...formData, credits: parseInt(formData.credits) }
          : subject
      ))
    } else {
      const newSubject: Subject = {
        id: Date.now().toString(),
        name: formData.name,
        code: formData.code,
        description: formData.description,
        credits: parseInt(formData.credits),
        classIds: [],
        classNames: [],
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0]
      }
      setSubjects(prev => [...prev, newSubject])
    }

    setFormData({ name: '', code: '', description: '', credits: '', teacherId: '' })
    setEditingSubject(null)
    setIsAddDialogOpen(false)
  }

  const handleEdit = (subject: Subject) => {
    setEditingSubject(subject)
    setFormData({
      name: subject.name,
      code: subject.code,
      description: subject.description || '',
      credits: subject.credits.toString(),
      teacherId: subject.teacherId || ''
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (subjectId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette matière ?')) {
      setSubjects(prev => prev.filter(subject => subject.id !== subjectId))
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Matières</h2>
          <p className="text-gray-600">Gérez les matières et leurs affectations</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingSubject(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Ajouter une matière
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingSubject ? 'Modifier une matière' : 'Ajouter une matière'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Nom de la matière</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="code">Code</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) => handleInputChange('code', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="credits">Crédits</Label>
                <Input
                  id="credits"
                  type="number"
                  value={formData.credits}
                  onChange={(e) => handleInputChange('credits', e.target.value)}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingSubject ? 'Modifier' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total matières</p>
                <p className="text-2xl font-bold">{subjects.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Matières actives</p>
                <p className="text-2xl font-bold">{subjects.filter(s => s.status === 'active').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-gray-600">Total crédits</p>
                <p className="text-2xl font-bold">{subjects.reduce((acc, s) => acc + s.credits, 0)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filtres</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher une matière..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Liste des matières ({filteredSubjects.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Nom</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Crédits</TableHead>
                <TableHead>Professeur</TableHead>
                <TableHead>Classes</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSubjects.map((subject) => (
                <TableRow key={subject.id}>
                  <TableCell className="font-medium">{subject.code}</TableCell>
                  <TableCell>{subject.name}</TableCell>
                  <TableCell>{subject.description || '-'}</TableCell>
                  <TableCell>{subject.credits}</TableCell>
                  <TableCell>{subject.teacherName || 'Non assigné'}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {subject.classNames.slice(0, 2).join(', ')}
                      {subject.classNames.length > 2 && ` +${subject.classNames.length - 2}`}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={subject.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                      {subject.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(subject)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(subject.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}