'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  FileText, 
  Image, 
  Download, 
  Upload, 
  Settings, 
  Eye,
  Save,
  Trash2,
  Plus,
  Edit,
  Copy,
  Printer,
  FileImage,
  FileSpreadsheet,
  Receipt,
  GraduationCap,
  Users,
  DollarSign,
  Calendar
} from 'lucide-react'

interface PrintTemplate {
  id: string
  name: string
  type: 'bulletin' | 'attestation' | 'facture' | 'certificat' | 'liste' | 'emploi_du_temps' | 'rapport'
  description: string
  logo?: string
  header: string
  footer: string
  content: string
  pageSize: 'A4' | 'A3' | 'Letter'
  orientation: 'portrait' | 'landscape'
  margins: {
    top: number
    right: number
    bottom: number
    left: number
  }
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface PrintSettings {
  defaultLogo?: string
  defaultHeader: string
  defaultFooter: string
  defaultPageSize: 'A4' | 'A3' | 'Letter'
  defaultOrientation: 'portrait' | 'landscape'
  defaultMargins: {
    top: number
    right: number
    bottom: number
    left: number
  }
  watermark?: string
  watermarkOpacity: number
  printGrades: boolean
  printPhotos: boolean
  printSignatures: boolean
}

export default function PrintSettings() {
  const [activeTab, setActiveTab] = useState('templates')
  const [loading, setLoading] = useState(false)
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle')
  const [templates, setTemplates] = useState<PrintTemplate[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<PrintTemplate | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  
  const [printSettings, setPrintSettings] = useState<PrintSettings>({
    defaultHeader: `
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #1e40af; margin-bottom: 10px;">ÉCOLEPRO MANAGER</h1>
        <p style="margin: 5px 0;">123 Rue de l'Éducation, 75000 Paris</p>
        <p style="margin: 5px 0;">Tél: +33 1 23 45 67 89 | Email: contact@ecolepro.fr</p>
      </div>
    `,
    defaultFooter: `
      <div style="text-align: center; margin-top: 20px; font-size: 12px; color: #666;">
        <p>Document généré le ${new Date().toLocaleDateString('fr-FR')}</p>
        <p>ÉcolePro Manager - Système de Gestion Scolaire</p>
      </div>
    `,
    defaultPageSize: 'A4',
    defaultOrientation: 'portrait',
    defaultMargins: {
      top: 20,
      right: 20,
      bottom: 20,
      left: 20
    },
    watermarkOpacity: 0.1,
    printGrades: true,
    printPhotos: false,
    printSignatures: true
  })

  const [newTemplate, setNewTemplate] = useState<Partial<PrintTemplate>>({
    name: '',
    type: 'bulletin',
    description: '',
    header: printSettings.defaultHeader,
    footer: printSettings.defaultFooter,
    content: '',
    pageSize: 'A4',
    orientation: 'portrait',
    margins: printSettings.defaultMargins,
    isActive: true
  })

  const templateTypes = [
    { value: 'bulletin', label: 'Bulletin de notes', icon: GraduationCap },
    { value: 'attestation', label: 'Attestation de scolarité', icon: FileText },
    { value: 'facture', label: 'Facture', icon: Receipt },
    { value: 'certificat', label: 'Certificat', icon: FileImage },
    { value: 'liste', label: 'Liste d\'élèves', icon: Users },
    { value: 'emploi_du_temps', label: 'Emploi du temps', icon: Calendar },
    { value: 'rapport', label: 'Rapport', icon: FileSpreadsheet }
  ]

  const loadTemplates = async () => {
    try {
      const response = await fetch('/api/print-templates')
      if (response.ok) {
        const data = await response.json()
        setTemplates(data)
      }
    } catch (error) {
      console.error('Failed to load templates:', error)
    }
  }

  const loadPrintSettings = async () => {
    try {
      const response = await fetch('/api/settings?category=print')
      if (response.ok) {
        const data = await response.json()
        if (data.print) {
          setPrintSettings(data.print)
        }
      }
    } catch (error) {
      console.error('Failed to load print settings:', error)
    }
  }

  useEffect(() => {
    loadTemplates()
    loadPrintSettings()
  }, [])

  const handleSaveTemplate = async () => {
    if (!newTemplate.name || !newTemplate.type) return

    setLoading(true)
    setSaveStatus('saving')

    try {
      const method = selectedTemplate ? 'PUT' : 'POST'
      const url = selectedTemplate ? `/api/print-templates/${selectedTemplate.id}` : '/api/print-templates'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newTemplate)
      })

      if (response.ok) {
        setSaveStatus('success')
        await loadTemplates()
        setIsEditing(false)
        setSelectedTemplate(null)
        setNewTemplate({
          name: '',
          type: 'bulletin',
          description: '',
          header: printSettings.defaultHeader,
          footer: printSettings.defaultFooter,
          content: '',
          pageSize: 'A4',
          orientation: 'portrait',
          margins: printSettings.defaultMargins,
          isActive: true
        })
        setTimeout(() => setSaveStatus('idle'), 3000)
      } else {
        throw new Error('Failed to save template')
      }
    } catch (error) {
      setSaveStatus('error')
      setTimeout(() => setSaveStatus('idle'), 3000)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteTemplate = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce modèle ?')) return

    try {
      const response = await fetch(`/api/print-templates/${id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        await loadTemplates()
        if (selectedTemplate?.id === id) {
          setSelectedTemplate(null)
          setIsEditing(false)
        }
      }
    } catch (error) {
      console.error('Failed to delete template:', error)
    }
  }

  const handleDuplicateTemplate = async (template: PrintTemplate) => {
    const duplicated = {
      ...template,
      name: `${template.name} (copie)`,
      id: undefined
    }

    try {
      const response = await fetch('/api/print-templates', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(duplicated)
      })

      if (response.ok) {
        await loadTemplates()
      }
    } catch (error) {
      console.error('Failed to duplicate template:', error)
    }
  }

  const handleSavePrintSettings = async () => {
    setLoading(true)
    setSaveStatus('saving')

    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          category: 'print',
          settings: printSettings
        })
      })

      if (response.ok) {
        setSaveStatus('success')
        setTimeout(() => setSaveStatus('idle'), 3000)
      } else {
        throw new Error('Failed to save print settings')
      }
    } catch (error) {
      setSaveStatus('error')
      setTimeout(() => setSaveStatus('idle'), 3000)
    } finally {
      setLoading(false)
    }
  }

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const base64 = e.target?.result as string
        if (selectedTemplate) {
          setSelectedTemplate({...selectedTemplate, logo: base64})
          setNewTemplate({...newTemplate, logo: base64})
        } else {
          setNewTemplate({...newTemplate, logo: base64})
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const getTemplateIcon = (type: string) => {
    const templateType = templateTypes.find(t => t.value === type)
    return templateType ? templateType.icon : FileText
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Paramètres d'impression</h2>
          <p className="text-muted-foreground">Configurez les modèles et paramètres d'impression</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-2" />
            Aperçu impression
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="templates" className="flex items-center space-x-2">
            <FileText className="h-4 w-4" />
            <span>Modèles</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Paramètres</span>
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center space-x-2">
            <Eye className="h-4 w-4" />
            <span>Aperçu</span>
          </TabsTrigger>
        </TabsList>

        {/* Onglet Modèles */}
        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Liste des modèles */}
            <Card>
              <CardHeader>
                <CardTitle>Modèles disponibles</CardTitle>
                <CardDescription>
                  Gérez vos modèles d'impression
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {templates.map((template) => {
                    const Icon = getTemplateIcon(template.type)
                    return (
                      <div
                        key={template.id}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                          selectedTemplate?.id === template.id
                            ? 'border-blue-500 bg-blue-50'
                            : 'hover:bg-gray-50'
                        }`}
                        onClick={() => {
                          setSelectedTemplate(template)
                          setNewTemplate(template)
                          setIsEditing(true)
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Icon className="h-5 w-5 text-blue-600" />
                            <div>
                              <h4 className="font-medium">{template.name}</h4>
                              <p className="text-sm text-muted-foreground">
                                {templateTypes.find(t => t.value === template.type)?.label}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-1">
                            {template.isActive && (
                              <Badge variant="default" className="text-xs">Actif</Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleDuplicateTemplate(template)
                              }}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleDeleteTemplate(template.id)
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                  
                  {templates.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Aucun modèle créé</p>
                    </div>
                  )}
                </div>
                
                <Button
                  className="w-full mt-4"
                  onClick={() => {
                    setSelectedTemplate(null)
                    setNewTemplate({
                      name: '',
                      type: 'bulletin',
                      description: '',
                      header: printSettings.defaultHeader,
                      footer: printSettings.defaultFooter,
                      content: '',
                      pageSize: 'A4',
                      orientation: 'portrait',
                      margins: printSettings.defaultMargins,
                      isActive: true
                    })
                    setIsEditing(true)
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Nouveau modèle
                </Button>
              </CardContent>
            </Card>

            {/* Éditeur de modèle */}
            <Card>
              <CardHeader>
                <CardTitle>
                  {isEditing ? 'Modifier le modèle' : 'Nouveau modèle'}
                </CardTitle>
                <CardDescription>
                  Configurez les détails de votre modèle d'impression
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isEditing && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="templateName">Nom du modèle</Label>
                        <Input
                          id="templateName"
                          value={newTemplate.name || ''}
                          onChange={(e) => setNewTemplate({...newTemplate, name: e.target.value})}
                          placeholder="Ex: Bulletin trimestriel"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="templateType">Type de document</Label>
                        <Select
                          value={newTemplate.type}
                          onValueChange={(value) => setNewTemplate({...newTemplate, type: value as PrintTemplate['type']})}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {templateTypes.map((type) => {
                              const Icon = type.icon
                              return (
                                <SelectItem key={type.value} value={type.value}>
                                  <div className="flex items-center space-x-2">
                                    <Icon className="h-4 w-4" />
                                    <span>{type.label}</span>
                                  </div>
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="templateDescription">Description</Label>
                      <Input
                        id="templateDescription"
                        value={newTemplate.description || ''}
                        onChange={(e) => setNewTemplate({...newTemplate, description: e.target.value})}
                        placeholder="Description du modèle"
                      />
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label>Logo</Label>
                      <div className="flex items-center space-x-4">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="hidden"
                          id="logo-upload"
                        />
                        <label htmlFor="logo-upload">
                          <Button variant="outline" asChild>
                            <span className="cursor-pointer">
                              <Upload className="h-4 w-4 mr-2" />
                              Télécharger
                            </span>
                          </Button>
                        </label>
                        {(newTemplate.logo || selectedTemplate?.logo) && (
                          <div className="flex items-center space-x-2">
                            <img
                              src={newTemplate.logo || selectedTemplate?.logo}
                              alt="Logo"
                              className="h-8 w-8 object-contain"
                            />
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setNewTemplate({...newTemplate, logo: undefined})
                                if (selectedTemplate) {
                                  setSelectedTemplate({...selectedTemplate, logo: undefined})
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="templateHeader">Entête (HTML)</Label>
                      <Textarea
                        id="templateHeader"
                        value={newTemplate.header || ''}
                        onChange={(e) => setNewTemplate({...newTemplate, header: e.target.value})}
                        rows={4}
                        placeholder="HTML pour l'entête du document"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="templateFooter">Pied de page (HTML)</Label>
                      <Textarea
                        id="templateFooter"
                        value={newTemplate.footer || ''}
                        onChange={(e) => setNewTemplate({...newTemplate, footer: e.target.value})}
                        rows={4}
                        placeholder="HTML pour le pied de page du document"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="templateContent">Contenu (HTML avec variables)</Label>
                      <Textarea
                        id="templateContent"
                        value={newTemplate.content || ''}
                        onChange={(e) => setNewTemplate({...newTemplate, content: e.target.value})}
                        rows={6}
                        placeholder="Contenu du document avec variables comme {{student_name}}, {{grade}}, etc."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Format de page</Label>
                        <Select
                          value={newTemplate.pageSize}
                          onValueChange={(value) => setNewTemplate({...newTemplate, pageSize: value as PrintTemplate['pageSize']})}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A4">A4</SelectItem>
                            <SelectItem value="A3">A3</SelectItem>
                            <SelectItem value="Letter">Letter</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Orientation</Label>
                        <Select
                          value={newTemplate.orientation}
                          onValueChange={(value) => setNewTemplate({...newTemplate, orientation: value as PrintTemplate['orientation']})}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="portrait">Portrait</SelectItem>
                            <SelectItem value="landscape">Paysage</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Marges (mm)</Label>
                      <div className="grid grid-cols-4 gap-2">
                        <Input
                          type="number"
                          placeholder="Haut"
                          value={newTemplate.margins?.top || 20}
                          onChange={(e) => setNewTemplate({
                            ...newTemplate,
                            margins: {...(newTemplate.margins || {}), top: parseInt(e.target.value)}
                          })}
                        />
                        <Input
                          type="number"
                          placeholder="Droite"
                          value={newTemplate.margins?.right || 20}
                          onChange={(e) => setNewTemplate({
                            ...newTemplate,
                            margins: {...(newTemplate.margins || {}), right: parseInt(e.target.value)}
                          })}
                        />
                        <Input
                          type="number"
                          placeholder="Bas"
                          value={newTemplate.margins?.bottom || 20}
                          onChange={(e) => setNewTemplate({
                            ...newTemplate,
                            margins: {...(newTemplate.margins || {}), bottom: parseInt(e.target.value)}
                          })}
                        />
                        <Input
                          type="number"
                          placeholder="Gauche"
                          value={newTemplate.margins?.left || 20}
                          onChange={(e) => setNewTemplate({
                            ...newTemplate,
                            margins: {...(newTemplate.margins || {}), left: parseInt(e.target.value)}
                          })}
                        />
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={newTemplate.isActive || false}
                        onCheckedChange={(checked) => setNewTemplate({...newTemplate, isActive: checked})}
                      />
                      <Label>Modèle actif</Label>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setIsEditing(false)
                          setSelectedTemplate(null)
                        }}
                      >
                        Annuler
                      </Button>
                      <Button onClick={handleSaveTemplate} disabled={loading}>
                        <Save className="h-4 w-4 mr-2" />
                        {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                      </Button>
                    </div>
                  </>
                )}

                {!isEditing && (
                  <div className="text-center py-8 text-muted-foreground">
                    <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Sélectionnez un modèle à modifier ou créez-en un nouveau</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Onglet Paramètres */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Paramètres généraux d'impression</CardTitle>
              <CardDescription>
                Configurez les paramètres par défaut pour toutes les impressions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Apparence par défaut</h4>
                
                <div className="space-y-2">
                  <Label htmlFor="defaultHeader">Entête par défaut (HTML)</Label>
                  <Textarea
                    id="defaultHeader"
                    value={printSettings.defaultHeader}
                    onChange={(e) => setPrintSettings({...printSettings, defaultHeader: e.target.value})}
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="defaultFooter">Pied de page par défaut (HTML)</Label>
                  <Textarea
                    id="defaultFooter"
                    value={printSettings.defaultFooter}
                    onChange={(e) => setPrintSettings({...printSettings, defaultFooter: e.target.value})}
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Format de page par défaut</Label>
                    <Select
                      value={printSettings.defaultPageSize}
                      onValueChange={(value) => setPrintSettings({...printSettings, defaultPageSize: value as PrintSettings['defaultPageSize']})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A4">A4</SelectItem>
                        <SelectItem value="A3">A3</SelectItem>
                        <SelectItem value="Letter">Letter</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Orientation par défaut</Label>
                    <Select
                      value={printSettings.defaultOrientation}
                      onValueChange={(value) => setPrintSettings({...printSettings, defaultOrientation: value as PrintSettings['defaultOrientation']})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="portrait">Portrait</SelectItem>
                        <SelectItem value="landscape">Paysage</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="text-sm font-medium">Options d'impression</h4>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Inclure les notes</Label>
                      <p className="text-sm text-muted-foreground">Afficher les notes dans les documents</p>
                    </div>
                    <Switch
                      checked={printSettings.printGrades}
                      onCheckedChange={(checked) => setPrintSettings({...printSettings, printGrades: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Inclure les photos</Label>
                      <p className="text-sm text-muted-foreground">Afficher les photos des étudiants</p>
                    </div>
                    <Switch
                      checked={printSettings.printPhotos}
                      onCheckedChange={(checked) => setPrintSettings({...printSettings, printPhotos: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Inclure les signatures</Label>
                      <p className="text-sm text-muted-foreground">Ajouter des zones de signature</p>
                    </div>
                    <Switch
                      checked={printSettings.printSignatures}
                      onCheckedChange={(checked) => setPrintSettings({...printSettings, printSignatures: checked})}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="text-sm font-medium">Filigrane</h4>
                
                <div className="space-y-2">
                  <Label htmlFor="watermark">Texte du filigrane</Label>
                  <Input
                    id="watermark"
                    value={printSettings.watermark || ''}
                    onChange={(e) => setPrintSettings({...printSettings, watermark: e.target.value})}
                    placeholder="Ex: CONFIDENTIEL"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="watermarkOpacity">Opacité du filigrane</Label>
                  <Input
                    id="watermarkOpacity"
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={printSettings.watermarkOpacity}
                    onChange={(e) => setPrintSettings({...printSettings, watermarkOpacity: parseFloat(e.target.value)})}
                  />
                  <div className="text-sm text-muted-foreground">
                    {Math.round(printSettings.watermarkOpacity * 100)}%
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button onClick={handleSavePrintSettings} disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Onglet Aperçu */}
        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Aperçu d'impression</CardTitle>
              <CardDescription>
                Prévisualisez vos documents avant impression
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Sélectionner un modèle</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choisir un modèle" />
                      </SelectTrigger>
                      <SelectContent>
                        {templates.map((template) => {
                          const Icon = getTemplateIcon(template.type)
                          return (
                            <SelectItem key={template.id} value={template.id}>
                              <div className="flex items-center space-x-2">
                                <Icon className="h-4 w-4" />
                                <span>{template.name}</span>
                              </div>
                            </SelectItem>
                          )
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Type d'aperçu</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Type de document" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bulletin">Bulletin de notes</SelectItem>
                        <SelectItem value="attestation">Attestation</SelectItem>
                        <SelectItem value="facture">Facture</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="border rounded-lg p-4 bg-white" style={{minHeight: '600px'}}>
                  <div dangerouslySetInnerHTML={{__html: printSettings.defaultHeader}} />
                  <div className="my-8 p-4 border-2 border-dashed border-gray-300 rounded text-center text-gray-500">
                    <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Aperçu du document</p>
                    <p className="text-sm">Sélectionnez un modèle et un type de document pour prévisualiser</p>
                  </div>
                  <div dangerouslySetInnerHTML={{__html: printSettings.defaultFooter}} />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Télécharger PDF
                  </Button>
                  <Button>
                    <Printer className="h-4 w-4 mr-2" />
                    Imprimer
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Statut de sauvegarde */}
      {saveStatus !== 'idle' && (
        <div className="fixed bottom-4 right-4">
          <Card className={`p-4 ${
            saveStatus === 'success' ? 'bg-green-50 border-green-200' : 
            saveStatus === 'error' ? 'bg-red-50 border-red-200' : 
            'bg-blue-50 border-blue-200'
          }`}>
            <div className="flex items-center space-x-2">
              {saveStatus === 'success' && <Save className="h-4 w-4 text-green-600" />}
              {saveStatus === 'error' && <Trash2 className="h-4 w-4 text-red-600" />}
              {saveStatus === 'saving' && <Save className="h-4 w-4 text-blue-600 animate-spin" />}
              <span className={`text-sm font-medium ${
                saveStatus === 'success' ? 'text-green-800' : 
                saveStatus === 'error' ? 'text-red-800' : 
                'text-blue-800'
              }`}>
                {saveStatus === 'success' ? 'Modèle sauvegardé' : 
                 saveStatus === 'error' ? 'Erreur de sauvegarde' : 
                 'Sauvegarde en cours...'}
              </span>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}