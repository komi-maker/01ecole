'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Shield, 
  Key, 
  Lock, 
  Eye, 
  EyeOff,
  Smartphone,
  Mail,
  AlertTriangle,
  CheckCircle,
  Save,
  RotateCcw
} from 'lucide-react';
import { toast } from 'sonner';

export default function SecuritySettings() {
  const [isSaving, setIsSaving] = useState(false);
  const [showPasswords, setShowPasswords] = useState(false);
  const [formData, setFormData] = useState({
    // Password Policy
    minLength: '8',
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    passwordExpiry: '90',
    preventReuse: '5',
    
    // Session Security
    sessionTimeout: '30',
    maxConcurrentSessions: '3',
    requireReauth: true,
    reauthTimeout: '15',
    
    // Two-Factor Authentication
    enable2FA: false,
    require2FA: false,
    allowSMS2FA: true,
    allowEmail2FA: true,
    allowApp2FA: true,
    
    // Login Security
    maxLoginAttempts: '5',
    lockoutDuration: '15',
    requireCaptcha: false,
    allowRememberMe: true,
    rememberMeDuration: '7',
    
    // IP Security
    restrictIPAccess: false,
    allowedIPs: '',
    enableIPWhitelist: false,
    
    // Data Protection
    encryptData: true,
    enableAuditLog: true,
    logRetentionDays: '365',
    
    // Current Password Change
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Paramètres de sécurité sauvegardés avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde des paramètres');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePasswordChange = async () => {
    if (formData.newPassword !== formData.confirmPassword) {
      toast.error('Les mots de passe ne correspondent pas');
      return;
    }
    
    if (formData.newPassword.length < parseInt(formData.minLength)) {
      toast.error(`Le mot de passe doit contenir au moins ${formData.minLength} caractères`);
      return;
    }

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Mot de passe modifié avec succès');
      setFormData(prev => ({
        ...prev,
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      }));
    } catch (error) {
      toast.error('Erreur lors de la modification du mot de passe');
    }
  };

  const getPasswordStrength = (password: string) => {
    if (!password) return { score: 0, text: '', color: '' };
    
    let score = 0;
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^a-zA-Z0-9]/.test(password)) score++;

    const levels = [
      { score: 0, text: 'Très faible', color: 'bg-red-500' },
      { score: 1, text: 'Faible', color: 'bg-orange-500' },
      { score: 2, text: 'Moyen', color: 'bg-yellow-500' },
      { score: 3, text: 'Bon', color: 'bg-blue-500' },
      { score: 4, text: 'Fort', color: 'bg-green-500' },
      { score: 5, text: 'Très fort', color: 'bg-green-600' }
    ];

    return levels[Math.min(score, 5)];
  };

  const passwordStrength = getPasswordStrength(formData.newPassword);

  return (
    <div className="space-y-6">
      {/* Password Policy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Politique de mot de passe
          </CardTitle>
          <CardDescription>
            Définissez les exigences de sécurité pour les mots de passe
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="minLength">Longueur minimale</Label>
              <Select value={formData.minLength} onValueChange={(value) => handleInputChange('minLength', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="6">6 caractères</SelectItem>
                  <SelectItem value="8">8 caractères</SelectItem>
                  <SelectItem value="10">10 caractères</SelectItem>
                  <SelectItem value="12">12 caractères</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="passwordExpiry">Expiration du mot de passe (jours)</Label>
              <Select value={formData.passwordExpiry} onValueChange={(value) => handleInputChange('passwordExpiry', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 jours</SelectItem>
                  <SelectItem value="60">60 jours</SelectItem>
                  <SelectItem value="90">90 jours</SelectItem>
                  <SelectItem value="180">180 jours</SelectItem>
                  <SelectItem value="365">365 jours</SelectItem>
                  <SelectItem value="0">Jamais</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="preventReuse">Empêcher la réutilisation des</Label>
              <Select value={formData.preventReuse} onValueChange={(value) => handleInputChange('preventReuse', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 derniers mots de passe</SelectItem>
                  <SelectItem value="5">5 derniers mots de passe</SelectItem>
                  <SelectItem value="10">10 derniers mots de passe</SelectItem>
                  <SelectItem value="0">Ne pas vérifier</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="requireUppercase">Exiger des majuscules</Label>
              <Switch
                id="requireUppercase"
                checked={formData.requireUppercase}
                onCheckedChange={(checked) => handleInputChange('requireUppercase', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="requireLowercase">Exiger des minuscules</Label>
              <Switch
                id="requireLowercase"
                checked={formData.requireLowercase}
                onCheckedChange={(checked) => handleInputChange('requireLowercase', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="requireNumbers">Exiger des chiffres</Label>
              <Switch
                id="requireNumbers"
                checked={formData.requireNumbers}
                onCheckedChange={(checked) => handleInputChange('requireNumbers', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="requireSpecialChars">Exiger des caractères spéciaux</Label>
              <Switch
                id="requireSpecialChars"
                checked={formData.requireSpecialChars}
                onCheckedChange={(checked) => handleInputChange('requireSpecialChars', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Change Password */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Changer votre mot de passe
          </CardTitle>
          <CardDescription>
            Modifiez votre mot de passe actuel
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="currentPassword">Mot de passe actuel</Label>
            <div className="relative">
              <Input
                id="currentPassword"
                type={showPasswords ? "text" : "password"}
                value={formData.currentPassword}
                onChange={(e) => handleInputChange('currentPassword', e.target.value)}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPasswords(!showPasswords)}
              >
                {showPasswords ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="newPassword">Nouveau mot de passe</Label>
            <div className="relative">
              <Input
                id="newPassword"
                type={showPasswords ? "text" : "password"}
                value={formData.newPassword}
                onChange={(e) => handleInputChange('newPassword', e.target.value)}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPasswords(!showPasswords)}
              >
                {showPasswords ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
            {formData.newPassword && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${passwordStrength.color}`}
                      style={{ width: `${(passwordStrength.score / 5) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm text-muted-foreground">{passwordStrength.text}</span>
                </div>
              </div>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirmer le nouveau mot de passe</Label>
            <div className="relative">
              <Input
                id="confirmPassword"
                type={showPasswords ? "text" : "password"}
                value={formData.confirmPassword}
                onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPasswords(!showPasswords)}
              >
                {showPasswords ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          <Button onClick={handlePasswordChange} className="w-full">
            <Lock className="mr-2 h-4 w-4" />
            Changer le mot de passe
          </Button>
        </CardContent>
      </Card>

      {/* Session Security */}
      <Card>
        <CardHeader>
          <CardTitle>Sécurité de session</CardTitle>
          <CardDescription>
            Configurez les paramètres de sécurité des sessions utilisateur
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Délai d'expiration (minutes)</Label>
              <Select value={formData.sessionTimeout} onValueChange={(value) => handleInputChange('sessionTimeout', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 heure</SelectItem>
                  <SelectItem value="120">2 heures</SelectItem>
                  <SelectItem value="240">4 heures</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxConcurrentSessions">Sessions simultanées maximales</Label>
              <Select value={formData.maxConcurrentSessions} onValueChange={(value) => handleInputChange('maxConcurrentSessions', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 session</SelectItem>
                  <SelectItem value="3">3 sessions</SelectItem>
                  <SelectItem value="5">5 sessions</SelectItem>
                  <SelectItem value="10">10 sessions</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="requireReauth">Exiger une réauthentification</Label>
                <p className="text-sm text-muted-foreground">
                  Demander une nouvelle authentification pour les actions sensibles
                </p>
              </div>
              <Switch
                id="requireReauth"
                checked={formData.requireReauth}
                onCheckedChange={(checked) => handleInputChange('requireReauth', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="allowRememberMe">Autoriser "Se souvenir de moi"</Label>
              <Switch
                id="allowRememberMe"
                checked={formData.allowRememberMe}
                onCheckedChange={(checked) => handleInputChange('allowRememberMe', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Two-Factor Authentication */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Authentification à deux facteurs
          </CardTitle>
          <CardDescription>
            Configurez l'authentification à deux facteurs pour une sécurité renforcée
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enable2FA">Activer la 2FA</Label>
                <p className="text-sm text-muted-foreground">
                  Permettre aux utilisateurs d'activer l'authentification à deux facteurs
                </p>
              </div>
              <Switch
                id="enable2FA"
                checked={formData.enable2FA}
                onCheckedChange={(checked) => handleInputChange('enable2FA', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="require2FA">Rendre la 2FA obligatoire</Label>
                <p className="text-sm text-muted-foreground">
                  Tous les utilisateurs doivent configurer la 2FA
                </p>
              </div>
              <Switch
                id="require2FA"
                checked={formData.require2FA}
                onCheckedChange={(checked) => handleInputChange('require2FA', checked)}
              />
            </div>
          </div>
          {formData.enable2FA && (
            <div className="space-y-3">
              <Label>Méthodes 2FA autorisées</Label>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <Label htmlFor="allowEmail2FA">Email</Label>
                </div>
                <Switch
                  id="allowEmail2FA"
                  checked={formData.allowEmail2FA}
                  onCheckedChange={(checked) => handleInputChange('allowEmail2FA', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4" />
                  <Label htmlFor="allowSMS2FA">SMS</Label>
                </div>
                <Switch
                  id="allowSMS2FA"
                  checked={formData.allowSMS2FA}
                  onCheckedChange={(checked) => handleInputChange('allowSMS2FA', checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4" />
                  <Label htmlFor="allowApp2FA">Application d'authentification</Label>
                </div>
                <Switch
                  id="allowApp2FA"
                  checked={formData.allowApp2FA}
                  onCheckedChange={(checked) => handleInputChange('allowApp2FA', checked)}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Login Security */}
      <Card>
        <CardHeader>
          <CardTitle>Sécurité de connexion</CardTitle>
          <CardDescription>
            Configurez les paramètres de sécurité pour les tentatives de connexion
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxLoginAttempts">Tentatives de connexion maximales</Label>
              <Select value={formData.maxLoginAttempts} onValueChange={(value) => handleInputChange('maxLoginAttempts', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 tentatives</SelectItem>
                  <SelectItem value="5">5 tentatives</SelectItem>
                  <SelectItem value="10">10 tentatives</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="lockoutDuration">Durée de verrouillage (minutes)</Label>
              <Select value={formData.lockoutDuration} onValueChange={(value) => handleInputChange('lockoutDuration', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 minutes</SelectItem>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 heure</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="requireCaptcha">Exiger CAPTCHA</Label>
                <p className="text-sm text-muted-foreground">
                  Ajouter une vérification CAPTCHA aux tentatives de connexion
                </p>
              </div>
              <Switch
                id="requireCaptcha"
                checked={formData.requireCaptcha}
                onCheckedChange={(checked) => handleInputChange('requireCaptcha', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Protection */}
      <Card>
        <CardHeader>
          <CardTitle>Protection des données</CardTitle>
          <CardDescription>
            Configurez la protection et l'audit des données
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="encryptData">Chiffrer les données sensibles</Label>
                <p className="text-sm text-muted-foreground">
                  Chiffrer les données sensibles dans la base de données
                </p>
              </div>
              <Switch
                id="encryptData"
                checked={formData.encryptData}
                onCheckedChange={(checked) => handleInputChange('encryptData', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableAuditLog">Activer l'audit des logs</Label>
                <p className="text-sm text-muted-foreground">
                  Enregistrer toutes les actions sensibles dans les logs
                </p>
              </div>
              <Switch
                id="enableAuditLog"
                checked={formData.enableAuditLog}
                onCheckedChange={(checked) => handleInputChange('enableAuditLog', checked)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="logRetentionDays">Durée de rétention des logs (jours)</Label>
            <Select value={formData.logRetentionDays} onValueChange={(value) => handleInputChange('logRetentionDays', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">30 jours</SelectItem>
                <SelectItem value="90">90 jours</SelectItem>
                <SelectItem value="180">180 jours</SelectItem>
                <SelectItem value="365">1 an</SelectItem>
                <SelectItem value="1095">3 ans</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Security Status */}
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <span>Votre configuration de sécurité est bonne. Pensez à activer l'authentification à deux facteurs pour une sécurité renforcée.</span>
          </div>
        </AlertDescription>
      </Alert>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setFormData({
          minLength: '8',
          requireUppercase: true,
          requireLowercase: true,
          requireNumbers: true,
          requireSpecialChars: true,
          passwordExpiry: '90',
          preventReuse: '5',
          sessionTimeout: '30',
          maxConcurrentSessions: '3',
          requireReauth: true,
          reauthTimeout: '15',
          enable2FA: false,
          require2FA: false,
          allowSMS2FA: true,
          allowEmail2FA: true,
          allowApp2FA: true,
          maxLoginAttempts: '5',
          lockoutDuration: '15',
          requireCaptcha: false,
          allowRememberMe: true,
          rememberMeDuration: '7',
          restrictIPAccess: false,
          allowedIPs: '',
          enableIPWhitelist: false,
          encryptData: true,
          enableAuditLog: true,
          logRetentionDays: '365',
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        })}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Réinitialiser
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
        </Button>
      </div>
    </div>
  );
}