'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  Database, 
  Server, 
  HardDrive,
  Shield,
  Activity,
  Download,
  Upload,
  RefreshCw,
  Save,
  RotateCcw,
  AlertTriangle,
  CheckCircle,
  Clock,
  Zap,
  Users,
  Globe,
  Settings,
  Trash2,
  FileText,
  Archive
} from 'lucide-react';
import { toast } from 'sonner';

export default function SystemSettings() {
  const [isSaving, setIsSaving] = useState(false);
  const [isBackupRunning, setIsBackupRunning] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [formData, setFormData] = useState({
    // Database Settings
    dbHost: 'localhost',
    dbPort: '5432',
    dbName: 'ecoleplus',
    dbUsername: 'ecoleplus_user',
    dbPassword: '',
    dbSSL: false,
    dbConnectionPool: '10',
    dbTimeout: '30',
    
    // Backup Settings
    autoBackup: true,
    backupFrequency: 'daily',
    backupRetention: '30',
    backupLocation: 'local',
    backupEncryption: true,
    backupCompression: true,
    cloudBackup: false,
    cloudProvider: 'aws',
    cloudBucket: '',
    cloudAccessKey: '',
    cloudSecretKey: '',
    
    // Performance Settings
    cacheEnabled: true,
    cacheType: 'redis',
    cacheTTL: '3600',
    cacheSize: '100',
    enableCompression: true,
    compressionLevel: '6',
    enableCDN: false,
    cdnUrl: '',
    
    // Security Settings
    enableFirewall: true,
    enableRateLimit: true,
    rateLimitRequests: '100',
    rateLimitWindow: '60',
    enableCSRF: true,
    enableXSS: true,
    enableSQLInjection: true,
    
    // Logging Settings
    enableLogging: true,
    logLevel: 'info',
    logRetention: '90',
    logFormat: 'json',
    enableAuditLog: true,
    auditLogRetention: '365',
    
    // Maintenance Settings
    maintenanceMode: false,
    maintenanceMessage: 'Le système est en maintenance. Nous serons de retour bientôt.',
    scheduledMaintenance: false,
    maintenanceStartTime: '',
    maintenanceEndTime: '',
    notifyMaintenance: true,
    
    // System Limits
    maxFileSize: '10',
    maxConcurrentUsers: '100',
    maxLoginAttempts: '5',
    sessionTimeout: '30',
    passwordMinLength: '8',
    
    // API Settings
    enableAPI: true,
    apiRateLimit: '1000',
    apiTimeout: '30',
    enableWebhooks: false,
    webhookSecret: '',
    
    // Email Settings
    emailEnabled: true,
    emailFrom: 'noreply@ecoleplus.fr',
    emailReplyTo: 'support@ecoleplus.fr',
    smtpHost: 'smtp.gmail.com',
    smtpPort: '587',
    smtpUsername: '',
    smtpPassword: '',
    smtpTLS: true
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Paramètres système sauvegardés avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde des paramètres');
    } finally {
      setIsSaving(false);
    }
  };

  const handleBackup = async () => {
    setIsBackupRunning(true);
    try {
      // Simulate backup process
      await new Promise(resolve => setTimeout(resolve, 3000));
      toast.success('Sauvegarde effectuée avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setIsBackupRunning(false);
    }
  };

  const handleRestore = async () => {
    setIsRestoring(true);
    try {
      // Simulate restore process
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast.success('Restauration effectuée avec succès');
    } catch (error) {
      toast.error('Erreur lors de la restauration');
    } finally {
      setIsRestoring(false);
    }
  };

  const handleClearCache = async () => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Cache vidé avec succès');
    } catch (error) {
      toast.error('Erreur lors du vidage du cache');
    }
  };

  const handleOptimizeDatabase = async () => {
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast.success('Base de données optimisée avec succès');
    } catch (error) {
      toast.error('Erreur lors de l\'optimisation de la base de données');
    }
  };

  // Mock system stats
  const systemStats = {
    cpuUsage: 45,
    memoryUsage: 62,
    diskUsage: 78,
    activeConnections: 23,
    uptime: '15 jours',
    lastBackup: '2024-01-15 14:30',
    databaseSize: '2.3 GB',
    cacheHitRate: '94%'
  };

  return (
    <div className="space-y-6">
      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            État du système
          </CardTitle>
          <CardDescription>
            Vue d'ensemble de l'état actuel du système
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">CPU</span>
                <span className="text-sm text-muted-foreground">{systemStats.cpuUsage}%</span>
              </div>
              <Progress value={systemStats.cpuUsage} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Mémoire</span>
                <span className="text-sm text-muted-foreground">{systemStats.memoryUsage}%</span>
              </div>
              <Progress value={systemStats.memoryUsage} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Disque</span>
                <span className="text-sm text-muted-foreground">{systemStats.diskUsage}%</span>
              </div>
              <Progress value={systemStats.diskUsage} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Cache</span>
                <span className="text-sm text-muted-foreground">{systemStats.cacheHitRate}</span>
              </div>
              <Progress value={94} className="h-2" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Connexions actives: {systemStats.activeConnections}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Temps d'activité: {systemStats.uptime}</span>
            </div>
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Taille BDD: {systemStats.databaseSize}</span>
            </div>
            <div className="flex items-center gap-2">
              <Archive className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Dernière sauvegarde: {systemStats.lastBackup}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Database Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Base de données
          </CardTitle>
          <CardDescription>
            Configurez les paramètres de la base de données
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dbHost">Hôte de la base de données</Label>
              <Input
                id="dbHost"
                value={formData.dbHost}
                onChange={(e) => handleInputChange('dbHost', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dbPort">Port de la base de données</Label>
              <Input
                id="dbPort"
                value={formData.dbPort}
                onChange={(e) => handleInputChange('dbPort', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dbName">Nom de la base de données</Label>
              <Input
                id="dbName"
                value={formData.dbName}
                onChange={(e) => handleInputChange('dbName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dbUsername">Nom d'utilisateur</Label>
              <Input
                id="dbUsername"
                value={formData.dbUsername}
                onChange={(e) => handleInputChange('dbUsername', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dbPassword">Mot de passe</Label>
              <Input
                id="dbPassword"
                type="password"
                value={formData.dbPassword}
                onChange={(e) => handleInputChange('dbPassword', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dbConnectionPool">Taille du pool de connexions</Label>
              <Select value={formData.dbConnectionPool} onValueChange={(value) => handleInputChange('dbConnectionPool', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 connexions</SelectItem>
                  <SelectItem value="10">10 connexions</SelectItem>
                  <SelectItem value="20">20 connexions</SelectItem>
                  <SelectItem value="50">50 connexions</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="dbSSL">Utiliser SSL</Label>
                <p className="text-sm text-muted-foreground">
                  Activer le chiffrement SSL pour les connexions à la base de données
                </p>
              </div>
              <Switch
                id="dbSSL"
                checked={formData.dbSSL}
                onCheckedChange={(checked) => handleInputChange('dbSSL', checked)}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleOptimizeDatabase} variant="outline">
              <Zap className="mr-2 h-4 w-4" />
              Optimiser la base de données
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Backup Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Archive className="h-5 w-5" />
            Sauvegarde et restauration
          </CardTitle>
          <CardDescription>
            Configurez les paramètres de sauvegarde automatique
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="backupFrequency">Fréquence de sauvegarde</Label>
              <Select value={formData.backupFrequency} onValueChange={(value) => handleInputChange('backupFrequency', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Toutes les heures</SelectItem>
                  <SelectItem value="daily">Quotidienne</SelectItem>
                  <SelectItem value="weekly">Hebdomadaire</SelectItem>
                  <SelectItem value="monthly">Mensuelle</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="backupRetention">Période de rétention (jours)</Label>
              <Select value={formData.backupRetention} onValueChange={(value) => handleInputChange('backupRetention', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 jours</SelectItem>
                  <SelectItem value="30">30 jours</SelectItem>
                  <SelectItem value="90">90 jours</SelectItem>
                  <SelectItem value="365">1 an</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="backupLocation">Emplacement de sauvegarde</Label>
              <Select value={formData.backupLocation} onValueChange={(value) => handleInputChange('backupLocation', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="local">Local</SelectItem>
                  <SelectItem value="cloud">Cloud</SelectItem>
                  <SelectItem value="both">Les deux</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cloudProvider">Fournisseur cloud</Label>
              <Select value={formData.cloudProvider} onValueChange={(value) => handleInputChange('cloudProvider', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aws">AWS S3</SelectItem>
                  <SelectItem value="google">Google Cloud</SelectItem>
                  <SelectItem value="azure">Azure Blob</SelectItem>
                  <SelectItem value="dropbox">Dropbox</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="autoBackup">Sauvegarde automatique</Label>
                <p className="text-sm text-muted-foreground">
                  Activer les sauvegardes automatiques régulières
                </p>
              </div>
              <Switch
                id="autoBackup"
                checked={formData.autoBackup}
                onCheckedChange={(checked) => handleInputChange('autoBackup', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="backupEncryption">Chiffrer les sauvegardes</Label>
                <p className="text-sm text-muted-foreground">
                  Chiffrer les fichiers de sauvegarde pour la sécurité
                </p>
              </div>
              <Switch
                id="backupEncryption"
                checked={formData.backupEncryption}
                onCheckedChange={(checked) => handleInputChange('backupEncryption', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="backupCompression">Compresser les sauvegardes</Label>
                <p className="text-sm text-muted-foreground">
                  Compresser les fichiers de sauvegarde pour économiser de l'espace
                </p>
              </div>
              <Switch
                id="backupCompression"
                checked={formData.backupCompression}
                onCheckedChange={(checked) => handleInputChange('backupCompression', checked)}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleBackup} disabled={isBackupRunning}>
              <Download className="mr-2 h-4 w-4" />
              {isBackupRunning ? 'Sauvegarde en cours...' : 'Sauvegarder maintenant'}
            </Button>
            <Button onClick={handleRestore} disabled={isRestoring} variant="outline">
              <Upload className="mr-2 h-4 w-4" />
              {isRestoring ? 'Restauration en cours...' : 'Restaurer'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Performance Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Performance
          </CardTitle>
          <CardDescription>
            Optimisez les performances du système
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cacheType">Type de cache</Label>
              <Select value={formData.cacheType} onValueChange={(value) => handleInputChange('cacheType', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="redis">Redis</SelectItem>
                  <SelectItem value="memcached">Memcached</SelectItem>
                  <SelectItem value="file">Fichier</SelectItem>
                  <SelectItem value="memory">Mémoire</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cacheTTL">Durée de vie du cache (secondes)</Label>
              <Input
                id="cacheTTL"
                value={formData.cacheTTL}
                onChange={(e) => handleInputChange('cacheTTL', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cacheSize">Taille du cache (MB)</Label>
              <Input
                id="cacheSize"
                value={formData.cacheSize}
                onChange={(e) => handleInputChange('cacheSize', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="compressionLevel">Niveau de compression</Label>
              <Select value={formData.compressionLevel} onValueChange={(value) => handleInputChange('compressionLevel', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Rapide</SelectItem>
                  <SelectItem value="6">Équilibré</SelectItem>
                  <SelectItem value="9">Maximum</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="cacheEnabled">Activer le cache</Label>
                <p className="text-sm text-muted-foreground">
                  Activer le cache pour améliorer les performances
                </p>
              </div>
              <Switch
                id="cacheEnabled"
                checked={formData.cacheEnabled}
                onCheckedChange={(checked) => handleInputChange('cacheEnabled', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableCompression">Activer la compression</Label>
                <p className="text-sm text-muted-foreground">
                  Compresser les réponses pour réduire la bande passante
                </p>
              </div>
              <Switch
                id="enableCompression"
                checked={formData.enableCompression}
                onCheckedChange={(checked) => handleInputChange('enableCompression', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableCDN">Activer le CDN</Label>
                <p className="text-sm text-muted-foreground">
                  Utiliser un CDN pour les ressources statiques
                </p>
              </div>
              <Switch
                id="enableCDN"
                checked={formData.enableCDN}
                onCheckedChange={(checked) => handleInputChange('enableCDN', checked)}
              />
            </div>
          </div>
          {formData.enableCDN && (
            <div className="space-y-2">
              <Label htmlFor="cdnUrl">URL du CDN</Label>
              <Input
                id="cdnUrl"
                value={formData.cdnUrl}
                onChange={(e) => handleInputChange('cdnUrl', e.target.value)}
                placeholder="https://cdn.example.com"
              />
            </div>
          )}
          <Button onClick={handleClearCache} variant="outline">
            <Trash2 className="mr-2 h-4 w-4" />
            Vider le cache
          </Button>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Sécurité
          </CardTitle>
          <CardDescription>
            Configurez les paramètres de sécurité du système
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="rateLimitRequests">Limite de taux (requêtes/minute)</Label>
              <Input
                id="rateLimitRequests"
                value={formData.rateLimitRequests}
                onChange={(e) => handleInputChange('rateLimitRequests', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rateLimitWindow">Fenêtre de temps (secondes)</Label>
              <Input
                id="rateLimitWindow"
                value={formData.rateLimitWindow}
                onChange={(e) => handleInputChange('rateLimitWindow', e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableFirewall">Activer le pare-feu</Label>
                <p className="text-sm text-muted-foreground">
                  Activer le pare-feu applicatif
                </p>
              </div>
              <Switch
                id="enableFirewall"
                checked={formData.enableFirewall}
                onCheckedChange={(checked) => handleInputChange('enableFirewall', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableRateLimit">Activer la limitation de taux</Label>
                <p className="text-sm text-muted-foreground">
                  Limiter le nombre de requêtes par utilisateur
                </p>
              </div>
              <Switch
                id="enableRateLimit"
                checked={formData.enableRateLimit}
                onCheckedChange={(checked) => handleInputChange('enableRateLimit', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableCSRF">Activer la protection CSRF</Label>
                <p className="text-sm text-muted-foreground">
                  Protéger contre les attaques CSRF
                </p>
              </div>
              <Switch
                id="enableCSRF"
                checked={formData.enableCSRF}
                onCheckedChange={(checked) => handleInputChange('enableCSRF', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableXSS">Activer la protection XSS</Label>
                <p className="text-sm text-muted-foreground">
                  Protéger contre les attaques XSS
                </p>
              </div>
              <Switch
                id="enableXSS"
                checked={formData.enableXSS}
                onCheckedChange={(checked) => handleInputChange('enableXSS', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableSQLInjection">Activer la protection SQL Injection</Label>
                <p className="text-sm text-muted-foreground">
                  Protéger contre les injections SQL
                </p>
              </div>
              <Switch
                id="enableSQLInjection"
                checked={formData.enableSQLInjection}
                onCheckedChange={(checked) => handleInputChange('enableSQLInjection', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logging Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Journalisation
          </CardTitle>
          <CardDescription>
            Configurez les paramètres de journalisation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="logLevel">Niveau de journalisation</Label>
              <Select value={formData.logLevel} onValueChange={(value) => handleInputChange('logLevel', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="debug">Debug</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="logRetention">Période de rétention (jours)</Label>
              <Select value={formData.logRetention} onValueChange={(value) => handleInputChange('logRetention', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 jours</SelectItem>
                  <SelectItem value="30">30 jours</SelectItem>
                  <SelectItem value="90">90 jours</SelectItem>
                  <SelectItem value="365">1 an</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="logFormat">Format des logs</Label>
              <Select value={formData.logFormat} onValueChange={(value) => handleInputChange('logFormat', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="text">Texte</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="auditLogRetention">Rétention logs d'audit (jours)</Label>
              <Select value={formData.auditLogRetention} onValueChange={(value) => handleInputChange('auditLogRetention', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="90">90 jours</SelectItem>
                  <SelectItem value="365">1 an</SelectItem>
                  <SelectItem value="1095">3 ans</SelectItem>
                  <SelectItem value="3650">10 ans</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableLogging">Activer la journalisation</Label>
                <p className="text-sm text-muted-foreground">
                  Activer la journalisation des événements système
                </p>
              </div>
              <Switch
                id="enableLogging"
                checked={formData.enableLogging}
                onCheckedChange={(checked) => handleInputChange('enableLogging', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableAuditLog">Activer les logs d'audit</Label>
                <p className="text-sm text-muted-foreground">
                  Journaliser toutes les actions sensibles
                </p>
              </div>
              <Switch
                id="enableAuditLog"
                checked={formData.enableAuditLog}
                onCheckedChange={(checked) => handleInputChange('enableAuditLog', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Maintenance Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Maintenance</CardTitle>
          <CardDescription>
            Configurez les paramètres de maintenance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="maintenanceMode">Mode maintenance</Label>
                <p className="text-sm text-muted-foreground">
                  Activer le mode maintenance pour les utilisateurs
                </p>
              </div>
              <Switch
                id="maintenanceMode"
                checked={formData.maintenanceMode}
                onCheckedChange={(checked) => handleInputChange('maintenanceMode', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="scheduledMaintenance">Maintenance planifiée</Label>
                <p className="text-sm text-muted-foreground">
                  Planifier des maintenances automatiques
                </p>
              </div>
              <Switch
                id="scheduledMaintenance"
                checked={formData.scheduledMaintenance}
                onCheckedChange={(checked) => handleInputChange('scheduledMaintenance', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifyMaintenance">Notifier la maintenance</Label>
                <p className="text-sm text-muted-foreground">
                  Envoyer des notifications avant la maintenance
                </p>
              </div>
              <Switch
                id="notifyMaintenance"
                checked={formData.notifyMaintenance}
                onCheckedChange={(checked) => handleInputChange('notifyMaintenance', checked)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="maintenanceMessage">Message de maintenance</Label>
            <textarea
              id="maintenanceMessage"
              className="w-full h-20 p-3 border rounded-md"
              value={formData.maintenanceMessage}
              onChange={(e) => handleInputChange('maintenanceMessage', e.target.value)}
              placeholder="Message affiché aux utilisateurs pendant la maintenance"
            />
          </div>
          {formData.scheduledMaintenance && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="maintenanceStartTime">Heure de début</Label>
                <Input
                  id="maintenanceStartTime"
                  type="datetime-local"
                  value={formData.maintenanceStartTime}
                  onChange={(e) => handleInputChange('maintenanceStartTime', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="maintenanceEndTime">Heure de fin</Label>
                <Input
                  id="maintenanceEndTime"
                  type="datetime-local"
                  value={formData.maintenanceEndTime}
                  onChange={(e) => handleInputChange('maintenanceEndTime', e.target.value)}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* System Limits */}
      <Card>
        <CardHeader>
          <CardTitle>Limites système</CardTitle>
          <CardDescription>
            Configurez les limites et quotas du système
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxFileSize">Taille maximale des fichiers (MB)</Label>
              <Input
                id="maxFileSize"
                value={formData.maxFileSize}
                onChange={(e) => handleInputChange('maxFileSize', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxConcurrentUsers">Utilisateurs simultanés maximum</Label>
              <Input
                id="maxConcurrentUsers"
                value={formData.maxConcurrentUsers}
                onChange={(e) => handleInputChange('maxConcurrentUsers', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxLoginAttempts">Tentatives de connexion maximum</Label>
              <Input
                id="maxLoginAttempts"
                value={formData.maxLoginAttempts}
                onChange={(e) => handleInputChange('maxLoginAttempts', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Délai d'expiration de session (minutes)</Label>
              <Input
                id="sessionTimeout"
                value={formData.sessionTimeout}
                onChange={(e) => handleInputChange('sessionTimeout', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="passwordMinLength">Longueur minimale du mot de passe</Label>
              <Input
                id="passwordMinLength"
                value={formData.passwordMinLength}
                onChange={(e) => handleInputChange('passwordMinLength', e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Alerts */}
      {systemStats.diskUsage > 80 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            L'utilisation du disque est élevée ({systemStats.diskUsage}%). Pensez à nettoyer les anciens fichiers ou à augmenter l'espace de stockage.
          </AlertDescription>
        </Alert>
      )}

      {systemStats.memoryUsage > 80 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            L'utilisation de la mémoire est élevée ({systemStats.memoryUsage}%). Pensez à optimiser les applications ou à augmenter la mémoire RAM.
          </AlertDescription>
        </Alert>
      )}

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setFormData({
          dbHost: 'localhost',
          dbPort: '5432',
          dbName: 'ecoleplus',
          dbUsername: 'ecoleplus_user',
          dbPassword: '',
          dbSSL: false,
          dbConnectionPool: '10',
          dbTimeout: '30',
          autoBackup: true,
          backupFrequency: 'daily',
          backupRetention: '30',
          backupLocation: 'local',
          backupEncryption: true,
          backupCompression: true,
          cloudBackup: false,
          cloudProvider: 'aws',
          cloudBucket: '',
          cloudAccessKey: '',
          cloudSecretKey: '',
          cacheEnabled: true,
          cacheType: 'redis',
          cacheTTL: '3600',
          cacheSize: '100',
          enableCompression: true,
          compressionLevel: '6',
          enableCDN: false,
          cdnUrl: '',
          enableFirewall: true,
          enableRateLimit: true,
          rateLimitRequests: '100',
          rateLimitWindow: '60',
          enableCSRF: true,
          enableXSS: true,
          enableSQLInjection: true,
          enableLogging: true,
          logLevel: 'info',
          logRetention: '90',
          logFormat: 'json',
          enableAuditLog: true,
          auditLogRetention: '365',
          maintenanceMode: false,
          maintenanceMessage: 'Le système est en maintenance. Nous serons de retour bientôt.',
          scheduledMaintenance: false,
          maintenanceStartTime: '',
          maintenanceEndTime: '',
          notifyMaintenance: true,
          maxFileSize: '10',
          maxConcurrentUsers: '100',
          maxLoginAttempts: '5',
          sessionTimeout: '30',
          passwordMinLength: '8',
          enableAPI: true,
          apiRateLimit: '1000',
          apiTimeout: '30',
          enableWebhooks: false,
          webhookSecret: '',
          emailEnabled: true,
          emailFrom: 'noreply@ecoleplus.fr',
          emailReplyTo: 'support@ecoleplus.fr',
          smtpHost: 'smtp.gmail.com',
          smtpPort: '587',
          smtpUsername: '',
          smtpPassword: '',
          smtpTLS: true
        })}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Réinitialiser
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
        </Button>
      </div>
    </div>
  );
}