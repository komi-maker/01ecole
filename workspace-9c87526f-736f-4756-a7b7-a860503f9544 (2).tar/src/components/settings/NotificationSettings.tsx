'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  Bell, 
  Mail, 
  Smartphone,
  MessageSquare,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Save,
  RotateCcw,
  Volume2,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';

export default function NotificationSettings() {
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    // Email Notifications
    emailEnabled: true,
    emailAttendance: true,
    emailGrades: true,
    emailPayments: true,
    emailAnnouncements: true,
    emailSystem: false,
    
    // SMS Notifications
    smsEnabled: false,
    smsAttendance: false,
    smsGrades: false,
    smsPayments: true,
    smsEmergency: true,
    
    // Push Notifications
    pushEnabled: true,
    pushAttendance: true,
    pushGrades: true,
    pushPayments: true,
    pushAnnouncements: true,
    pushMessages: true,
    
    // In-App Notifications
    inAppEnabled: true,
    inAppAttendance: true,
    inAppGrades: true,
    inAppPayments: true,
    inAppAnnouncements: true,
    inAppMessages: true,
    inAppSystem: true,
    
    // Notification Preferences
    digestMode: false,
    digestFrequency: 'daily',
    quietHours: true,
    quietStart: '22:00',
    quietEnd: '07:00',
    soundEnabled: true,
    vibrationEnabled: true,
    
    // Email Settings
    smtpHost: 'smtp.gmail.com',
    smtpPort: '587',
    smtpUsername: 'notifications@ecoleplus.fr',
    smtpPassword: '',
    smtpUseTLS: true,
    
    // SMS Settings
    smsProvider: 'twilio',
    smsApiKey: '',
    smsApiSecret: '',
    smsSenderNumber: '+33612345678',
    
    // Templates
    attendanceTemplate: 'Votre enfant {studentName} était {status} aujourd\'hui.',
    gradeTemplate: 'Nouvelle note de {grade}/{max} en {subject} pour {studentName}.',
    paymentTemplate: 'Paiement de {amount}€ reçu pour {studentName}. {status}',
    announcementTemplate: 'Nouvelle annonce : {title}'
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Paramètres de notification sauvegardés avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde des paramètres');
    } finally {
      setIsSaving(false);
    }
  };

  const testNotification = async (type: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(`Notification de test ${type} envoyée avec succès`);
    } catch (error) {
      toast.error('Erreur lors de l\'envoi de la notification de test');
    }
  };

  const notificationCategories = [
    {
      id: 'attendance',
      title: 'Présence',
      icon: Calendar,
      description: 'Notifications relatives aux présences et absences',
      color: 'bg-blue-500'
    },
    {
      id: 'grades',
      title: 'Notes',
      icon: CheckCircle,
      description: 'Notifications relatives aux notes et évaluations',
      color: 'bg-green-500'
    },
    {
      id: 'payments',
      title: 'Paiements',
      icon: AlertTriangle,
      description: 'Notifications relatives aux paiements et frais',
      color: 'bg-yellow-500'
    },
    {
      id: 'announcements',
      title: 'Annonces',
      icon: MessageSquare,
      description: 'Notifications relatives aux annonces et communications',
      color: 'bg-purple-500'
    },
    {
      id: 'messages',
      title: 'Messages',
      icon: MessageSquare,
      description: 'Notifications relatives aux messages privés',
      color: 'bg-pink-500'
    },
    {
      id: 'system',
      title: 'Système',
      icon: AlertTriangle,
      description: 'Notifications relatives au système et maintenance',
      color: 'bg-red-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Notification Channels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Canaux de notification
          </CardTitle>
          <CardDescription>
            Choisissez les canaux de notification à activer
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Email Notifications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <Label htmlFor="emailEnabled">Notifications par email</Label>
              </div>
              <Switch
                id="emailEnabled"
                checked={formData.emailEnabled}
                onCheckedChange={(checked) => handleInputChange('emailEnabled', checked)}
              />
            </div>
            {formData.emailEnabled && (
              <div className="ml-6 space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="emailAttendance">Présences</Label>
                  <Switch
                    id="emailAttendance"
                    checked={formData.emailAttendance}
                    onCheckedChange={(checked) => handleInputChange('emailAttendance', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="emailGrades">Notes</Label>
                  <Switch
                    id="emailGrades"
                    checked={formData.emailGrades}
                    onCheckedChange={(checked) => handleInputChange('emailGrades', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="emailPayments">Paiements</Label>
                  <Switch
                    id="emailPayments"
                    checked={formData.emailPayments}
                    onCheckedChange={(checked) => handleInputChange('emailPayments', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="emailAnnouncements">Annonces</Label>
                  <Switch
                    id="emailAnnouncements"
                    checked={formData.emailAnnouncements}
                    onCheckedChange={(checked) => handleInputChange('emailAnnouncements', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="emailSystem">Système</Label>
                  <Switch
                    id="emailSystem"
                    checked={formData.emailSystem}
                    onCheckedChange={(checked) => handleInputChange('emailSystem', checked)}
                  />
                </div>
              </div>
            )}
          </div>

          {/* SMS Notifications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="h-4 w-4" />
                <Label htmlFor="smsEnabled">Notifications SMS</Label>
              </div>
              <Switch
                id="smsEnabled"
                checked={formData.smsEnabled}
                onCheckedChange={(checked) => handleInputChange('smsEnabled', checked)}
              />
            </div>
            {formData.smsEnabled && (
              <div className="ml-6 space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="smsAttendance">Présences</Label>
                  <Switch
                    id="smsAttendance"
                    checked={formData.smsAttendance}
                    onCheckedChange={(checked) => handleInputChange('smsAttendance', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="smsGrades">Notes</Label>
                  <Switch
                    id="smsGrades"
                    checked={formData.smsGrades}
                    onCheckedChange={(checked) => handleInputChange('smsGrades', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="smsPayments">Paiements</Label>
                  <Switch
                    id="smsPayments"
                    checked={formData.smsPayments}
                    onCheckedChange={(checked) => handleInputChange('smsPayments', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="smsEmergency">Urgences uniquement</Label>
                  <Switch
                    id="smsEmergency"
                    checked={formData.smsEmergency}
                    onCheckedChange={(checked) => handleInputChange('smsEmergency', checked)}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Push Notifications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <Label htmlFor="pushEnabled">Notifications push</Label>
              </div>
              <Switch
                id="pushEnabled"
                checked={formData.pushEnabled}
                onCheckedChange={(checked) => handleInputChange('pushEnabled', checked)}
              />
            </div>
            {formData.pushEnabled && (
              <div className="ml-6 space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="pushAttendance">Présences</Label>
                  <Switch
                    id="pushAttendance"
                    checked={formData.pushAttendance}
                    onCheckedChange={(checked) => handleInputChange('pushAttendance', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="pushGrades">Notes</Label>
                  <Switch
                    id="pushGrades"
                    checked={formData.pushGrades}
                    onCheckedChange={(checked) => handleInputChange('pushGrades', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="pushPayments">Paiements</Label>
                  <Switch
                    id="pushPayments"
                    checked={formData.pushPayments}
                    onCheckedChange={(checked) => handleInputChange('pushPayments', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="pushAnnouncements">Annonces</Label>
                  <Switch
                    id="pushAnnouncements"
                    checked={formData.pushAnnouncements}
                    onCheckedChange={(checked) => handleInputChange('pushAnnouncements', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="pushMessages">Messages</Label>
                  <Switch
                    id="pushMessages"
                    checked={formData.pushMessages}
                    onCheckedChange={(checked) => handleInputChange('pushMessages', checked)}
                  />
                </div>
              </div>
            )}
          </div>

          {/* In-App Notifications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="h-4 w-4" />
                <Label htmlFor="inAppEnabled">Notifications dans l'application</Label>
              </div>
              <Switch
                id="inAppEnabled"
                checked={formData.inAppEnabled}
                onCheckedChange={(checked) => handleInputChange('inAppEnabled', checked)}
              />
            </div>
            {formData.inAppEnabled && (
              <div className="ml-6 space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="inAppAttendance">Présences</Label>
                  <Switch
                    id="inAppAttendance"
                    checked={formData.inAppAttendance}
                    onCheckedChange={(checked) => handleInputChange('inAppAttendance', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="inAppGrades">Notes</Label>
                  <Switch
                    id="inAppGrades"
                    checked={formData.inAppGrades}
                    onCheckedChange={(checked) => handleInputChange('inAppGrades', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="inAppPayments">Paiements</Label>
                  <Switch
                    id="inAppPayments"
                    checked={formData.inAppPayments}
                    onCheckedChange={(checked) => handleInputChange('inAppPayments', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="inAppAnnouncements">Annonces</Label>
                  <Switch
                    id="inAppAnnouncements"
                    checked={formData.inAppAnnouncements}
                    onCheckedChange={(checked) => handleInputChange('inAppAnnouncements', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="inAppMessages">Messages</Label>
                  <Switch
                    id="inAppMessages"
                    checked={formData.inAppMessages}
                    onCheckedChange={(checked) => handleInputChange('inAppMessages', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="inAppSystem">Système</Label>
                  <Switch
                    id="inAppSystem"
                    checked={formData.inAppSystem}
                    onCheckedChange={(checked) => handleInputChange('inAppSystem', checked)}
                  />
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Préférences de notification</CardTitle>
          <CardDescription>
            Configurez quand et comment vous recevez les notifications
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="digestFrequency">Fréquence des résumés</Label>
              <Select value={formData.digestFrequency} onValueChange={(value) => handleInputChange('digestFrequency', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">Immédiat</SelectItem>
                  <SelectItem value="hourly">Toutes les heures</SelectItem>
                  <SelectItem value="daily">Quotidien</SelectItem>
                  <SelectItem value="weekly">Hebdomadaire</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="digestMode">Mode résumé</Label>
                <p className="text-sm text-muted-foreground">
                  Regrouper les notifications en résumés périodiques
                </p>
              </div>
              <Switch
                id="digestMode"
                checked={formData.digestMode}
                onCheckedChange={(checked) => handleInputChange('digestMode', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="quietHours">Heures de silence</Label>
                <p className="text-sm text-muted-foreground">
                  Ne pas envoyer de notifications pendant certaines heures
                </p>
              </div>
              <Switch
                id="quietHours"
                checked={formData.quietHours}
                onCheckedChange={(checked) => handleInputChange('quietHours', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="soundEnabled">Activer les sons</Label>
                <p className="text-sm text-muted-foreground">
                  Jouer un son pour les notifications
                </p>
              </div>
              <Switch
                id="soundEnabled"
                checked={formData.soundEnabled}
                onCheckedChange={(checked) => handleInputChange('soundEnabled', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="vibrationEnabled">Activer les vibrations</Label>
                <p className="text-sm text-muted-foreground">
                  Vibrer pour les notifications sur mobile
                </p>
              </div>
              <Switch
                id="vibrationEnabled"
                checked={formData.vibrationEnabled}
                onCheckedChange={(checked) => handleInputChange('vibrationEnabled', checked)}
              />
            </div>
          </div>

          {formData.quietHours && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quietStart">Début des heures de silence</Label>
                <Input
                  id="quietStart"
                  type="time"
                  value={formData.quietStart}
                  onChange={(e) => handleInputChange('quietStart', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="quietEnd">Fin des heures de silence</Label>
                <Input
                  id="quietEnd"
                  type="time"
                  value={formData.quietEnd}
                  onChange={(e) => handleInputChange('quietEnd', e.target.value)}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Email Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Configuration email
          </CardTitle>
          <CardDescription>
            Configurez les paramètres SMTP pour l'envoi d'emails
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="smtpHost">Serveur SMTP</Label>
              <Input
                id="smtpHost"
                value={formData.smtpHost}
                onChange={(e) => handleInputChange('smtpHost', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtpPort">Port SMTP</Label>
              <Input
                id="smtpPort"
                value={formData.smtpPort}
                onChange={(e) => handleInputChange('smtpPort', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtpUsername">Nom d'utilisateur SMTP</Label>
              <Input
                id="smtpUsername"
                value={formData.smtpUsername}
                onChange={(e) => handleInputChange('smtpUsername', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtpPassword">Mot de passe SMTP</Label>
              <Input
                id="smtpPassword"
                type="password"
                value={formData.smtpPassword}
                onChange={(e) => handleInputChange('smtpPassword', e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="smtpUseTLS">Utiliser TLS</Label>
              <p className="text-sm text-muted-foreground">
                Activer le chiffrement TLS pour les emails
              </p>
            </div>
            <Switch
              id="smtpUseTLS"
              checked={formData.smtpUseTLS}
              onCheckedChange={(checked) => handleInputChange('smtpUseTLS', checked)}
            />
          </div>
          <Button onClick={() => testNotification('email')} variant="outline">
            <Mail className="mr-2 h-4 w-4" />
            Envoyer un email de test
          </Button>
        </CardContent>
      </Card>

      {/* SMS Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Configuration SMS
          </CardTitle>
          <CardDescription>
            Configurez les paramètres pour l'envoi de SMS
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="smsProvider">Fournisseur SMS</Label>
              <Select value={formData.smsProvider} onValueChange={(value) => handleInputChange('smsProvider', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="twilio">Twilio</SelectItem>
                  <SelectItem value="aws-sns">AWS SNS</SelectItem>
                  <SelectItem value="messagebird">MessageBird</SelectItem>
                  <SelectItem value="sinch">Sinch</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="smsSenderNumber">Numéro d'expéditeur</Label>
              <Input
                id="smsSenderNumber"
                value={formData.smsSenderNumber}
                onChange={(e) => handleInputChange('smsSenderNumber', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smsApiKey">Clé API</Label>
              <Input
                id="smsApiKey"
                value={formData.smsApiKey}
                onChange={(e) => handleInputChange('smsApiKey', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smsApiSecret">Secret API</Label>
              <Input
                id="smsApiSecret"
                type="password"
                value={formData.smsApiSecret}
                onChange={(e) => handleInputChange('smsApiSecret', e.target.value)}
              />
            </div>
          </div>
          <Button onClick={() => testNotification('sms')} variant="outline">
            <Smartphone className="mr-2 h-4 w-4" />
            Envoyer un SMS de test
          </Button>
        </CardContent>
      </Card>

      {/* Notification Templates */}
      <Card>
        <CardHeader>
          <CardTitle>Modèles de notification</CardTitle>
          <CardDescription>
            Personnalisez les modèles de notification
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="attendanceTemplate">Présence</Label>
            <Input
              id="attendanceTemplate"
              value={formData.attendanceTemplate}
              onChange={(e) => handleInputChange('attendanceTemplate', e.target.value)}
              placeholder="Variables: {studentName}, {status}, {date}"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="gradeTemplate">Notes</Label>
            <Input
              id="gradeTemplate"
              value={formData.gradeTemplate}
              onChange={(e) => handleInputChange('gradeTemplate', e.target.value)}
              placeholder="Variables: {studentName}, {subject}, {grade}, {max}"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="paymentTemplate">Paiements</Label>
            <Input
              id="paymentTemplate"
              value={formData.paymentTemplate}
              onChange={(e) => handleInputChange('paymentTemplate', e.target.value)}
              placeholder="Variables: {studentName}, {amount}, {status}, {date}"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="announcementTemplate">Annonces</Label>
            <Input
              id="announcementTemplate"
              value={formData.announcementTemplate}
              onChange={(e) => handleInputChange('announcementTemplate', e.target.value)}
              placeholder="Variables: {title}, {content}, {date}"
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setFormData({
          emailEnabled: true,
          emailAttendance: true,
          emailGrades: true,
          emailPayments: true,
          emailAnnouncements: true,
          emailSystem: false,
          smsEnabled: false,
          smsAttendance: false,
          smsGrades: false,
          smsPayments: true,
          smsEmergency: true,
          pushEnabled: true,
          pushAttendance: true,
          pushGrades: true,
          pushPayments: true,
          pushAnnouncements: true,
          pushMessages: true,
          inAppEnabled: true,
          inAppAttendance: true,
          inAppGrades: true,
          inAppPayments: true,
          inAppAnnouncements: true,
          inAppMessages: true,
          inAppSystem: true,
          digestMode: false,
          digestFrequency: 'daily',
          quietHours: true,
          quietStart: '22:00',
          quietEnd: '07:00',
          soundEnabled: true,
          vibrationEnabled: true,
          smtpHost: 'smtp.gmail.com',
          smtpPort: '587',
          smtpUsername: 'notifications@ecoleplus.fr',
          smtpPassword: '',
          smtpUseTLS: true,
          smsProvider: 'twilio',
          smsApiKey: '',
          smsApiSecret: '',
          smsSenderNumber: '+33612345678',
          attendanceTemplate: 'Votre enfant {studentName} était {status} aujourd\'hui.',
          gradeTemplate: 'Nouvelle note de {grade}/{max} en {subject} pour {studentName}.',
          paymentTemplate: 'Paiement de {amount}€ reçu pour {studentName}. {status}',
          announcementTemplate: 'Nouvelle annonce : {title}'
        })}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Réinitialiser
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
        </Button>
      </div>
    </div>
  );
}