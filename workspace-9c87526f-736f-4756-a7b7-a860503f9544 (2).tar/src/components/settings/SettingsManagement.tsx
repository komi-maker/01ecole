'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Settings, 
  School, 
  Bell, 
  Palette, 
  Globe, 
  Shield, 
  Database, 
  Mail, 
  Phone,
  MapPin,
  Save,
  RefreshCw,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle,
  Printer
} from 'lucide-react'

// Import des composants
import PrintSettings from './PrintSettings'

interface SchoolSettings {
  name: string
  address: string
  phone: string
  email: string
  website: string
  directorName: string
  schoolType: string
  academicYear: string
  currency: string
  timezone: string
  language: string
}

interface NotificationSettings {
  emailNotifications: boolean
  smsNotifications: boolean
  pushNotifications: boolean
  paymentReminders: boolean
  attendanceAlerts: boolean
  gradeNotifications: boolean
  systemUpdates: boolean
  weeklyReports: boolean
}

interface AppearanceSettings {
  theme: 'light' | 'dark' | 'system'
  primaryColor: string
  logo: string
  favicon: string
  customCSS: string
  compactMode: boolean
  showAnimations: boolean
}

interface SecuritySettings {
  twoFactorAuth: boolean
  sessionTimeout: number
  passwordPolicy: boolean
  loginAttempts: number
  ipWhitelist: boolean
  auditLog: boolean
  dataEncryption: boolean
}

export default function SettingsManagement() {
  const [activeTab, setActiveTab] = useState('general')
  const [loading, setLoading] = useState(false)
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle')

  // États pour les différents paramètres
  const [schoolSettings, setSchoolSettings] = useState<SchoolSettings>({
    name: 'ÉcolePro Manager',
    address: '123 Rue de l\'Éducation, 75000 Paris',
    phone: '+33 1 23 45 67 89',
    email: 'contact@ecolepro.fr',
    website: 'www.ecolepro.fr',
    directorName: 'M. Jean Dupont',
    schoolType: 'primaire',
    academicYear: '2024-2025',
    currency: 'EUR',
    timezone: 'Europe/Paris',
    language: 'fr'
  })

  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    paymentReminders: true,
    attendanceAlerts: true,
    gradeNotifications: true,
    systemUpdates: false,
    weeklyReports: true
  })

  const [appearanceSettings, setAppearanceSettings] = useState<AppearanceSettings>({
    theme: 'light',
    primaryColor: '#3b82f6',
    logo: '',
    favicon: '',
    customCSS: '',
    compactMode: false,
    showAnimations: true
  })

  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>({
    twoFactorAuth: false,
    sessionTimeout: 30,
    passwordPolicy: true,
    loginAttempts: 5,
    ipWhitelist: false,
    auditLog: true,
    dataEncryption: true
  })

  const handleSave = async (section: string) => {
    setLoading(true)
    setSaveStatus('saving')
    
    try {
      let settingsToSave = {}
      
      switch (section) {
        case 'general':
          settingsToSave = {
            schoolName: schoolSettings.name,
            schoolAddress: schoolSettings.address,
            schoolPhone: schoolSettings.phone,
            schoolEmail: schoolSettings.email,
            schoolWebsite: schoolSettings.website,
            directorName: schoolSettings.directorName,
            schoolType: schoolSettings.schoolType,
            academicYear: schoolSettings.academicYear,
            currency: schoolSettings.currency,
            timezone: schoolSettings.timezone,
            language: schoolSettings.language
          }
          break
        case 'notifications':
          settingsToSave = notificationSettings
          break
        case 'appearance':
          settingsToSave = appearanceSettings
          break
        case 'security':
          settingsToSave = securitySettings
          break
      }
      
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          category: section,
          settings: settingsToSave
        })
      })
      
      if (response.ok) {
        setSaveStatus('success')
        setTimeout(() => setSaveStatus('idle'), 3000)
      } else {
        throw new Error('Failed to save settings')
      }
    } catch (error) {
      setSaveStatus('error')
      setTimeout(() => setSaveStatus('idle'), 3000)
    } finally {
      setLoading(false)
    }
  }

  const handleReset = async (section: string) => {
    try {
      const response = await fetch('/api/settings/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          category: section
        })
      })
      
      if (response.ok) {
        // Recharger les paramètres par défaut
        await loadSettings()
      } else {
        throw new Error('Failed to reset settings')
      }
    } catch (error) {
      console.error('Reset failed:', error)
    }
  }

  const loadSettings = async () => {
    try {
      const response = await fetch('/api/settings')
      if (response.ok) {
        const data = await response.json()
        
        // Mettre à jour les états avec les données chargées
        if (data.general) {
          setSchoolSettings({
            name: data.general.schoolName || 'ÉcolePro Manager',
            address: data.general.schoolAddress || '',
            phone: data.general.schoolPhone || '',
            email: data.general.schoolEmail || '',
            website: data.general.schoolWebsite || '',
            directorName: data.general.directorName || '',
            schoolType: data.general.schoolType || 'primaire',
            academicYear: data.general.academicYear || '2024-2025',
            currency: data.general.currency || 'EUR',
            timezone: data.general.timezone || 'Europe/Paris',
            language: data.general.language || 'fr'
          })
        }
        
        if (data.notifications) {
          setNotificationSettings(data.notifications)
        }
        
        if (data.appearance) {
          setAppearanceSettings(data.appearance)
        }
        
        if (data.security) {
          setSecuritySettings(data.security)
        }
      }
    } catch (error) {
      console.error('Failed to load settings:', error)
    }
  }

  // Charger les paramètres au montage du composant
  useEffect(() => {
    loadSettings()
  }, [])

  const handleExport = async () => {
    try {
      const data = {
        school: schoolSettings,
        notifications: notificationSettings,
        appearance: appearanceSettings,
        security: securitySettings
      }
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'settings-backup.json'
      a.click()
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Export failed:', error)
    }
  }

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string)
          if (data.school) setSchoolSettings(data.school)
          if (data.notifications) setNotificationSettings(data.notifications)
          if (data.appearance) setAppearanceSettings(data.appearance)
          if (data.security) setSecuritySettings(data.security)
        } catch (error) {
          console.error('Import failed:', error)
        }
      }
      reader.readAsText(file)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Paramètres</h2>
          <p className="text-muted-foreground">Configurez les paramètres de votre application</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Exporter
          </Button>
          <Button variant="outline" asChild>
            <label className="cursor-pointer">
              <Upload className="h-4 w-4 mr-2" />
              Importer
              <input type="file" accept=".json" onChange={handleImport} className="hidden" />
            </label>
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="general" className="flex items-center space-x-2">
            <School className="h-4 w-4" />
            <span>Général</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center space-x-2">
            <Bell className="h-4 w-4" />
            <span>Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex items-center space-x-2">
            <Palette className="h-4 w-4" />
            <span>Apparence</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span>Sécurité</span>
          </TabsTrigger>
          <TabsTrigger value="print" className="flex items-center space-x-2">
            <Printer className="h-4 w-4" />
            <span>Impression</span>
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center space-x-2">
            <Database className="h-4 w-4" />
            <span>Avancé</span>
          </TabsTrigger>
        </TabsList>

        {/* Paramètres généraux */}
        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informations de l'établissement</CardTitle>
              <CardDescription>
                Configurez les informations de base de votre établissement scolaire
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="schoolName">Nom de l'établissement</Label>
                  <Input
                    id="schoolName"
                    value={schoolSettings.name}
                    onChange={(e) => setSchoolSettings({...schoolSettings, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="directorName">Nom du directeur</Label>
                  <Input
                    id="directorName"
                    value={schoolSettings.directorName}
                    onChange={(e) => setSchoolSettings({...schoolSettings, directorName: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="schoolType">Type d'établissement</Label>
                  <Select value={schoolSettings.schoolType} onValueChange={(value) => setSchoolSettings({...schoolSettings, schoolType: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="primaire">Primaire</SelectItem>
                      <SelectItem value="college">Collège</SelectItem>
                      <SelectItem value="lycee">Lycée</SelectItem>
                      <SelectItem value="superieur">Supérieur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="academicYear">Année académique</Label>
                  <Input
                    id="academicYear"
                    value={schoolSettings.academicYear}
                    onChange={(e) => setSchoolSettings({...schoolSettings, academicYear: e.target.value})}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="address">Adresse</Label>
                <Textarea
                  id="address"
                  value={schoolSettings.address}
                  onChange={(e) => setSchoolSettings({...schoolSettings, address: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Téléphone</Label>
                  <Input
                    id="phone"
                    value={schoolSettings.phone}
                    onChange={(e) => setSchoolSettings({...schoolSettings, phone: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={schoolSettings.email}
                    onChange={(e) => setSchoolSettings({...schoolSettings, email: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="website">Site web</Label>
                  <Input
                    id="website"
                    value={schoolSettings.website}
                    onChange={(e) => setSchoolSettings({...schoolSettings, website: e.target.value})}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="currency">Devise</Label>
                  <Select value={schoolSettings.currency} onValueChange={(value) => setSchoolSettings({...schoolSettings, currency: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EUR">EUR (€)</SelectItem>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="GBP">GBP (£)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">Fuseau horaire</Label>
                  <Select value={schoolSettings.timezone} onValueChange={(value) => setSchoolSettings({...schoolSettings, timezone: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Europe/Paris">Europe/Paris</SelectItem>
                      <SelectItem value="Europe/London">Europe/London</SelectItem>
                      <SelectItem value="America/New_York">America/New_York</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Langue</Label>
                  <Select value={schoolSettings.language} onValueChange={(value) => setSchoolSettings({...schoolSettings, language: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => handleReset('general')}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Réinitialiser
                </Button>
                <Button onClick={() => handleSave('general')} disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Paramètres de notification */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Préférences de notification</CardTitle>
              <CardDescription>
                Configurez comment et quand vous souhaitez recevoir des notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Canaux de notification</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <Label>Email</Label>
                    </div>
                    <Switch
                      checked={notificationSettings.emailNotifications}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, emailNotifications: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4" />
                      <Label>SMS</Label>
                    </div>
                    <Switch
                      checked={notificationSettings.smsNotifications}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, smsNotifications: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Bell className="h-4 w-4" />
                      <Label>Push</Label>
                    </div>
                    <Switch
                      checked={notificationSettings.pushNotifications}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, pushNotifications: checked})}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Types de notifications</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Rappels de paiement</Label>
                      <p className="text-sm text-muted-foreground">Notifications pour les paiements en retard</p>
                    </div>
                    <Switch
                      checked={notificationSettings.paymentReminders}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, paymentReminders: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Alertes d'absence</Label>
                      <p className="text-sm text-muted-foreground">Notifications pour les absences non justifiées</p>
                    </div>
                    <Switch
                      checked={notificationSettings.attendanceAlerts}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, attendanceAlerts: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Notifications de notes</Label>
                      <p className="text-sm text-muted-foreground">Alertes lors de la publication des notes</p>
                    </div>
                    <Switch
                      checked={notificationSettings.gradeNotifications}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, gradeNotifications: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Mises à jour système</Label>
                      <p className="text-sm text-muted-foreground">Informations sur les mises à jour</p>
                    </div>
                    <Switch
                      checked={notificationSettings.systemUpdates}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, systemUpdates: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Rapports hebdomadaires</Label>
                      <p className="text-sm text-muted-foreground">Résumé des activités de la semaine</p>
                    </div>
                    <Switch
                      checked={notificationSettings.weeklyReports}
                      onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, weeklyReports: checked})}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button onClick={() => handleSave('notifications')} disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Paramètres d'apparence */}
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personnalisation de l'interface</CardTitle>
              <CardDescription>
                Configurez l'apparence et le comportement de l'interface utilisateur
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Thème</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="light"
                      name="theme"
                      value="light"
                      checked={appearanceSettings.theme === 'light'}
                      onChange={(e) => setAppearanceSettings({...appearanceSettings, theme: e.target.value as 'light' | 'dark' | 'system'})}
                    />
                    <Label htmlFor="light">Clair</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="dark"
                      name="theme"
                      value="dark"
                      checked={appearanceSettings.theme === 'dark'}
                      onChange={(e) => setAppearanceSettings({...appearanceSettings, theme: e.target.value as 'light' | 'dark' | 'system'})}
                    />
                    <Label htmlFor="dark">Sombre</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="system"
                      name="theme"
                      value="system"
                      checked={appearanceSettings.theme === 'system'}
                      onChange={(e) => setAppearanceSettings({...appearanceSettings, theme: e.target.value as 'light' | 'dark' | 'system'})}
                    />
                    <Label htmlFor="system">Système</Label>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Couleurs</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="primaryColor">Couleur principale</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="primaryColor"
                        type="color"
                        value={appearanceSettings.primaryColor}
                        onChange={(e) => setAppearanceSettings({...appearanceSettings, primaryColor: e.target.value})}
                        className="w-20 h-10"
                      />
                      <Input
                        value={appearanceSettings.primaryColor}
                        onChange={(e) => setAppearanceSettings({...appearanceSettings, primaryColor: e.target.value})}
                        placeholder="#3b82f6"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Comportement</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Mode compact</Label>
                      <p className="text-sm text-muted-foreground">Réduit l'espacement entre les éléments</p>
                    </div>
                    <Switch
                      checked={appearanceSettings.compactMode}
                      onCheckedChange={(checked) => setAppearanceSettings({...appearanceSettings, compactMode: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Animations</Label>
                      <p className="text-sm text-muted-foreground">Active les animations de transition</p>
                    </div>
                    <Switch
                      checked={appearanceSettings.showAnimations}
                      onCheckedChange={(checked) => setAppearanceSettings({...appearanceSettings, showAnimations: checked})}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button onClick={() => handleSave('appearance')} disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Paramètres de sécurité */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Paramètres de sécurité</CardTitle>
              <CardDescription>
                Configurez les options de sécurité pour protéger vos données
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Authentification</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Authentification à deux facteurs</Label>
                      <p className="text-sm text-muted-foreground">Ajoute une couche de sécurité supplémentaire</p>
                    </div>
                    <Switch
                      checked={securitySettings.twoFactorAuth}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, twoFactorAuth: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Politique de mot de passe</Label>
                      <p className="text-sm text-muted-foreground">Exige des mots de passe complexes</p>
                    </div>
                    <Switch
                      checked={securitySettings.passwordPolicy}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, passwordPolicy: checked})}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Session</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout">Délai d'expiration (minutes)</Label>
                    <Input
                      id="sessionTimeout"
                      type="number"
                      value={securitySettings.sessionTimeout}
                      onChange={(e) => setSecuritySettings({...securitySettings, sessionTimeout: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="loginAttempts">Tentatives de connexion max</Label>
                    <Input
                      id="loginAttempts"
                      type="number"
                      value={securitySettings.loginAttempts}
                      onChange={(e) => setSecuritySettings({...securitySettings, loginAttempts: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Protection des données</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Liste blanche IP</Label>
                      <p className="text-sm text-muted-foreground">Autorise uniquement les adresses IP spécifiées</p>
                    </div>
                    <Switch
                      checked={securitySettings.ipWhitelist}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, ipWhitelist: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Journal d'audit</Label>
                      <p className="text-sm text-muted-foreground">Enregistre toutes les activités</p>
                    </div>
                    <Switch
                      checked={securitySettings.auditLog}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, auditLog: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <Label>Chiffrement des données</Label>
                      <p className="text-sm text-muted-foreground">Chiffre les données sensibles</p>
                    </div>
                    <Switch
                      checked={securitySettings.dataEncryption}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, dataEncryption: checked})}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button onClick={() => handleSave('security')} disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Paramètres d'impression */}
        <TabsContent value="print" className="space-y-6">
          <PrintSettings />
        </TabsContent>

        {/* Paramètres avancés */}
        <TabsContent value="advanced" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Paramètres avancés</CardTitle>
              <CardDescription>
                Options avancées pour les utilisateurs techniques
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Maintenance</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start">
                    <Database className="h-4 w-4 mr-2" />
                    Nettoyer la base de données
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Vider le cache
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Download className="h-4 w-4 mr-2" />
                    Exporter les données
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Upload className="h-4 w-4 mr-2" />
                    Importer les données
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium">Informations système</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <Label>Version de l'application</Label>
                    <p className="text-sm text-muted-foreground">v1.0.0</p>
                  </div>
                  <div>
                    <Label>Dernière mise à jour</Label>
                    <p className="text-sm text-muted-foreground">15/10/2024</p>
                  </div>
                  <div>
                    <Label>Base de données</Label>
                    <p className="text-sm text-muted-foreground">SQLite</p>
                  </div>
                  <div>
                    <Label>Espace utilisé</Label>
                    <p className="text-sm text-muted-foreground">245 MB</p>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="destructive">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Réinitialiser l'application
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Statut de sauvegarde */}
      {saveStatus !== 'idle' && (
        <div className="fixed bottom-4 right-4">
          <Card className={`p-4 ${
            saveStatus === 'success' ? 'bg-green-50 border-green-200' : 
            saveStatus === 'error' ? 'bg-red-50 border-red-200' : 
            'bg-blue-50 border-blue-200'
          }`}>
            <div className="flex items-center space-x-2">
              {saveStatus === 'success' && <CheckCircle className="h-4 w-4 text-green-600" />}
              {saveStatus === 'error' && <AlertTriangle className="h-4 w-4 text-red-600" />}
              {saveStatus === 'saving' && <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" />}
              <span className={`text-sm font-medium ${
                saveStatus === 'success' ? 'text-green-800' : 
                saveStatus === 'error' ? 'text-red-800' : 
                'text-blue-800'
              }`}>
                {saveStatus === 'success' ? 'Paramètres sauvegardés' : 
                 saveStatus === 'error' ? 'Erreur de sauvegarde' : 
                 'Sauvegarde en cours...'}
              </span>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}