'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  School, 
  Globe, 
  Mail, 
  Phone, 
  MapPin, 
  Clock,
  Save,
  RotateCcw
} from 'lucide-react';
import { toast } from 'sonner';

export default function GeneralSettings() {
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    // School Information
    schoolName: 'ÉcolePlus',
    schoolCode: 'EPL2024',
    schoolType: 'prive',
    address: '123 Rue de l\'Éducation, Paris, France',
    phone: '+33 1 23 45 67 89',
    email: 'contact@ecoleplus.fr',
    website: 'www.ecoleplus.fr',
    
    // Academic Settings
    academicYear: '2024-2025',
    semesterSystem: true,
    currentSemester: '1',
    gradingScale: '20',
    passingGrade: '10',
    
    // Working Hours
    mondayOpen: '08:00',
    mondayClose: '17:00',
    saturdayOpen: '',
    saturdayClose: '',
    sundayOpen: '',
    sundayClose: '',
    
    // Language & Region
    defaultLanguage: 'fr',
    timezone: 'Europe/Paris',
    currency: 'EUR',
    dateFormat: 'DD/MM/YYYY',
    
    // System Settings
    autoBackup: true,
    backupFrequency: 'daily',
    maxFileSize: '10',
    sessionTimeout: '30'
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Paramètres généraux sauvegardés avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde des paramètres');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setFormData({
      schoolName: 'ÉcolePlus',
      schoolCode: 'EPL2024',
      schoolType: 'prive',
      address: '123 Rue de l\'Éducation, Paris, France',
      phone: '+33 1 23 45 67 89',
      email: 'contact@ecoleplus.fr',
      website: 'www.ecoleplus.fr',
      academicYear: '2024-2025',
      semesterSystem: true,
      currentSemester: '1',
      gradingScale: '20',
      passingGrade: '10',
      mondayOpen: '08:00',
      mondayClose: '17:00',
      saturdayOpen: '',
      saturdayClose: '',
      sundayOpen: '',
      sundayClose: '',
      defaultLanguage: 'fr',
      timezone: 'Europe/Paris',
      currency: 'EUR',
      dateFormat: 'DD/MM/YYYY',
      autoBackup: true,
      backupFrequency: 'daily',
      maxFileSize: '10',
      sessionTimeout: '30'
    });
    toast.info('Paramètres réinitialisés aux valeurs par défaut');
  };

  return (
    <div className="space-y-6">
      {/* School Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <School className="h-5 w-5" />
            Informations de l'établissement
          </CardTitle>
          <CardDescription>
            Configurez les informations de base de votre établissement
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="schoolName">Nom de l'établissement</Label>
              <Input
                id="schoolName"
                value={formData.schoolName}
                onChange={(e) => handleInputChange('schoolName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="schoolCode">Code de l'établissement</Label>
              <Input
                id="schoolCode"
                value={formData.schoolCode}
                onChange={(e) => handleInputChange('schoolCode', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="schoolType">Type d'établissement</Label>
              <Select value={formData.schoolType} onValueChange={(value) => handleInputChange('schoolType', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">Public</SelectItem>
                  <SelectItem value="prive">Privé</SelectItem>
                  <SelectItem value="international">International</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email principal</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Téléphone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="website">Site web</Label>
              <Input
                id="website"
                value={formData.website}
                onChange={(e) => handleInputChange('website', e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Adresse</Label>
            <Textarea
              id="address"
              value={formData.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              rows={2}
            />
          </div>
        </CardContent>
      </Card>

      {/* Academic Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Paramètres académiques
          </CardTitle>
          <CardDescription>
            Configurez les paramètres académiques et le système de notation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="academicYear">Année académique</Label>
              <Input
                id="academicYear"
                value={formData.academicYear}
                onChange={(e) => handleInputChange('academicYear', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gradingScale">Barème de notation</Label>
              <Select value={formData.gradingScale} onValueChange={(value) => handleInputChange('gradingScale', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="20">Sur 20</SelectItem>
                  <SelectItem value="100">Sur 100</SelectItem>
                  <SelectItem value="5">Sur 5</SelectItem>
                  <SelectItem value="10">Sur 10</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="passingGrade">Note de passage</Label>
              <Input
                id="passingGrade"
                value={formData.passingGrade}
                onChange={(e) => handleInputChange('passingGrade', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentSemester">Semestre actuel</Label>
              <Select value={formData.currentSemester} onValueChange={(value) => handleInputChange('currentSemester', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Semestre 1</SelectItem>
                  <SelectItem value="2">Semestre 2</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="semesterSystem">Système semestriel</Label>
              <p className="text-sm text-muted-foreground">
                Activer le système semestriel au lieu du système annuel
              </p>
            </div>
            <Switch
              id="semesterSystem"
              checked={formData.semesterSystem}
              onCheckedChange={(checked) => handleInputChange('semesterSystem', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Working Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Heures d'ouverture
          </CardTitle>
          <CardDescription>
            Définissez les heures d'ouverture de l'établissement
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Lundi - Vendredi</Label>
              <div className="flex gap-2">
                <Input
                  type="time"
                  value={formData.mondayOpen}
                  onChange={(e) => handleInputChange('mondayOpen', e.target.value)}
                  placeholder="Ouverture"
                />
                <Input
                  type="time"
                  value={formData.mondayClose}
                  onChange={(e) => handleInputChange('mondayClose', e.target.value)}
                  placeholder="Fermeture"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Samedi</Label>
              <div className="flex gap-2">
                <Input
                  type="time"
                  value={formData.saturdayOpen}
                  onChange={(e) => handleInputChange('saturdayOpen', e.target.value)}
                  placeholder="Ouverture"
                />
                <Input
                  type="time"
                  value={formData.saturdayClose}
                  onChange={(e) => handleInputChange('saturdayClose', e.target.value)}
                  placeholder="Fermeture"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Dimanche</Label>
              <div className="flex gap-2">
                <Input
                  type="time"
                  value={formData.sundayOpen}
                  onChange={(e) => handleInputChange('sundayOpen', e.target.value)}
                  placeholder="Ouverture"
                />
                <Input
                  type="time"
                  value={formData.sundayClose}
                  onChange={(e) => handleInputChange('sundayClose', e.target.value)}
                  placeholder="Fermeture"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Language & Region */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Langue et région
          </CardTitle>
          <CardDescription>
            Configurez les paramètres régionaux et linguistiques
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="defaultLanguage">Langue par défaut</Label>
              <Select value={formData.defaultLanguage} onValueChange={(value) => handleInputChange('defaultLanguage', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="ar">العربية</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="timezone">Fuseau horaire</Label>
              <Select value={formData.timezone} onValueChange={(value) => handleInputChange('timezone', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Europe/Paris">Europe/Paris</SelectItem>
                  <SelectItem value="Europe/London">Europe/London</SelectItem>
                  <SelectItem value="America/New_York">America/New_York</SelectItem>
                  <SelectItem value="Asia/Tokyo">Asia/Tokyo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Devise</Label>
              <Select value={formData.currency} onValueChange={(value) => handleInputChange('currency', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                  <SelectItem value="XOF">XOF (CFA)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dateFormat">Format de date</Label>
              <Select value={formData.dateFormat} onValueChange={(value) => handleInputChange('dateFormat', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                  <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                  <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                  <SelectItem value="DD-MM-YYYY">DD-MM-YYYY</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Paramètres système</CardTitle>
          <CardDescription>
            Configurez les paramètres système et de sauvegarde
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxFileSize">Taille maximale des fichiers (MB)</Label>
              <Input
                id="maxFileSize"
                type="number"
                value={formData.maxFileSize}
                onChange={(e) => handleInputChange('maxFileSize', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Délai d'expiration de session (minutes)</Label>
              <Input
                id="sessionTimeout"
                type="number"
                value={formData.sessionTimeout}
                onChange={(e) => handleInputChange('sessionTimeout', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="backupFrequency">Fréquence de sauvegarde</Label>
              <Select value={formData.backupFrequency} onValueChange={(value) => handleInputChange('backupFrequency', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Quotidienne</SelectItem>
                  <SelectItem value="weekly">Hebdomadaire</SelectItem>
                  <SelectItem value="monthly">Mensuelle</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="autoBackup">Sauvegarde automatique</Label>
              <p className="text-sm text-muted-foreground">
                Activer les sauvegardes automatiques régulières
              </p>
            </div>
            <Switch
              id="autoBackup"
              checked={formData.autoBackup}
              onCheckedChange={(checked) => handleInputChange('autoBackup', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={handleReset}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Réinitialiser
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
        </Button>
      </div>
    </div>
  );
}