'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  Palette, 
  Monitor, 
  Moon, 
  Sun,
  Type,
  Layout,
  ImageIcon,
  Save,
  RotateCcw,
  Eye,
  Download,
  Upload
} from 'lucide-react';
import { toast } from 'sonner';

export default function AppearanceSettings() {
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    // Theme
    theme: 'light',
    primaryColor: '#3b82f6',
    secondaryColor: '#64748b',
    accentColor: '#f59e0b',
    backgroundColor: '#ffffff',
    surfaceColor: '#f8fafc',
    textColor: '#1e293b',
    
    // Typography
    fontFamily: 'Inter',
    fontSize: 'medium',
    lineHeight: 'relaxed',
    fontWeight: 'normal',
    
    // Layout
    sidebarCollapsed: false,
    sidebarWidth: '280',
    headerHeight: '64',
    footerEnabled: true,
    breadcrumbsEnabled: true,
    
    // Dashboard
    dashboardLayout: 'grid',
    widgetsPerRow: '3',
    showWidgetTitles: true,
    showWidgetBorders: true,
    widgetRounded: true,
    
    // Branding
    logoUrl: '',
    faviconUrl: '',
    customCSS: '',
    customJS: '',
    
    // Animations
    enableAnimations: true,
    animationDuration: 'normal',
    enableTransitions: true,
    transitionDuration: 'fast',
    
    // Accessibility
    highContrast: false,
    reducedMotion: false,
    largeText: false,
    focusVisible: true,
    
    // Display
    density: 'comfortable',
    showShadows: true,
    showGradients: true,
    borderRadius: 'medium',
    
    // Language
    language: 'fr',
    dateFormat: 'DD/MM/YYYY',
    timeFormat: '24h',
    numberFormat: 'fr-FR'
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Paramètres d\'apparence sauvegardés avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde des paramètres');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportTheme = () => {
    const themeData = {
      theme: formData.theme,
      colors: {
        primary: formData.primaryColor,
        secondary: formData.secondaryColor,
        accent: formData.accentColor,
        background: formData.backgroundColor,
        surface: formData.surfaceColor,
        text: formData.textColor
      },
      typography: {
        fontFamily: formData.fontFamily,
        fontSize: formData.fontSize,
        lineHeight: formData.lineHeight,
        fontWeight: formData.fontWeight
      },
      layout: {
        sidebarCollapsed: formData.sidebarCollapsed,
        sidebarWidth: formData.sidebarWidth,
        headerHeight: formData.headerHeight,
        footerEnabled: formData.footerEnabled,
        breadcrumbsEnabled: formData.breadcrumbsEnabled
      }
    };
    
    const blob = new Blob([JSON.stringify(themeData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ecoleplus-theme.json';
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success('Thème exporté avec succès');
  };

  const handleImportTheme = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const themeData = JSON.parse(e.target?.result as string);
          setFormData(prev => ({
            ...prev,
            theme: themeData.theme || prev.theme,
            primaryColor: themeData.colors?.primary || prev.primaryColor,
            secondaryColor: themeData.colors?.secondary || prev.secondaryColor,
            accentColor: themeData.colors?.accent || prev.accentColor,
            backgroundColor: themeData.colors?.background || prev.backgroundColor,
            surfaceColor: themeData.colors?.surface || prev.surfaceColor,
            textColor: themeData.colors?.text || prev.textColor,
            fontFamily: themeData.typography?.fontFamily || prev.fontFamily,
            fontSize: themeData.typography?.fontSize || prev.fontSize,
            lineHeight: themeData.typography?.lineHeight || prev.lineHeight,
            fontWeight: themeData.typography?.fontWeight || prev.fontWeight,
            sidebarCollapsed: themeData.layout?.sidebarCollapsed ?? prev.sidebarCollapsed,
            sidebarWidth: themeData.layout?.sidebarWidth || prev.sidebarWidth,
            headerHeight: themeData.layout?.headerHeight || prev.headerHeight,
            footerEnabled: themeData.layout?.footerEnabled ?? prev.footerEnabled,
            breadcrumbsEnabled: themeData.layout?.breadcrumbsEnabled ?? prev.breadcrumbsEnabled
          }));
          toast.success('Thème importé avec succès');
        } catch (error) {
          toast.error('Erreur lors de l\'importation du thème');
        }
      };
      reader.readAsText(file);
    }
  };

  const presetThemes = [
    {
      name: 'ÉcolePlus (par défaut)',
      theme: 'light',
      primaryColor: '#3b82f6',
      secondaryColor: '#64748b',
      accentColor: '#f59e0b'
    },
    {
      name: 'Classique',
      theme: 'light',
      primaryColor: '#1e40af',
      secondaryColor: '#475569',
      accentColor: '#dc2626'
    },
    {
      name: 'Moderne',
      theme: 'light',
      primaryColor: '#8b5cf6',
      secondaryColor: '#6b7280',
      accentColor: '#ec4899'
    },
    {
      name: 'Nature',
      theme: 'light',
      primaryColor: '#059669',
      secondaryColor: '#6b7280',
      accentColor: '#84cc16'
    },
    {
      name: 'Sombre',
      theme: 'dark',
      primaryColor: '#60a5fa',
      secondaryColor: '#9ca3af',
      accentColor: '#fbbf24'
    }
  ];

  const applyPresetTheme = (preset: typeof presetThemes[0]) => {
    setFormData(prev => ({
      ...prev,
      theme: preset.theme,
      primaryColor: preset.primaryColor,
      secondaryColor: preset.secondaryColor,
      accentColor: preset.accentColor
    }));
    toast.success(`Thème "${preset.name}" appliqué`);
  };

  return (
    <div className="space-y-6">
      {/* Theme Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            Thème
          </CardTitle>
          <CardDescription>
            Choisissez un thème prédéfini ou personnalisez les couleurs
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>Thèmes prédéfinis</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {presetThemes.map((preset, index) => (
                <div
                  key={index}
                  className="border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors"
                  onClick={() => applyPresetTheme(preset)}
                >
                  <div className="flex items-center gap-2 mb-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: preset.primaryColor }}
                      alt=""
                    />
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: preset.secondaryColor }}
                      alt=""
                    />
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: preset.accentColor }}
                      alt=""
                    />
                  </div>
                  <div className="font-medium">{preset.name}</div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <Label>Personnalisation des couleurs</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="primaryColor">Couleur primaire</Label>
                <div className="flex gap-2">
                  <Input
                    id="primaryColor"
                    type="color"
                    value={formData.primaryColor}
                    onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.primaryColor}
                    onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                    placeholder="#3b82f6"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="secondaryColor">Couleur secondaire</Label>
                <div className="flex gap-2">
                  <Input
                    id="secondaryColor"
                    type="color"
                    value={formData.secondaryColor}
                    onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.secondaryColor}
                    onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                    placeholder="#64748b"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accentColor">Couleur d'accent</Label>
                <div className="flex gap-2">
                  <Input
                    id="accentColor"
                    type="color"
                    value={formData.accentColor}
                    onChange={(e) => handleInputChange('accentColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.accentColor}
                    onChange={(e) => handleInputChange('accentColor', e.target.value)}
                    placeholder="#f59e0b"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="backgroundColor">Couleur de fond</Label>
                <div className="flex gap-2">
                  <Input
                    id="backgroundColor"
                    type="color"
                    value={formData.backgroundColor}
                    onChange={(e) => handleInputChange('backgroundColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.backgroundColor}
                    onChange={(e) => handleInputChange('backgroundColor', e.target.value)}
                    placeholder="#ffffff"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="surfaceColor">Couleur de surface</Label>
                <div className="flex gap-2">
                  <Input
                    id="surfaceColor"
                    type="color"
                    value={formData.surfaceColor}
                    onChange={(e) => handleInputChange('surfaceColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.surfaceColor}
                    onChange={(e) => handleInputChange('surfaceColor', e.target.value)}
                    placeholder="#f8fafc"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="textColor">Couleur du texte</Label>
                <div className="flex gap-2">
                  <Input
                    id="textColor"
                    type="color"
                    value={formData.textColor}
                    onChange={(e) => handleInputChange('textColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.textColor}
                    onChange={(e) => handleInputChange('textColor', e.target.value)}
                    placeholder="#1e293b"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="theme">Mode sombre</Label>
              <p className="text-sm text-muted-foreground">
                Activer le mode sombre pour l'interface
              </p>
            </div>
            <Switch
              id="theme"
              checked={formData.theme === 'dark'}
              onCheckedChange={(checked) => handleInputChange('theme', checked ? 'dark' : 'light')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Typography */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Type className="h-5 w-5" />
            Typographie
          </CardTitle>
          <CardDescription>
            Configurez les polices et les styles de texte
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fontFamily">Police de caractères</Label>
              <Select value={formData.fontFamily} onValueChange={(value) => handleInputChange('fontFamily', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Inter">Inter</SelectItem>
                  <SelectItem value="Roboto">Roboto</SelectItem>
                  <SelectItem value="Open Sans">Open Sans</SelectItem>
                  <SelectItem value="Lato">Lato</SelectItem>
                  <SelectItem value="Montserrat">Montserrat</SelectItem>
                  <SelectItem value="Poppins">Poppins</SelectItem>
                  <SelectItem value="Raleway">Raleway</SelectItem>
                  <SelectItem value="Ubuntu">Ubuntu</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="fontSize">Taille de police</Label>
              <Select value={formData.fontSize} onValueChange={(value) => handleInputChange('fontSize', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Petite</SelectItem>
                  <SelectItem value="medium">Moyenne</SelectItem>
                  <SelectItem value="large">Grande</SelectItem>
                  <SelectItem value="xlarge">Très grande</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="lineHeight">Hauteur de ligne</Label>
              <Select value={formData.lineHeight} onValueChange={(value) => handleInputChange('lineHeight', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tight">Serrée</SelectItem>
                  <SelectItem value="normal">Normale</SelectItem>
                  <SelectItem value="relaxed">Détendue</SelectItem>
                  <SelectItem value="loose">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="fontWeight">Graisse de police</Label>
              <Select value={formData.fontWeight} onValueChange={(value) => handleInputChange('fontWeight', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Léger</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="medium">Moyen</SelectItem>
                  <SelectItem value="semibold">Demi-gras</SelectItem>
                  <SelectItem value="bold">Gras</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Layout */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layout className="h-5 w-5" />
            Mise en page
          </CardTitle>
          <CardDescription>
            Configurez la disposition et l'organisation de l'interface
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sidebarWidth">Largeur de la barre latérale</Label>
              <Select value={formData.sidebarWidth} onValueChange={(value) => handleInputChange('sidebarWidth', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="240">Étroite (240px)</SelectItem>
                  <SelectItem value="280">Normale (280px)</SelectItem>
                  <SelectItem value="320">Large (320px)</SelectItem>
                  <SelectItem value="360">Très large (360px)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="headerHeight">Hauteur de l'en-tête</Label>
              <Select value={formData.headerHeight} onValueChange={(value) => handleInputChange('headerHeight', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="56">Compacte (56px)</SelectItem>
                  <SelectItem value="64">Normale (64px)</SelectItem>
                  <SelectItem value="72">Large (72px)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dashboardLayout">Disposition du tableau de bord</Label>
              <Select value={formData.dashboardLayout} onValueChange={(value) => handleInputChange('dashboardLayout', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="grid">Grille</SelectItem>
                  <SelectItem value="masonry">Maçonnerie</SelectItem>
                  <SelectItem value="list">Liste</SelectItem>
                  <SelectItem value="cards">Cartes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="widgetsPerRow">Widgets par ligne</Label>
              <Select value={formData.widgetsPerRow} onValueChange={(value) => handleInputChange('widgetsPerRow', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2">2 widgets</SelectItem>
                  <SelectItem value="3">3 widgets</SelectItem>
                  <SelectItem value="4">4 widgets</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="sidebarCollapsed">Barre latérale réduite par défaut</Label>
              <Switch
                id="sidebarCollapsed"
                checked={formData.sidebarCollapsed}
                onCheckedChange={(checked) => handleInputChange('sidebarCollapsed', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="footerEnabled">Afficher le pied de page</Label>
              <Switch
                id="footerEnabled"
                checked={formData.footerEnabled}
                onCheckedChange={(checked) => handleInputChange('footerEnabled', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="breadcrumbsEnabled">Afficher le fil d'Ariane</Label>
              <Switch
                id="breadcrumbsEnabled"
                checked={formData.breadcrumbsEnabled}
                onCheckedChange={(checked) => handleInputChange('breadcrumbsEnabled', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="showWidgetTitles">Afficher les titres des widgets</Label>
              <Switch
                id="showWidgetTitles"
                checked={formData.showWidgetTitles}
                onCheckedChange={(checked) => handleInputChange('showWidgetTitles', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="showWidgetBorders">Afficher les bordures des widgets</Label>
              <Switch
                id="showWidgetBorders"
                checked={formData.showWidgetBorders}
                onCheckedChange={(checked) => handleInputChange('showWidgetBorders', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="widgetRounded">Widgets arrondis</Label>
              <Switch
                id="widgetRounded"
                checked={formData.widgetRounded}
                onCheckedChange={(checked) => handleInputChange('widgetRounded', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Display Options */}
      <Card>
        <CardHeader>
          <CardTitle>Options d'affichage</CardTitle>
          <CardDescription>
            Configurez les options d'affichage et d'accessibilité
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="density">Densité d'affichage</Label>
              <Select value={formData.density} onValueChange={(value) => handleInputChange('density', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="compact">Compacte</SelectItem>
                  <SelectItem value="comfortable">Confortable</SelectItem>
                  <SelectItem value="spacious">Spacieuse</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="borderRadius">Rayon des bordures</Label>
              <Select value={formData.borderRadius} onValueChange={(value) => handleInputChange('borderRadius', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Aucun</SelectItem>
                  <SelectItem value="small">Petit</SelectItem>
                  <SelectItem value="medium">Moyen</SelectItem>
                  <SelectItem value="large">Grand</SelectItem>
                  <SelectItem value="full">Plein</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="showShadows">Afficher les ombres</Label>
                <p className="text-sm text-muted-foreground">
                  Ajouter des ombres aux éléments de l'interface
                </p>
              </div>
              <Switch
                id="showShadows"
                checked={formData.showShadows}
                onCheckedChange={(checked) => handleInputChange('showShadows', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="showGradients">Afficher les dégradés</Label>
                <p className="text-sm text-muted-foreground">
                  Utiliser des dégradés pour les arrière-plans
                </p>
              </div>
              <Switch
                id="showGradients"
                checked={formData.showGradients}
                onCheckedChange={(checked) => handleInputChange('showGradients', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableAnimations">Activer les animations</Label>
                <p className="text-sm text-muted-foreground">
                  Activer les animations de l'interface
                </p>
              </div>
              <Switch
                id="enableAnimations"
                checked={formData.enableAnimations}
                onCheckedChange={(checked) => handleInputChange('enableAnimations', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="enableTransitions">Activer les transitions</Label>
                <p className="text-sm text-muted-foreground">
                  Activer les transitions douces entre les états
                </p>
              </div>
              <Switch
                id="enableTransitions"
                checked={formData.enableTransitions}
                onCheckedChange={(checked) => handleInputChange('enableTransitions', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Accessibility */}
      <Card>
        <CardHeader>
          <CardTitle>Accessibilité</CardTitle>
          <CardDescription>
            Configurez les options d'accessibilité
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="highContrast">Contraste élevé</Label>
                <p className="text-sm text-muted-foreground">
                  Augmenter le contraste pour une meilleure lisibilité
                </p>
              </div>
              <Switch
                id="highContrast"
                checked={formData.highContrast}
                onCheckedChange={(checked) => handleInputChange('highContrast', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="reducedMotion">Mouvements réduits</Label>
                <p className="text-sm text-muted-foreground">
                  Réduire les animations pour les utilisateurs sensibles
                </p>
              </div>
              <Switch
                id="reducedMotion"
                checked={formData.reducedMotion}
                onCheckedChange={(checked) => handleInputChange('reducedMotion', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="largeText">Texte agrandi</Label>
                <p className="text-sm text-muted-foreground">
                  Augmenter la taille du texte pour une meilleure lisibilité
                </p>
              </div>
              <Switch
                id="largeText"
                checked={formData.largeText}
                onCheckedChange={(checked) => handleInputChange('largeText', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="focusVisible">Focus visible</Label>
                <p className="text-sm text-muted-foreground">
                  Afficher clairement le focus pour la navigation au clavier
                </p>
              </div>
              <Switch
                id="focusVisible"
                checked={formData.focusVisible}
                onCheckedChange={(checked) => handleInputChange('focusVisible', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Branding */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5" />
            Personnalisation de la marque
          </CardTitle>
          <CardDescription>
            Ajoutez votre logo et personnalisez l'apparence
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="logoUrl">URL du logo</Label>
              <Input
                id="logoUrl"
                value={formData.logoUrl}
                onChange={(e) => handleInputChange('logoUrl', e.target.value)}
                placeholder="https://example.com/logo.png"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="faviconUrl">URL du favicon</Label>
              <Input
                id="faviconUrl"
                value={formData.faviconUrl}
                onChange={(e) => handleInputChange('faviconUrl', e.target.value)}
                placeholder="https://example.com/favicon.ico"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="customCSS">CSS personnalisé</Label>
            <textarea
              id="customCSS"
              className="w-full h-32 p-3 border rounded-md font-mono text-sm"
              value={formData.customCSS}
              onChange={(e) => handleInputChange('customCSS', e.target.value)}
              placeholder="/* Ajoutez votre CSS personnalisé ici */"
            />
          </div>
        </CardContent>
      </Card>

      {/* Theme Management */}
      <Card>
        <CardHeader>
          <CardTitle>Gestion des thèmes</CardTitle>
          <CardDescription>
            Importez ou exportez des thèmes personnalisés
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={handleExportTheme} variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Exporter le thème
            </Button>
            <div className="relative">
              <input
                type="file"
                accept=".json"
                onChange={handleImportTheme}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <Button variant="outline">
                <Upload className="mr-2 h-4 w-4" />
                Importer un thème
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Preview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Aperçu
          </CardTitle>
          <CardDescription>
            Aperçu des changements d'apparence
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div 
            className="p-6 rounded-lg border"
            style={{
              backgroundColor: formData.backgroundColor,
              color: formData.textColor,
              fontFamily: formData.fontFamily,
              fontSize: formData.fontSize === 'small' ? '14px' : formData.fontSize === 'large' ? '18px' : '16px',
              lineHeight: formData.lineHeight === 'tight' ? '1.25' : formData.lineHeight === 'relaxed' ? '1.75' : '1.5',
              borderRadius: formData.borderRadius === 'none' ? '0' : formData.borderRadius === 'small' ? '4px' : formData.borderRadius === 'large' ? '12px' : '8px'
            }}
          >
            <h3 
              className="text-xl font-bold mb-4"
              style={{ color: formData.primaryColor }}
            >
              Aperçu du thème
            </h3>
            <p className="mb-4">
              Ceci est un aperçu de votre thème personnalisé. Les couleurs, les polices et les styles que vous avez choisis seront appliqués à toute l'application.
            </p>
            <div className="flex gap-2">
              <Button 
                style={{ 
                  backgroundColor: formData.primaryColor,
                  borderRadius: formData.borderRadius === 'none' ? '0' : formData.borderRadius === 'small' ? '4px' : formData.borderRadius === 'large' ? '12px' : '8px'
                }}
              >
                Bouton primaire
              </Button>
              <Button 
                variant="outline"
                style={{ 
                  borderColor: formData.secondaryColor,
                  color: formData.secondaryColor,
                  borderRadius: formData.borderRadius === 'none' ? '0' : formData.borderRadius === 'small' ? '4px' : formData.borderRadius === 'large' ? '12px' : '8px'
                }}
              >
                Bouton secondaire
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setFormData({
          theme: 'light',
          primaryColor: '#3b82f6',
          secondaryColor: '#64748b',
          accentColor: '#f59e0b',
          backgroundColor: '#ffffff',
          surfaceColor: '#f8fafc',
          textColor: '#1e293b',
          fontFamily: 'Inter',
          fontSize: 'medium',
          lineHeight: 'relaxed',
          fontWeight: 'normal',
          sidebarCollapsed: false,
          sidebarWidth: '280',
          headerHeight: '64',
          footerEnabled: true,
          breadcrumbsEnabled: true,
          dashboardLayout: 'grid',
          widgetsPerRow: '3',
          showWidgetTitles: true,
          showWidgetBorders: true,
          widgetRounded: true,
          logoUrl: '',
          faviconUrl: '',
          customCSS: '',
          customJS: '',
          enableAnimations: true,
          animationDuration: 'normal',
          enableTransitions: true,
          transitionDuration: 'fast',
          highContrast: false,
          reducedMotion: false,
          largeText: false,
          focusVisible: true,
          density: 'comfortable',
          showShadows: true,
          showGradients: true,
          borderRadius: 'medium',
          language: 'fr',
          dateFormat: 'DD/MM/YYYY',
          timeFormat: '24h',
          numberFormat: 'fr-FR'
        })}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Réinitialiser
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
        </Button>
      </div>
    </div>
  );
}