'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Edit, Trash2, Search, GraduationCap, User, BookOpen, Calculator } from 'lucide-react'

interface Grade {
  id: string
  studentId: string
  student: {
    firstName: string
    lastName: string
    class: {
      name: string
    }
  }
  subjectId: string
  subject: {
    name: string
    code: string
  }
  examId: string
  exam: {
    title: string
    totalMarks: number
  }
  score: number
  maxScore: number
  remarks?: string
  createdAt: string
}

export default function GradeManagement() {
  const [grades, setGrades] = useState<Grade[]>([])
  const [students, setStudents] = useState<any[]>([])
  const [subjects, setSubjects] = useState<any[]>([])
  const [exams, setExams] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [subjectFilter, setSubjectFilter] = useState<string>('all')
  const [classFilter, setClassFilter] = useState<string>('all')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingGrade, setEditingGrade] = useState<Grade | null>(null)
  const [formData, setFormData] = useState({
    studentId: '',
    subjectId: '',
    examId: '',
    score: '',
    maxScore: '',
    remarks: ''
  })

  useEffect(() => {
    fetchGrades()
    fetchStudents()
    fetchSubjects()
    fetchExams()
  }, [])

  const fetchGrades = async () => {
    try {
      const response = await fetch('/api/grades')
      const data = await response.json()
      setGrades(data.grades || [])
    } catch (error) {
      console.error('Error fetching grades:', error)
    }
  }

  const fetchStudents = async () => {
    try {
      const response = await fetch('/api/students')
      const data = await response.json()
      setStudents(data.students || [])
    } catch (error) {
      console.error('Error fetching students:', error)
    }
  }

  const fetchSubjects = async () => {
    try {
      const response = await fetch('/api/subjects')
      const data = await response.json()
      setSubjects(data.subjects || [])
    } catch (error) {
      console.error('Error fetching subjects:', error)
    }
  }

  const fetchExams = async () => {
    try {
      const response = await fetch('/api/exams')
      const data = await response.json()
      setExams(data.exams || [])
    } catch (error) {
      console.error('Error fetching exams:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editingGrade ? `/api/grades/${editingGrade.id}` : '/api/grades'
      const method = editingGrade ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          studentId: formData.studentId,
          subjectId: formData.subjectId,
          examId: formData.examId,
          score: parseFloat(formData.score),
          maxScore: parseFloat(formData.maxScore),
          remarks: formData.remarks
        }),
      })

      if (response.ok) {
        fetchGrades()
        setIsDialogOpen(false)
        setEditingGrade(null)
        setFormData({
          studentId: '',
          subjectId: '',
          examId: '',
          score: '',
          maxScore: '',
          remarks: ''
        })
      }
    } catch (error) {
      console.error('Error saving grade:', error)
    }
  }

  const handleEdit = (grade: Grade) => {
    setEditingGrade(grade)
    setFormData({
      studentId: grade.studentId,
      subjectId: grade.subjectId,
      examId: grade.examId,
      score: grade.score.toString(),
      maxScore: grade.maxScore.toString(),
      remarks: grade.remarks || ''
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette note ?')) {
      try {
        const response = await fetch(`/api/grades/${id}`, {
          method: 'DELETE',
        })
        if (response.ok) {
          fetchGrades()
        }
      } catch (error) {
        console.error('Error deleting grade:', error)
      }
    }
  }

  const getGradeColor = (score: number, maxScore: number) => {
    const percentage = (score / maxScore) * 100
    if (percentage >= 90) return 'bg-green-100 text-green-800'
    if (percentage >= 80) return 'bg-blue-100 text-blue-800'
    if (percentage >= 70) return 'bg-yellow-100 text-yellow-800'
    if (percentage >= 60) return 'bg-orange-100 text-orange-800'
    return 'bg-red-100 text-red-800'
  }

  const getGradeText = (score: number, maxScore: number) => {
    const percentage = (score / maxScore) * 100
    if (percentage >= 90) return 'Excellent'
    if (percentage >= 80) return 'Très bien'
    if (percentage >= 70) return 'Bien'
    if (percentage >= 60) return 'Assez bien'
    return 'Insuffisant'
  }

  const filteredGrades = grades.filter(grade => {
    const matchesSearch = 
      grade.student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      grade.student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      grade.subject.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      grade.exam.title.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesSubject = subjectFilter === 'all' || grade.subjectId === subjectFilter
    const matchesClass = classFilter === 'all' || grade.student.class.id === classFilter
    
    return matchesSearch && matchesSubject && matchesClass
  })

  const averageGrade = grades.length > 0 
    ? grades.reduce((sum, grade) => sum + (grade.score / grade.maxScore) * 100, 0) / grades.length 
    : 0

  const highestGrade = grades.length > 0 
    ? Math.max(...grades.map(g => (g.score / g.maxScore) * 100))
    : 0

  const lowestGrade = grades.length > 0 
    ? Math.min(...grades.map(g => (g.score / g.maxScore) * 100))
    : 0

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Notes</h2>
          <p className="text-gray-600">Gérez les notes des étudiants</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingGrade(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle Note
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingGrade ? 'Modifier la note' : 'Nouvelle note'}
              </DialogTitle>
              <DialogDescription>
                {editingGrade ? 'Modifiez les informations de la note' : 'Créez une nouvelle note'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="student">Étudiant</Label>
                <Select value={formData.studentId} onValueChange={(value) => setFormData({ ...formData, studentId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez un étudiant" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.firstName} {student.lastName} - {student.class.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="subject">Matière</Label>
                <Select value={formData.subjectId} onValueChange={(value) => setFormData({ ...formData, subjectId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez une matière" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id}>
                        {subject.name} ({subject.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="exam">Examen</Label>
                <Select value={formData.examId} onValueChange={(value) => setFormData({ ...formData, examId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez un examen" />
                  </SelectTrigger>
                  <SelectContent>
                    {exams.map((exam) => (
                      <SelectItem key={exam.id} value={exam.id}>
                        {exam.title} ({exam.totalMarks} points)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="score">Note obtenue</Label>
                  <Input
                    id="score"
                    type="number"
                    step="0.01"
                    value={formData.score}
                    onChange={(e) => setFormData({ ...formData, score: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="maxScore">Note maximale</Label>
                  <Input
                    id="maxScore"
                    type="number"
                    step="0.01"
                    value={formData.maxScore}
                    onChange={(e) => setFormData({ ...formData, maxScore: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="remarks">Remarques</Label>
                <Input
                  id="remarks"
                  value={formData.remarks}
                  onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingGrade ? 'Modifier' : 'Créer'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Moyenne générale</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageGrade.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {grades.length} note{grades.length > 1 ? 's' : ''}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Note la plus élevée</CardTitle>
            <GraduationCap className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{highestGrade.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              Excellent
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Note la plus basse</CardTitle>
            <GraduationCap className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{lowestGrade.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              À améliorer
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total des notes</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{grades.length}</div>
            <p className="text-xs text-muted-foreground">
              Enregistrées
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Liste des Notes</CardTitle>
          <CardDescription>
            {grades.length} note{grades.length > 1 ? 's' : ''} au total
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <Search className="h-4 w-4 text-gray-400" />
            <Input
              placeholder="Rechercher une note..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            <Select value={subjectFilter} onValueChange={setSubjectFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Matière" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes</SelectItem>
                {subjects.map((subject) => (
                  <SelectItem key={subject.id} value={subject.id}>
                    {subject.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Classe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes</SelectItem>
                {Array.from(new Set(students.map(s => s.class))).map((cls: any) => (
                  <SelectItem key={cls.id} value={cls.id}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Étudiant</TableHead>
                <TableHead>Matière</TableHead>
                <TableHead>Examen</TableHead>
                <TableHead>Note</TableHead>
                <TableHead>Pourcentage</TableHead>
                <TableHead>Appréciation</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredGrades.map((grade) => {
                const percentage = (grade.score / grade.maxScore) * 100
                return (
                  <TableRow key={grade.id}>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-gray-400" />
                        <div>
                          <div className="font-medium">
                            {grade.student.firstName} {grade.student.lastName}
                          </div>
                          <div className="text-sm text-gray-500">
                            {grade.student.class.name}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <BookOpen className="h-4 w-4 text-gray-400" />
                        <div>
                          <div className="font-medium">{grade.subject.name}</div>
                          <div className="text-sm text-gray-500">{grade.subject.code}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{grade.exam.title}</div>
                        <div className="text-sm text-gray-500">
                          Max: {grade.exam.totalMarks} points
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {grade.score}/{grade.maxScore}
                    </TableCell>
                    <TableCell>
                      <Badge className={getGradeColor(grade.score, grade.maxScore)}>
                        {percentage.toFixed(1)}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {getGradeText(grade.score, grade.maxScore)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(grade)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(grade.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}