'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Edit, Trash2, Search, Calendar, User, CheckCircle, XCircle, Clock } from 'lucide-react'

interface Attendance {
  id: string
  studentId: string
  student: {
    firstName: string
    lastName: string
    class: {
      name: string
    }
  }
  date: string
  status: 'PRESENT' | 'ABSENT' | 'LATE' | 'EXCUSED'
  notes?: string
}

export default function AttendanceManagement() {
  const [attendances, setAttendances] = useState<Attendance[]>([])
  const [students, setStudents] = useState<any[]>([])
  const [classes, setClasses] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [classFilter, setClassFilter] = useState<string>('all')
  const [dateFilter, setDateFilter] = useState<string>('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingAttendance, setEditingAttendance] = useState<Attendance | null>(null)
  const [formData, setFormData] = useState({
    studentId: '',
    date: '',
    status: '',
    notes: ''
  })

  useEffect(() => {
    fetchAttendances()
    fetchStudents()
    fetchClasses()
    // Set today's date as default
    setFormData(prev => ({ ...prev, date: new Date().toISOString().split('T')[0] }))
    setDateFilter(new Date().toISOString().split('T')[0])
  }, [])

  const fetchAttendances = async () => {
    try {
      const response = await fetch('/api/attendance')
      const data = await response.json()
      setAttendances(data.attendance || [])
    } catch (error) {
      console.error('Error fetching attendances:', error)
    }
  }

  const fetchStudents = async () => {
    try {
      const response = await fetch('/api/students')
      const data = await response.json()
      setStudents(data.students || [])
    } catch (error) {
      console.error('Error fetching students:', error)
    }
  }

  const fetchClasses = async () => {
    try {
      const response = await fetch('/api/classes')
      const data = await response.json()
      setClasses(data.classes || [])
    } catch (error) {
      console.error('Error fetching classes:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editingAttendance ? `/api/attendance/${editingAttendance.id}` : '/api/attendance'
      const method = editingAttendance ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          studentId: formData.studentId,
          date: formData.date,
          status: formData.status,
          notes: formData.notes
        }),
      })

      if (response.ok) {
        fetchAttendances()
        setIsDialogOpen(false)
        setEditingAttendance(null)
        setFormData({
          studentId: '',
          date: new Date().toISOString().split('T')[0],
          status: '',
          notes: ''
        })
      }
    } catch (error) {
      console.error('Error saving attendance:', error)
    }
  }

  const handleEdit = (attendance: Attendance) => {
    setEditingAttendance(attendance)
    setFormData({
      studentId: attendance.studentId,
      date: attendance.date,
      status: attendance.status,
      notes: attendance.notes || ''
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette présence ?')) {
      try {
        const response = await fetch(`/api/attendance/${id}`, {
          method: 'DELETE',
        })
        if (response.ok) {
          fetchAttendances()
        }
      } catch (error) {
        console.error('Error deleting attendance:', error)
      }
    }
  }

  const handleBulkAttendance = async (classId: string, date: string, status: string) => {
    try {
      const classStudents = students.filter(student => student.classId === classId)
      
      for (const student of classStudents) {
        await fetch('/api/attendance', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            studentId: student.id,
            date,
            status,
            notes: ''
          }),
        })
      }
      
      fetchAttendances()
    } catch (error) {
      console.error('Error recording bulk attendance:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PRESENT':
        return 'bg-green-100 text-green-800'
      case 'ABSENT':
        return 'bg-red-100 text-red-800'
      case 'LATE':
        return 'bg-yellow-100 text-yellow-800'
      case 'EXCUSED':
        return 'bg-blue-100 text-blue-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PRESENT':
        return <CheckCircle className="h-4 w-4" />
      case 'ABSENT':
        return <XCircle className="h-4 w-4" />
      case 'LATE':
        return <Clock className="h-4 w-4" />
      case 'EXCUSED':
        return <Calendar className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'PRESENT':
        return 'Présent'
      case 'ABSENT':
        return 'Absent'
      case 'LATE':
        return 'En retard'
      case 'EXCUSED':
        return 'Excusé'
      default:
        return status
    }
  }

  const filteredAttendances = attendances.filter(attendance => {
    const matchesSearch = 
      attendance.student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      attendance.student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      attendance.student.class.name.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = statusFilter === 'all' || attendance.status === statusFilter
    const matchesClass = classFilter === 'all' || attendance.student.classId === classFilter
    const matchesDate = !dateFilter || attendance.date === dateFilter
    
    return matchesSearch && matchesStatus && matchesClass && matchesDate
  })

  const todayAttendances = attendances.filter(a => a.date === new Date().toISOString().split('T')[0])
  const presentCount = todayAttendances.filter(a => a.status === 'PRESENT').length
  const absentCount = todayAttendances.filter(a => a.status === 'ABSENT').length
  const lateCount = todayAttendances.filter(a => a.status === 'LATE').length

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Présences</h2>
          <p className="text-gray-600">Suivez les présences et absences des étudiants</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingAttendance(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle Présence
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingAttendance ? 'Modifier la présence' : 'Nouvelle présence'}
              </DialogTitle>
              <DialogDescription>
                {editingAttendance ? 'Modifiez les informations de présence' : 'Enregistrez une nouvelle présence'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="student">Étudiant</Label>
                <Select value={formData.studentId} onValueChange={(value) => setFormData({ ...formData, studentId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez un étudiant" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.firstName} {student.lastName} - {student.class.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="status">Statut</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez un statut" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PRESENT">Présent</SelectItem>
                      <SelectItem value="ABSENT">Absent</SelectItem>
                      <SelectItem value="LATE">En retard</SelectItem>
                      <SelectItem value="EXCUSED">Excusé</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Input
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Ajoutez des notes optionnelles..."
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingAttendance ? 'Modifier' : 'Enregistrer'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Présents aujourd'hui</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{presentCount}</div>
            <p className="text-xs text-muted-foreground">
              {todayAttendances.length > 0 && Math.round((presentCount / todayAttendances.length) * 100)}% de présence
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Absents aujourd'hui</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{absentCount}</div>
            <p className="text-xs text-muted-foreground">
              {todayAttendances.length > 0 && Math.round((absentCount / todayAttendances.length) * 100)}% d'absence
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">En retard aujourd'hui</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{lateCount}</div>
            <p className="text-xs text-muted-foreground">
              {todayAttendances.length > 0 && Math.round((lateCount / todayAttendances.length) * 100)}% en retard
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total enregistrées</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendances.length}</div>
            <p className="text-xs text-muted-foreground">
              Présences au total
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Liste des Présences</CardTitle>
          <CardDescription>
            {attendances.length} présence{attendances.length > 1 ? 's' : ''} au total
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <Search className="h-4 w-4 text-gray-400" />
            <Input
              placeholder="Rechercher une présence..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            <Input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-40"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                <SelectItem value="PRESENT">Présents</SelectItem>
                <SelectItem value="ABSENT">Absents</SelectItem>
                <SelectItem value="LATE">En retard</SelectItem>
                <SelectItem value="EXCUSED">Excusés</SelectItem>
              </SelectContent>
            </Select>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Classe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes</SelectItem>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Étudiant</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAttendances.map((attendance) => (
                <TableRow key={attendance.id}>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <div>
                        <div className="font-medium">
                          {attendance.student.firstName} {attendance.student.lastName}
                        </div>
                        <div className="text-sm text-gray-500">
                          {attendance.student.class.name}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span>{new Date(attendance.date).toLocaleDateString()}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(attendance.status)}>
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(attendance.status)}
                        <span>{getStatusText(attendance.status)}</span>
                      </div>
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {attendance.notes ? (
                      <span className="text-sm text-gray-600">{attendance.notes}</span>
                    ) : (
                      <span className="text-sm text-gray-400">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(attendance)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(attendance.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}