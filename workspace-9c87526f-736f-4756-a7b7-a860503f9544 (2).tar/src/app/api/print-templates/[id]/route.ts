import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Récupérer un modèle d'impression spécifique
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const template = await db.printTemplate.findUnique({
      where: { id: params.id }
    })

    if (!template) {
      return NextResponse.json(
        { error: 'Print template not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(template)
  } catch (error) {
    console.error('Error fetching print template:', error)
    return NextResponse.json(
      { error: 'Failed to fetch print template' },
      { status: 500 }
    )
  }
}

// PUT - Mettre à jour un modèle d'impression
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const {
      name,
      type,
      description,
      logo,
      header,
      footer,
      content,
      pageSize,
      orientation,
      margins,
      isActive
    } = body

    const template = await db.printTemplate.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(type && { type }),
        ...(description !== undefined && { description }),
        ...(logo !== undefined && { logo }),
        ...(header !== undefined && { header }),
        ...(footer !== undefined && { footer }),
        ...(content !== undefined && { content }),
        ...(pageSize && { pageSize }),
        ...(orientation && { orientation }),
        ...(margins && {
          marginTop: margins.top,
          marginRight: margins.right,
          marginBottom: margins.bottom,
          marginLeft: margins.left
        }),
        ...(isActive !== undefined && { isActive })
      }
    })

    return NextResponse.json(template)
  } catch (error) {
    console.error('Error updating print template:', error)
    return NextResponse.json(
      { error: 'Failed to update print template' },
      { status: 500 }
    )
  }
}

// DELETE - Supprimer un modèle d'impression
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.printTemplate.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting print template:', error)
    return NextResponse.json(
      { error: 'Failed to delete print template' },
      { status: 500 }
    )
  }
}