import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Récupérer tous les modèles d'impression
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const active = searchParams.get('active')

    let whereClause = {}
    
    if (type) {
      whereClause = { ...whereClause, type }
    }
    
    if (active === 'true') {
      whereClause = { ...whereClause, isActive: true }
    }

    const templates = await db.printTemplate.findMany({
      where: whereClause,
      orderBy: [
        { type: 'asc' },
        { name: 'asc' }
      ]
    })

    return NextResponse.json(templates)
  } catch (error) {
    console.error('Error fetching print templates:', error)
    return NextResponse.json(
      { error: 'Failed to fetch print templates' },
      { status: 500 }
    )
  }
}

// POST - Créer un nouveau modèle d'impression
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      name,
      type,
      description,
      logo,
      header,
      footer,
      content,
      pageSize,
      orientation,
      margins,
      isActive
    } = body

    if (!name || !type) {
      return NextResponse.json(
        { error: 'Name and type are required' },
        { status: 400 }
      )
    }

    const template = await db.printTemplate.create({
      data: {
        name,
        type,
        description,
        logo,
        header,
        footer,
        content,
        pageSize: pageSize || 'A4',
        orientation: orientation || 'portrait',
        marginTop: margins?.top || 20,
        marginRight: margins?.right || 20,
        marginBottom: margins?.bottom || 20,
        marginLeft: margins?.left || 20,
        isActive: isActive !== undefined ? isActive : true
      }
    })

    return NextResponse.json(template, { status: 201 })
  } catch (error) {
    console.error('Error creating print template:', error)
    return NextResponse.json(
      { error: 'Failed to create print template' },
      { status: 500 }
    )
  }
}