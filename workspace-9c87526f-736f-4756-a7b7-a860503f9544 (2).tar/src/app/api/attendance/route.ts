import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const date = searchParams.get('date');
    const classId = searchParams.get('classId');
    const studentId = searchParams.get('studentId');
    const status = searchParams.get('status');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (date) {
      where.date = date;
    }

    if (classId) {
      where.student = {
        classId: classId
      };
    }

    if (studentId) {
      where.studentId = studentId;
    }

    if (status) {
      where.status = status;
    }

    const [attendance, total] = await Promise.all([
      db.attendance.findMany({
        where,
        skip,
        take: limit,
        include: {
          student: {
            include: {
              class: true
            }
          }
        },
        orderBy: { date: 'desc' }
      }),
      db.attendance.count({ where })
    ]);

    return NextResponse.json({
      attendance,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get attendance error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { studentId, date, status, notes } = await request.json();

    if (!studentId || !date || !status) {
      return NextResponse.json(
        { error: 'Student ID, date, and status are required' },
        { status: 400 }
      );
    }

    // Check if attendance already exists for this student and date
    const existingAttendance = await db.attendance.findFirst({
      where: {
        studentId,
        date
      }
    });

    if (existingAttendance) {
      return NextResponse.json(
        { error: 'Attendance already recorded for this student on this date' },
        { status: 409 }
      );
    }

    const attendance = await db.attendance.create({
      data: {
        studentId,
        date,
        status,
        notes
      },
      include: {
        student: {
          include: {
            class: true
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Attendance recorded successfully',
      attendance
    });

  } catch (error) {
    console.error('Create attendance error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}