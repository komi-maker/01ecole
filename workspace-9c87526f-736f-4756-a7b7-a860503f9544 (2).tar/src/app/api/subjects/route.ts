import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';

    const skip = (page - 1) * limit;

    const where: any = {};

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ];
    }

    const [subjects, total] = await Promise.all([
      db.subject.findMany({
        where,
        skip,
        take: limit,
        include: {
          _count: {
            select: {
              grades: true,
              schedules: true,
              attendances: true
            }
          }
        },
        orderBy: { name: 'asc' }
      }),
      db.subject.count({ where })
    ]);

    return NextResponse.json({
      subjects,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get subjects error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, code, description, credits, classId, teacherId } = await request.json();

    if (!name || !code) {
      return NextResponse.json(
        { error: 'Name and code are required' },
        { status: 400 }
      );
    }

    const subject = await db.subject.create({
      data: {
        name,
        code,
        description,
        credits,
        classId,
        teacherId
      }
    });

    return NextResponse.json({
      message: 'Subject created successfully',
      subject
    });

  } catch (error) {
    console.error('Create subject error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}