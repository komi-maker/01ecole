import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Récupérer tous les paramètres
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')

    let settings
    if (category) {
      settings = await db.appSettings.findMany({
        where: { category }
      })
    } else {
      settings = await db.appSettings.findMany()
    }

    // Grouper les paramètres par catégorie
    const groupedSettings = settings.reduce((acc, setting) => {
      if (!acc[setting.category]) {
        acc[setting.category] = {}
      }
      
      // Convertir la valeur selon le type
      let value = setting.value
      if (setting.type === 'number') {
        value = parseFloat(setting.value)
      } else if (setting.type === 'boolean') {
        value = setting.value === 'true'
      } else if (setting.type === 'json') {
        value = JSON.parse(setting.value)
      }
      
      acc[setting.category][setting.key] = value
      return acc
    }, {} as Record<string, Record<string, any>>)

    return NextResponse.json(groupedSettings)
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch settings' },
      { status: 500 }
    )
  }
}

// POST - Mettre à jour les paramètres
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { category, settings } = body

    if (!category || !settings) {
      return NextResponse.json(
        { error: 'Category and settings are required' },
        { status: 400 }
      )
    }

    // Mettre à jour chaque paramètre
    const updatePromises = Object.entries(settings).map(async ([key, value]) => {
      const type = typeof value === 'number' ? 'number' : 
                   typeof value === 'boolean' ? 'boolean' : 
                   typeof value === 'object' ? 'json' : 'string'

      const stringValue = typeof value === 'object' ? JSON.stringify(value) : String(value)

      return db.appSettings.upsert({
        where: {
          category_key: {
            category,
            key
          }
        },
        update: {
          value: stringValue,
          type
        },
        create: {
          category,
          key,
          value: stringValue,
          type
        }
      })
    })

    await Promise.all(updatePromises)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json(
      { error: 'Failed to update settings' },
      { status: 500 }
    )
  }
}

// DELETE - Supprimer un paramètre
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const key = searchParams.get('key')

    if (!category || !key) {
      return NextResponse.json(
        { error: 'Category and key are required' },
        { status: 400 }
      )
    }

    await db.appSettings.delete({
      where: {
        category_key: {
          category,
          key
        }
      }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting setting:', error)
    return NextResponse.json(
      { error: 'Failed to delete setting' },
      { status: 500 }
    )
  }
}