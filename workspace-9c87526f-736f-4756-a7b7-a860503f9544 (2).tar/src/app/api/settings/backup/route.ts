import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    // Simuler une sauvegarde
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const backupData = {
      id: `backup_${Date.now()}`,
      timestamp: new Date().toISOString(),
      size: '2.3 MB',
      status: 'completed',
      location: '/backups/ecoleplus_backup_2024-01-15_14-30-00.zip'
    };

    return NextResponse.json({
      message: 'Backup completed successfully',
      backup: backupData
    });

  } catch (error) {
    console.error('Backup error:', error);
    return NextResponse.json(
      { error: 'Backup failed' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    // Simuler la récupération de la liste des sauvegardes
    const backups = [
      {
        id: 'backup_1705316400000',
        timestamp: '2024-01-15T14:30:00Z',
        size: '2.3 MB',
        status: 'completed',
        location: '/backups/ecoleplus_backup_2024-01-15_14-30-00.zip'
      },
      {
        id: 'backup_1705230000000',
        timestamp: '2024-01-14T14:30:00Z',
        size: '2.2 MB',
        status: 'completed',
        location: '/backups/ecoleplus_backup_2024-01-14_14-30-00.zip'
      },
      {
        id: 'backup_1705143600000',
        timestamp: '2024-01-13T14:30:00Z',
        size: '2.1 MB',
        status: 'completed',
        location: '/backups/ecoleplus_backup_2024-01-13_14-30-00.zip'
      }
    ];

    return NextResponse.json({
      backups
    });

  } catch (error) {
    console.error('Get backups error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}