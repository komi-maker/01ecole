import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST - Réinitialiser les paramètres par défaut
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { category } = body

    // Paramètres par défaut
    const defaultSettings = {
      general: {
        schoolName: 'ÉcolePro Manager',
        schoolAddress: '123 Rue de l\'Éducation, 75000 Paris',
        schoolPhone: '+33 1 23 45 67 89',
        schoolEmail: 'contact@ecolepro.fr',
        schoolWebsite: 'www.ecolepro.fr',
        directorName: 'M. Jean Dupont',
        schoolType: 'primaire',
        academicYear: '2024-2025',
        currency: 'EUR',
        timezone: 'Europe/Paris',
        language: 'fr'
      },
      notifications: {
        emailNotifications: 'true',
        smsNotifications: 'false',
        pushNotifications: 'true',
        paymentReminders: 'true',
        attendanceAlerts: 'true',
        gradeNotifications: 'true',
        systemUpdates: 'false',
        weeklyReports: 'true'
      },
      appearance: {
        theme: 'light',
        primaryColor: '#3b82f6',
        compactMode: 'false',
        showAnimations: 'true'
      },
      security: {
        twoFactorAuth: 'false',
        sessionTimeout: '30',
        passwordPolicy: 'true',
        loginAttempts: '5',
        ipWhitelist: 'false',
        auditLog: 'true',
        dataEncryption: 'true'
      }
    }

    // Si une catégorie spécifique est demandée
    if (category && defaultSettings[category as keyof typeof defaultSettings]) {
      // Supprimer les paramètres existants pour cette catégorie
      await db.appSettings.deleteMany({
        where: { category }
      })

      // Créer les paramètres par défaut pour cette catégorie
      const settingsToCreate = Object.entries(defaultSettings[category as keyof typeof defaultSettings]).map(([key, value]) => ({
        category,
        key,
        value,
        type: typeof value === 'number' ? 'number' : 
              typeof value === 'boolean' ? 'boolean' : 
              'string'
      }))

      await db.appSettings.createMany({
        data: settingsToCreate
      })

      return NextResponse.json({ 
        success: true, 
        message: `Settings for category '${category}' reset to defaults` 
      })
    }

    // Si aucune catégorie spécifique, réinitialiser tout
    if (!category) {
      // Supprimer tous les paramètres existants
      await db.appSettings.deleteMany()

      // Créer tous les paramètres par défaut
      const allSettingsToCreate = Object.entries(defaultSettings).flatMap(([cat, settings]) =>
        Object.entries(settings).map(([key, value]) => ({
          category: cat,
          key,
          value,
          type: typeof value === 'number' ? 'number' : 
                typeof value === 'boolean' ? 'boolean' : 
                'string'
        }))
      )

      await db.appSettings.createMany({
        data: allSettingsToCreate
      })

      return NextResponse.json({ 
        success: true, 
        message: 'All settings reset to defaults' 
      })
    }

    return NextResponse.json(
      { error: 'Invalid category' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Error resetting settings:', error)
    return NextResponse.json(
      { error: 'Failed to reset settings' },
      { status: 500 }
    )
  }
}