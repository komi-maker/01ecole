import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const studentId = searchParams.get('studentId');
    const subjectId = searchParams.get('subjectId');
    const examId = searchParams.get('examId');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (studentId) {
      where.studentId = studentId;
    }

    if (subjectId) {
      where.subjectId = subjectId;
    }

    if (examId) {
      where.examId = examId;
    }

    const [grades, total] = await Promise.all([
      db.grade.findMany({
        where,
        skip,
        take: limit,
        include: {
          student: {
            include: {
              class: true
            }
          },
          subject: true,
          teacher: true
        },
        orderBy: { createdAt: 'desc' }
      }),
      db.grade.count({ where })
    ]);

    return NextResponse.json({
      grades,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get grades error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { studentId, subjectId, teacherId, type, value, max, coefficient, semester, date, remarks } = await request.json();

    if (!studentId || !subjectId || !value || !max) {
      return NextResponse.json(
        { error: 'All required fields must be provided' },
        { status: 400 }
      );
    }

    const grade = await db.grade.create({
      data: {
        studentId,
        subjectId,
        teacherId,
        type,
        value,
        max,
        coefficient,
        semester,
        date: new Date(date),
        remarks
      },
      include: {
        student: {
          include: {
            class: true
          }
        },
        subject: true,
        teacher: true
      }
    });

    return NextResponse.json({
      message: 'Grade created successfully',
      grade
    });

  } catch (error) {
    console.error('Create grade error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}