import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    // Get total counts
    const [
      totalStudents,
      totalTeachers,
      totalClasses,
      totalSubjects,
      activeStudents,
      activeTeachers,
      todayAttendance,
      pendingFees
    ] = await Promise.all([
      db.student.count(),
      db.teacher.count(),
      db.class.count(),
      db.subject.count(),
      db.student.count({ where: { isActive: true } }),
      db.teacher.count({ where: { isActive: true } }),
      db.attendance.count({
        where: {
          date: new Date().toISOString().split('T')[0]
        }
      }),
      db.fee.count({
        where: {
          status: 'PENDING'
        }
      })
    ]);

    // Get recent activities
    const recentActivities = await db.activityLog.findMany({
      take: 10,
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true
          }
        }
      }
    });

    // Get upcoming events
    const upcomingEvents = await db.event.findMany({
      take: 5,
      where: {
        date: {
          gte: new Date()
        }
      },
      orderBy: { date: 'asc' }
    });

    // Get class distribution
    const classDistribution = await db.class.findMany({
      select: {
        id: true,
        name: true,
        _count: {
          select: {
            students: true
          }
        }
      }
    });

    // Get gender distribution
    const genderDistribution = await db.student.groupBy({
      by: ['gender'],
      _count: {
        gender: true
      }
    });

    return NextResponse.json({
      stats: {
        totalStudents,
        totalTeachers,
        totalClasses,
        totalSubjects,
        activeStudents,
        activeTeachers,
        todayAttendance,
        pendingFees
      },
      recentActivities,
      upcomingEvents,
      classDistribution,
      genderDistribution
    });

  } catch (error) {
    console.error('Dashboard stats error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}