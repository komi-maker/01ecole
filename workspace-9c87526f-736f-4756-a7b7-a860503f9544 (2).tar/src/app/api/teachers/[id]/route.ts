import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const teacher = await db.teacher.findUnique({
      where: { id: params.id },
      include: {
        user: true,
        subjects: {
          include: {
            subject: true
          }
        },
        classes: {
          include: {
            class: true
          }
        },
        schedules: {
          include: {
            class: true,
            subject: true
          },
          orderBy: { startTime: 'asc' }
        }
      }
    });

    if (!teacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      teacher
    });

  } catch (error) {
    console.error('Get teacher error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const {
      teacherId,
      firstName,
      lastName,
      dateOfBirth,
      gender,
      address,
      phone,
      email,
      userId,
      hireDate,
      salary,
      qualification,
      experience,
      emergencyContact,
      isActive
    } = await request.json();

    // Check if teacher exists
    const existingTeacher = await db.teacher.findUnique({
      where: { id: params.id }
    });

    if (!existingTeacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      );
    }

    // Check if teacher ID is being changed and if it's already taken
    if (teacherId && teacherId !== existingTeacher.teacherId) {
      const idTaken = await db.teacher.findUnique({
        where: { teacherId }
      });

      if (idTaken) {
        return NextResponse.json(
          { error: 'Teacher ID is already taken' },
          { status: 409 }
        );
      }
    }

    const teacher = await db.teacher.update({
      where: { id: params.id },
      data: {
        teacherId,
        firstName,
        lastName,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
        gender,
        address,
        phone,
        email,
        userId,
        hireDate: hireDate ? new Date(hireDate) : undefined,
        salary,
        qualification,
        experience,
        emergencyContact,
        isActive
      },
      include: {
        user: true,
        subjects: {
          include: {
            subject: true
          }
        },
        classes: {
          include: {
            class: true
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Teacher updated successfully',
      teacher
    });

  } catch (error) {
    console.error('Update teacher error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check if teacher exists
    const existingTeacher = await db.teacher.findUnique({
      where: { id: params.id }
    });

    if (!existingTeacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      );
    }

    await db.teacher.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      message: 'Teacher deleted successfully'
    });

  } catch (error) {
    console.error('Delete teacher error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}