import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const subjectId = searchParams.get('subjectId');
    const gender = searchParams.get('gender');
    const isActive = searchParams.get('isActive');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { teacherId: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } }
      ];
    }

    if (subjectId) {
      where.subjects = {
        some: {
          subjectId: subjectId
        }
      };
    }

    if (gender) {
      where.gender = gender;
    }

    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }

    const [teachers, total] = await Promise.all([
      db.teacher.findMany({
        where,
        skip,
        take: limit,
        include: {
          user: true,
          subjects: {
            include: {
              subject: true
            }
          },
          classes: {
            include: {
              class: true
            }
          }
        },
        orderBy: { hireDate: 'desc' }
      }),
      db.teacher.count({ where })
    ]);

    return NextResponse.json({
      teachers,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get teachers error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const {
      teacherId,
      userId,
      department,
      salary
    } = await request.json();

    if (!teacherId || !userId) {
      return NextResponse.json(
        { error: 'All required fields must be provided' },
        { status: 400 }
      );
    }

    // Check if teacher ID already exists
    const existingTeacher = await db.teacher.findUnique({
      where: { teacherId }
    });

    if (existingTeacher) {
      return NextResponse.json(
        { error: 'Teacher with this ID already exists' },
        { status: 409 }
      );
    }

    // Create teacher
    const teacher = await db.teacher.create({
      data: {
        teacherId,
        userId,
        department,
        salary
      },
      include: {
        user: true,
        subjects: true,
        classes: {
          include: {
            class: true
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Teacher created successfully',
      teacher
    });

  } catch (error) {
    console.error('Create teacher error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}