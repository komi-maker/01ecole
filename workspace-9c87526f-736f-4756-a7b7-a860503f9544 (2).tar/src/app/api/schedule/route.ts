import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const classId = searchParams.get('classId');
    const teacherId = searchParams.get('teacherId');
    const dayOfWeek = searchParams.get('dayOfWeek');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (classId) {
      where.classId = classId;
    }

    if (teacherId) {
      where.teacherId = teacherId;
    }

    if (dayOfWeek) {
      where.dayOfWeek = parseInt(dayOfWeek);
    }

    const [schedules, total] = await Promise.all([
      db.schedule.findMany({
        where,
        skip,
        take: limit,
        include: {
          class: true,
          subject: true
        },
        orderBy: [
          { dayOfWeek: 'asc' },
          { startTime: 'asc' }
        ]
      }),
      db.schedule.count({ where })
    ]);

    return NextResponse.json({
      schedules,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get schedules error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { classId, subjectId, dayOfWeek, startTime, endTime, room, semester } = await request.json();

    if (!classId || !subjectId || dayOfWeek === undefined || !startTime || !endTime) {
      return NextResponse.json(
        { error: 'All required fields must be provided' },
        { status: 400 }
      );
    }

    const schedule = await db.schedule.create({
      data: {
        classId,
        subjectId,
        dayOfWeek,
        startTime,
        endTime,
        room,
        semester
      },
      include: {
        class: true,
        subject: true
      }
    });

    return NextResponse.json({
      message: 'Schedule created successfully',
      schedule
    });

  } catch (error) {
    console.error('Create schedule error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}