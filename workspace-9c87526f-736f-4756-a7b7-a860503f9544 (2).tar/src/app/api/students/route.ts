import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const classId = searchParams.get('classId');
    const gender = searchParams.get('gender');
    const isActive = searchParams.get('isActive');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { studentId: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } }
      ];
    }

    if (classId) {
      where.classId = classId;
    }

    if (gender) {
      where.gender = gender;
    }

    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }

    const [students, total] = await Promise.all([
      db.student.findMany({
        where,
        skip,
        take: limit,
        include: {
          class: true,
          parent: {
            include: {
              user: true
            }
          }
        },
        orderBy: { enrollmentDate: 'desc' }
      }),
      db.student.count({ where })
    ]);

    return NextResponse.json({
      students,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get students error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const {
      studentId,
      userId,
      classId,
      parentId
    } = await request.json();

    if (!studentId || !userId) {
      return NextResponse.json(
        { error: 'All required fields must be provided' },
        { status: 400 }
      );
    }

    // Check if student ID already exists
    const existingStudent = await db.student.findUnique({
      where: { studentId }
    });

    if (existingStudent) {
      return NextResponse.json(
        { error: 'Student with this ID already exists' },
        { status: 409 }
      );
    }

    // Create student
    const student = await db.student.create({
      data: {
        studentId,
        userId,
        classId,
        parentId
      },
      include: {
        class: true,
        parent: {
          include: {
            user: true
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Student created successfully',
      student
    });

  } catch (error) {
    console.error('Create student error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}