import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const student = await db.student.findUnique({
      where: { id: params.id },
      include: {
        class: true,
        parent: {
          include: {
            user: true
          }
        },
        attendance: {
          orderBy: { date: 'desc' },
          take: 10
        },
        grades: {
          include: {
            subject: true,
            exam: true
          },
          orderBy: { createdAt: 'desc' }
        },
        fees: {
          orderBy: { dueDate: 'desc' }
        }
      }
    });

    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      student
    });

  } catch (error) {
    console.error('Get student error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const {
      studentId,
      firstName,
      lastName,
      dateOfBirth,
      gender,
      address,
      phone,
      email,
      classId,
      parentId,
      admissionDate,
      emergencyContact,
      isActive
    } = await request.json();

    // Check if student exists
    const existingStudent = await db.student.findUnique({
      where: { id: params.id }
    });

    if (!existingStudent) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      );
    }

    // Check if student ID is being changed and if it's already taken
    if (studentId && studentId !== existingStudent.studentId) {
      const idTaken = await db.student.findUnique({
        where: { studentId }
      });

      if (idTaken) {
        return NextResponse.json(
          { error: 'Student ID is already taken' },
          { status: 409 }
        );
      }
    }

    const student = await db.student.update({
      where: { id: params.id },
      data: {
        studentId,
        firstName,
        lastName,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
        gender,
        address,
        phone,
        email,
        classId,
        parentId,
        admissionDate: admissionDate ? new Date(admissionDate) : undefined,
        emergencyContact,
        isActive
      },
      include: {
        class: true,
        parent: {
          include: {
            user: true
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Student updated successfully',
      student
    });

  } catch (error) {
    console.error('Update student error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check if student exists
    const existingStudent = await db.student.findUnique({
      where: { id: params.id }
    });

    if (!existingStudent) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      );
    }

    await db.student.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      message: 'Student deleted successfully'
    });

  } catch (error) {
    console.error('Delete student error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}