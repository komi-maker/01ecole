import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const classId = searchParams.get('classId');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    let data: any = {};

    switch (type) {
      case 'attendance':
        data = await generateAttendanceReport(classId, startDate, endDate);
        break;
      case 'grades':
        data = await generateGradesReport(classId, startDate, endDate);
        break;
      case 'payments':
        data = await generatePaymentsReport(classId, startDate, endDate);
        break;
      case 'enrollment':
        data = await generateEnrollmentReport(classId, startDate, endDate);
        break;
      default:
        return NextResponse.json(
          { error: 'Invalid report type' },
          { status: 400 }
        );
    }

    return NextResponse.json({
      type,
      data,
      generatedAt: new Date()
    });

  } catch (error) {
    console.error('Generate report error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

async function generateAttendanceReport(classId?: string, startDate?: string, endDate?: string) {
  const where: any = {};
  
  if (classId) {
    where.student = { classId };
  }
  
  if (startDate && endDate) {
    where.date = {
      gte: startDate,
      lte: endDate
    };
  }

  const attendance = await db.attendance.findMany({
    where,
    include: {
      student: {
        include: {
          class: true
        }
      }
    },
    orderBy: { date: 'desc' }
  });

  const summary = attendance.reduce((acc: any, record) => {
    const status = record.status;
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  return { attendance, summary };
}

async function generateGradesReport(classId?: string, startDate?: string, endDate?: string) {
  const where: any = {};
  
  if (classId) {
    where.student = { classId };
  }
  
  if (startDate && endDate) {
    where.createdAt = {
      gte: new Date(startDate),
      lte: new Date(endDate)
    };
  }

  const grades = await db.grade.findMany({
    where,
    include: {
      student: {
        include: {
          class: true
        }
      },
      subject: true,
      exam: true
    },
    orderBy: { createdAt: 'desc' }
  });

  const averages = grades.reduce((acc: any, grade) => {
    const subjectName = grade.subject.name;
    if (!acc[subjectName]) {
      acc[subjectName] = { total: 0, count: 0 };
    }
    acc[subjectName].total += (grade.score / grade.maxScore) * 100;
    acc[subjectName].count += 1;
    return acc;
  }, {});

  Object.keys(averages).forEach(subject => {
    averages[subject] = averages[subject].total / averages[subject].count;
  });

  return { grades, averages };
}

async function generatePaymentsReport(classId?: string, startDate?: string, endDate?: string) {
  const where: any = {};
  
  if (classId) {
    where.student = { classId };
  }
  
  if (startDate && endDate) {
    where.dueDate = {
      gte: new Date(startDate),
      lte: new Date(endDate)
    };
  }

  const payments = await db.payment.findMany({
    where,
    include: {
      student: {
        include: {
          class: true
        }
      }
    },
    orderBy: { dueDate: 'desc' }
  });

  const summary = payments.reduce((acc: any, payment) => {
    acc.total += payment.amount;
    acc.paid += payment.status === 'PAID' ? payment.amount : 0;
    acc.pending += payment.status === 'PENDING' ? payment.amount : 0;
    acc.overdue += payment.status === 'OVERDUE' ? payment.amount : 0;
    return acc;
  }, { total: 0, paid: 0, pending: 0, overdue: 0 });

  return { payments, summary };
}

async function generateEnrollmentReport(classId?: string, startDate?: string, endDate?: string) {
  const where: any = {};
  
  if (classId) {
    where.classId = classId;
  }
  
  if (startDate && endDate) {
    where.enrollmentDate = {
      gte: new Date(startDate),
      lte: new Date(endDate)
    };
  }

  const students = await db.student.findMany({
    where,
    include: {
      class: true
    },
    orderBy: { enrollmentDate: 'desc' }
  });

  const byClass = students.reduce((acc: any, student) => {
    const className = student.class.name;
    acc[className] = (acc[className] || 0) + 1;
    return acc;
  }, {});

  const byGender = students.reduce((acc: any, student) => {
    acc[student.gender] = (acc[student.gender] || 0) + 1;
    return acc;
  }, {});

  return { students, byClass, byGender };
}