'use client'

import SettingsManagement from '@/components/settings/SettingsManagement'

export default function SettingsPage() {
  return <SettingsManagement />
}