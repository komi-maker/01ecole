'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Users, 
  GraduationCap, 
  Calendar, 
  DollarSign, 
  BookOpen, 
  Bell,
  MessageSquare,
  TrendingUp,
  UserCheck,
  Clock,
  AlertCircle,
  FileText,
  Receipt,
  School,
  CreditCard,
  UserMinus,
  Calculator,
  Settings
} from 'lucide-react'

// Import des composants
import StudentManagement from '@/components/students/StudentManagement'
import TeacherManagement from '@/components/teachers/TeacherManagement'
import ClassManagement from '@/components/classes/ClassManagement'
import PaymentManagement from '@/components/payments/PaymentManagement'
import GradeManagement from '@/components/grades/GradeManagement'
import ScheduleManagement from '@/components/schedule/ScheduleManagement'
import AttendanceManagement from '@/components/attendance/AttendanceManagement'
import SettingsManagement from '@/components/settings/SettingsManagement'

// Composants factices pour les modules non encore créés
const SubjectManagement = () => (
  <div className="text-center py-12">
    <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
    <h3 className="text-lg font-medium text-gray-900 mb-2">Module Matières</h3>
    <p className="text-gray-500">Ce module sera bientôt disponible.</p>
  </div>
)

const ExpenseManagement = () => (
  <div className="text-center py-12">
    <Calculator className="h-12 w-12 text-gray-400 mx-auto mb-4" />
    <h3 className="text-lg font-medium text-gray-900 mb-2">Module Dépenses</h3>
    <p className="text-gray-500">Ce module sera bientôt disponible.</p>
  </div>
)

const EnrollmentManagement = () => (
  <div className="text-center py-12">
    <School className="h-12 w-12 text-gray-400 mx-auto mb-4" />
    <h3 className="text-lg font-medium text-gray-900 mb-2">Module Inscriptions</h3>
    <p className="text-gray-500">Ce module sera bientôt disponible.</p>
  </div>
)

const ReceiptManagement = () => (
  <div className="text-center py-12">
    <Receipt className="h-12 w-12 text-gray-400 mx-auto mb-4" />
    <h3 className="text-lg font-medium text-gray-900 mb-2">Module Reçus</h3>
    <p className="text-gray-500">Ce module sera bientôt disponible.</p>
  </div>
)

// Types pour les données du dashboard
interface DashboardStats {
  totalStudents: number
  totalTeachers: number
  totalClasses: number
  totalSubjects: number
  totalRevenue: number
  totalExpenses: number
  pendingPayments: number
  todayAttendances: number
  todayAbsences: number
  unreadMessages: number
  recentNotifications: number
  averageGrade: number
}

interface RecentActivity {
  id: string
  type: 'student' | 'payment' | 'grade' | 'attendance' | 'enrollment' | 'expense'
  description: string
  time: string
  status?: 'success' | 'warning' | 'error'
  amount?: number
}

export default function SchoolManagementDashboard() {
  const [activeTab, setActiveTab] = useState('overview')
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    totalTeachers: 0,
    totalClasses: 0,
    totalSubjects: 0,
    totalRevenue: 0,
    totalExpenses: 0,
    pendingPayments: 0,
    todayAttendances: 0,
    todayAbsences: 0,
    unreadMessages: 0,
    recentNotifications: 0,
    averageGrade: 0
  })

  const [recentActivities, setRecentActivities] = useState<RecentActivity[]>([])

  // Simuler le chargement des données
  useEffect(() => {
    // Données de démonstration
    setStats({
      totalStudents: 245,
      totalTeachers: 32,
      totalClasses: 12,
      totalSubjects: 24,
      totalRevenue: 125000,
      totalExpenses: 85000,
      pendingPayments: 18,
      todayAttendances: 220,
      todayAbsences: 25,
      unreadMessages: 5,
      recentNotifications: 3,
      averageGrade: 14.2
    })

    setRecentActivities([
      {
        id: '1',
        type: 'enrollment',
        description: 'Nouvelle inscription: Marie Dupont - Classe 3ème A',
        time: 'Il y a 2 heures',
        status: 'success'
      },
      {
        id: '2',
        type: 'payment',
        description: 'Paiement reçu de Jean Martin - Frais de scolarité',
        time: 'Il y a 3 heures',
        status: 'success',
        amount: 2500
      },
      {
        id: '3',
        type: 'attendance',
        description: 'Absence non justifiée: Pierre Bernard',
        time: 'Il y a 4 heures',
        status: 'warning'
      },
      {
        id: '4',
        type: 'grade',
        description: 'Notes publiées pour la classe de 3ème A',
        time: 'Il y a 5 heures',
        status: 'success'
      },
      {
        id: '5',
        type: 'expense',
        description: 'Dépense enregistrée: Fournitures de bureau',
        time: 'Il y a 6 heures',
        status: 'success',
        amount: 450
      }
    ])
  }, [])

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'student':
        return <Users className="h-4 w-4" />
      case 'payment':
        return <DollarSign className="h-4 w-4" />
      case 'grade':
        return <GraduationCap className="h-4 w-4" />
      case 'attendance':
        return <Clock className="h-4 w-4" />
      case 'enrollment':
        return <School className="h-4 w-4" />
      case 'expense':
        return <Calculator className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-100 text-green-800'
      case 'warning':
        return 'bg-yellow-100 text-yellow-800'
      case 'error':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <School className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-gray-900">ÉcolePro Manager</h1>
              </div>
              <Badge variant="secondary">Système de Gestion Scolaire</Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" className="relative">
                <Bell className="h-4 w-4" />
                {stats.recentNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {stats.recentNotifications}
                  </span>
                )}
              </Button>
              <Button variant="outline" size="sm" className="relative">
                <MessageSquare className="h-4 w-4" />
                {stats.unreadMessages > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 text-white text-xs rounded-full flex items-center justify-center">
                    {stats.unreadMessages}
                  </span>
                )}
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setActiveTab('settings')}
                className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
              >
                <Settings className="h-4 w-4 mr-2" />
                Paramètres
              </Button>
              <div className="flex items-center space-x-2">
                <div className="h-8 w-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                  A
                </div>
                <span className="text-sm font-medium">Administrateur</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Étudiants</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalStudents}</div>
              <p className="text-xs text-muted-foreground">
                +12% ce mois
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Professeurs</CardTitle>
              <GraduationCap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalTeachers}</div>
              <p className="text-xs text-muted-foreground">
                +2 ce trimestre
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenus</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalRevenue.toLocaleString()}€</div>
              <p className="text-xs text-muted-foreground">
                +8% ce mois
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Présences aujourd'hui</CardTitle>
              <UserCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.todayAttendances}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round((stats.todayAttendances / stats.totalStudents) * 100)}% de présence
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:grid-cols-12 gap-1">
            <TabsTrigger value="overview" className="col-span-2">Vue d'ensemble</TabsTrigger>
            <TabsTrigger value="students" className="col-span-2">Étudiants</TabsTrigger>
            <TabsTrigger value="teachers" className="col-span-2">Professeurs</TabsTrigger>
            <TabsTrigger value="classes" className="col-span-2">Classes</TabsTrigger>
            <TabsTrigger value="payments" className="col-span-2">Paiements</TabsTrigger>
            <TabsTrigger value="grades" className="col-span-2">Notes</TabsTrigger>
            <TabsTrigger value="schedule" className="col-span-2">Emploi du temps</TabsTrigger>
            <TabsTrigger value="subjects" className="col-span-2">Matières</TabsTrigger>
            <TabsTrigger value="attendance" className="col-span-2">Absences</TabsTrigger>
            <TabsTrigger value="expenses" className="col-span-2">Dépenses</TabsTrigger>
            <TabsTrigger value="enrollment" className="col-span-2">Inscriptions</TabsTrigger>
            <TabsTrigger value="receipts" className="col-span-2">Reçus</TabsTrigger>
            <TabsTrigger value="settings" className="col-span-2 flex items-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200">
              <Settings className="h-4 w-4" />
              Paramètres
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Activities */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5" />
                    <span>Activités récentes</span>
                  </CardTitle>
                  <CardDescription>
                    Les dernières activités dans le système
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-64 overflow-y-auto">
                    {recentActivities.map((activity) => (
                      <div key={activity.id} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50">
                        <div className="flex-shrink-0">
                          {getActivityIcon(activity.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {activity.description}
                          </p>
                          <p className="text-xs text-gray-500">{activity.time}</p>
                          {activity.amount && (
                            <p className="text-xs font-medium text-green-600">{activity.amount}€</p>
                          )}
                        </div>
                        {activity.status && (
                          <Badge className={getStatusColor(activity.status)}>
                            {activity.status === 'success' ? 'Succès' : 
                             activity.status === 'warning' ? 'Attention' : 'Erreur'}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Actions rapides</CardTitle>
                  <CardDescription>
                    Accédez rapidement aux fonctionnalités principales
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <Button variant="outline" className="h-20 flex flex-col space-y-2" onClick={() => setActiveTab('students')}>
                      <Users className="h-6 w-6" />
                      <span className="text-sm">Étudiants</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col space-y-2" onClick={() => setActiveTab('enrollment')}>
                      <School className="h-6 w-6" />
                      <span className="text-sm">Inscriptions</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col space-y-2" onClick={() => setActiveTab('payments')}>
                      <CreditCard className="h-6 w-6" />
                      <span className="text-sm">Paiements</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col space-y-2" onClick={() => setActiveTab('grades')}>
                      <FileText className="h-6 w-6" />
                      <span className="text-sm">Notes</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col space-y-2" onClick={() => setActiveTab('attendance')}>
                      <UserMinus className="h-6 w-6" />
                      <span className="text-sm">Absences</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col space-y-2 bg-blue-50 hover:bg-blue-100 border-blue-200" 
                      onClick={() => setActiveTab('settings')}
                    >
                      <Settings className="h-6 w-6 text-blue-600" />
                      <span className="text-sm text-blue-600 font-medium">Paramètres</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Financial Overview */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <DollarSign className="h-5 w-5 text-green-600" />
                    <span>Revenus du mois</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">{stats.totalRevenue.toLocaleString()}€</div>
                  <p className="text-sm text-gray-600">+8% par rapport au mois dernier</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calculator className="h-5 w-5 text-red-600" />
                    <span>Dépenses du mois</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-600">{stats.totalExpenses.toLocaleString()}€</div>
                  <p className="text-sm text-gray-600">+5% par rapport au mois dernier</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-blue-600" />
                    <span>Bénéfice net</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">
                    {(stats.totalRevenue - stats.totalExpenses).toLocaleString()}€
                  </div>
                  <p className="text-sm text-gray-600">Marge: {Math.round(((stats.totalRevenue - stats.totalExpenses) / stats.totalRevenue) * 100)}%</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="students">
            <StudentManagement />
          </TabsContent>

          <TabsContent value="teachers">
            <TeacherManagement />
          </TabsContent>

          <TabsContent value="classes">
            <ClassManagement />
          </TabsContent>

          <TabsContent value="payments">
            <PaymentManagement />
          </TabsContent>

          <TabsContent value="grades">
            <GradeManagement />
          </TabsContent>

          <TabsContent value="schedule">
            <ScheduleManagement />
          </TabsContent>

          <TabsContent value="subjects">
            <SubjectManagement />
          </TabsContent>

          <TabsContent value="attendance">
            <AttendanceManagement />
          </TabsContent>

          <TabsContent value="expenses">
            <ExpenseManagement />
          </TabsContent>

          <TabsContent value="enrollment">
            <EnrollmentManagement />
          </TabsContent>

          <TabsContent value="receipts">
            <ReceiptManagement />
          </TabsContent>

          <TabsContent value="settings">
            <SettingsManagement />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}